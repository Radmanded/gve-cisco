.. acitoolkit documentation master file, created by
   sphinx-quickstart on Sat Oct 25 16:49:43 2014.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Welcome to acitoolkit's documentation!
======================================
.. image:: aci.png

Contents:

.. toctree::
   :maxdepth: 4

   introduction
   objectmodel
   monitor_policy
   tutorial
   stats
   modules
   applications


Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`

