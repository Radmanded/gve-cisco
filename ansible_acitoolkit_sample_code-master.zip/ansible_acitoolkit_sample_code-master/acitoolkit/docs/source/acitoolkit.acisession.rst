acisession module
=================

.. automodule:: acitoolkit.acisession

    .. autoclass:: Session
        :members:
        :inherited-members:	   
        :undoc-members:
        :show-inheritance:
