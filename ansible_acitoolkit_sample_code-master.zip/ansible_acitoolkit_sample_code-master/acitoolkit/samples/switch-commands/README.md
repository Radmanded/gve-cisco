# ACI Toolkit Samples - Switch Commands #

This directory contains sample scripts that operate in a similar manner to the commands provided on the individual switches.
