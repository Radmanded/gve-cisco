# Webex Trainings Mass Upload Web Interface

This project provides the user with a password-protected web interface to 
mass create webex events and webex meetings from a csv file. 

It leverages the functions from [this project](https://wwwin-github.cisco.com/gve/webex_meetings_scheduler)
and wraps them into a web interface.

## Contacts

* Marcel Neidinger (mneiding@cisco.com)

## Solution Components

* flask
* Python3

## Installation/Configuration

This application is a standard flask application. First install the required packages by running

```bash
$ pip install -r requirements.txt
```

Next you need to configure the application by providing the required variables in a `config.yml` file. 
The repository includes a `config.yml.conftpl` file.

```yaml
---
webex_user: <Webex Admin User>
webex_password: <Webex Admin User Password>
webex_site: <Webex Site>
default_webex_password: <Default password for webex meetings>

site_user: <user for web interface>
site_password: <password for web interface>
```

Last you need to create a `uploads` directory by running

```bash
$ mkdir -p uploads
```

## Usage

To start the flask application using the build-in web server from flask simply run

```bash
$ python3 app.py
```

This will start the web server on port 8080. Have a look at the provided `csv_template.csv` to 
see how to properly format the file for the .csv upload.

### License

Provided under Cisco Sample Code License, for details see [LICENSE](./LICENSE)

### Code of Conduct

Our code of conduct is available [here](./CODE_OF_CONDUCT.md)

### Contributing

See our contributing guidelines [here](./CONTRIBUTING.md)

#### DISCLAIMER:
<b>Please note:</b> This script is meant for demo purposes only. All tools/ scripts in this repo are released for use "AS IS" without any warranties of any kind, including, but not limited to their installation, use, or performance. Any use of these scripts and tools is at your own risk. There is no guarantee that they have been through thorough testing in a comparable environment and we are not responsible for any damage or data loss incurred with their use.
You are responsible for reviewing and testing any scripts you run thoroughly before use in any non-testing environment.
