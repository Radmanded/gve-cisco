# Copyright (c) 2020 Cisco and/or its affiliates.
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

import yaml
import os
import functions
import csv
import datetime
import string
import random
import xml.etree.ElementTree as ET
import pandas as pd
from shutil import copyfile

from flask import Flask, flash, request, redirect, url_for, render_template
from flask_httpauth import HTTPBasicAuth
from werkzeug.security import generate_password_hash, check_password_hash
from werkzeug.utils import secure_filename

def generate_random_password(length=8):
    chars = []

    for i in range(0, length):
        char = random.choices(string.ascii_letters)[0]

        chars.append(char)
    return "".join(chars)

def allowed_file(filename):
    return '.' in filename and \
           filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS

def create_meeting_from_csv(file_path):
    with open(file_path,'r') as csv_file:
        csv_reader = csv.reader(csv_file)
        header = None
        
        meetings_and_keys = {}
        for row_number, row in enumerate(csv_reader):

            if row_number == 0:
                header = row
                continue
            else:
                meeting_name = row[0]
                host = row[1]
                session_type = row[2]
                meeting_template = row[3]
                start_time = row[4]
                end_time = row[5]
                duration = row[6]

                attendees = row[7]
                attendees = attendees.replace(' ','')
                attendees = attendees.split(';')

                date = row[8]
                day_number = row[9]
                period_number = row[10]
                period_name = row[11]

                # Here we are swapping the date format from DD/MM/YYYY to MM/DD/YYYY 

                start_time = list(start_time)
                start_time[0:2] ,start_time[3:5] = start_time[3:5],start_time[0:2]
                start_time = ''.join(start_time)
                start_time = start_time + ":00"

                print("Start time: " + start_time)
                if session_type == 'M':
                    try:
                        response = functions.CreateMeeting(functions.sessionSecurityContext,
                            meetingPassword = generate_random_password(),
                            confName = meeting_name,
                            meetingType = meetingType,
                            agenda = period_name,
                            startDate = start_time,
                            duration = duration,
                            host = host,
                            attendees = attendees)

                        meeting_key = response.find('{*}body/{*}bodyContent/{*}meetingkey').text

                        meetings_and_keys[meeting_name] = meeting_key

                    except functions.SendRequestError as err:
                        print(err)
                        raise SystemExit
                elif session_type == 'T':
                    try:
                        response = functions.CreateTraining(functions.sessionSecurityContext,
                            meetingPassword = generate_random_password(),
                            confName = meeting_name,
                            meetingType = meetingType,
                            agenda = period_name,
                            startDate = start_time,
                            duration = duration,
                            host = host,
                            attendees = attendees)
                        
                        session_key = response.find('{*}body/{*}bodyContent/{*}sessionkey').text
                        meetings_and_keys[meeting_name] = session_key
                    except functions.SendRequestError as err:
                        print(err)
                        raise SystemExit
        return meetings_and_keys

# Read configuration
config = yaml.safe_load(open("config.yml"))

# AuthenticateUser and get sesssionTicket
try:
    functions.sessionSecurityContext = functions.AuthenticateUser(
        config['webex_site'],
        config['webex_user'],
        config['webex_password'],
        ""
    )

# If an error occurs, print the error details and exit the script
except functions.SendRequestError as err:
    print(err)
    raise SystemExit

# Get default meeting type
try:
    response = functions.GetUser(functions.sessionSecurityContext)

except functions.SendRequestError as err:
    print(err)
    raise SystemExit

meetingType = response.find('{*}body/{*}bodyContent/{*}meetingTypes')[0].text
    
# Setup web server
app = Flask(__name__)

UPLOAD_FOLDER = 'uploads'
ALLOWED_EXTENSIONS = {'csv', 'pdf', 'png', 'jpg', 'jpeg', 'gif'}

app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER

# Setup authentication
auth = HTTPBasicAuth()

users = {
    config['site_user']: generate_password_hash(config['site_password'])
}

@auth.verify_password
def verify_password(username, password):
    if username in users and \
            check_password_hash(users.get(username), password):
        return username

# Setup upload view
@app.route('/', methods=['GET', 'POST'])
@auth.login_required
def upload_file():
    if request.method == 'POST':
        # check if the post request has the file part
        if 'file' not in request.files:
            flash('No file part')
            return redirect(request.url)
        file = request.files['file']
        # if user does not select file, browser also
        # submit an empty part without filename
        if file.filename == '':
            flash('No selected file')
            return redirect(request.url)
        if file and allowed_file(file.filename):
            filename = secure_filename(file.filename)
            uploaded_file_path = os.path.join(app.config['UPLOAD_FOLDER'], filename)

            file.save(uploaded_file_path)
            
            # Create meetings
            created_meetings = create_meeting_from_csv(uploaded_file_path)

            return render_template("success.html", meetings=created_meetings)
    return render_template("upload.html")

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=8080)