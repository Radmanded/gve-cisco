# Environment Variables
BOT_TOKEN = '<bot token>'
BOT_NAME = '<bot name>'
HELP_SPACE = '<webex request space>'
