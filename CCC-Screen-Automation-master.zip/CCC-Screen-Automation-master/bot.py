"""
Copyright (c) 2020 Cisco and/or its affiliates.

This software is licensed to you under the terms of the Cisco Sample
Code License, Version 1.1 (the "License"). You may obtain a copy of the
License at

               https://developer.cisco.com/docs/licenses

All use of the material herein must be in accordance with the terms of
the License. All rights not expressly granted by the License are
reserved. Unless required by applicable law or agreed to separately in
writing, software distributed under the License is distributed on an "AS
IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express
or implied.
"""


import requests, time, json, os, yaml, threading, subprocess, webbrowser

from datetime import date


from pyadaptivecards.card import AdaptiveCard
from pyadaptivecards.inputs import Choices, Toggle
from pyadaptivecards.components import TextBlock, Choice
from pyadaptivecards.actions import Submit

from flask import Flask, request, jsonify

from webexteamssdk import WebexTeamsAPI


#access environment variables
SCRIPT_DIRECTORY = os.environ.get('SCRIPT_DIRECTORY')
NGROK_DIRECTORY = os.environ.get('NGROK_DIRECTORY')
NGROK_PORT = os.environ.get('NGROK_PORT')
BOT_ACCESS_TOKEN = os.environ.get('BOT_ACCESS_TOKEN')
BOT_EMAIL = os.environ.get('BOT_EMAIL')


# create a webex teams api connection
api = WebexTeamsAPI(access_token=BOT_ACCESS_TOKEN)
# create a Flask application
app = Flask(__name__)


#automates ngrok and webhook update
def ngrok():
    '''
    This function opens a secure tunnel to the Internet using ngrok and sets up the Webex Teams webhooks accordingly.
    Using ngrok, the Flask application, i.e. the bot running on the local machine, can securely connect to a public
    URL that Webex Teams can connect to. For the webhooks, the function draws on the hooks.yml file and manipulates the
    vars.yml with the Bot access token and the ngrok public URL. The webhook setup is based on the following GitHub
    repository: https://github.com/CiscoSE/webhooksimple

    **[ATTENTION]** The commands that are executed here are written for Windows. When using other OS, commands (esp. for
    killing and starting the ngrok process and for setting up the webhooks) may need to be adapted.

    The parts of the function in the while loop, in which ngrok is started and the webhooks setup, re-runs every 7
    hours, given that the tunnel expires after a certain amount of time. In the __main__ function, this function is
    threaded, i.e. it runs in parallel to the bot given that the tunnel needs to be open at the same time as the bot is
    running.

    :return: nothing
    '''

    #read the access token from the environment variables and store it in the vars file
    t = yaml.safe_load(open(SCRIPT_DIRECTORY + 'vars.yml'))
    t['adapter']['authentication']['access_token'] = BOT_ACCESS_TOKEN
    with open(SCRIPT_DIRECTORY + 'vars.yml', 'w') as s:
        yaml.dump(t, s, default_flow_style=False)

    wakeup = time.time()  # variable required for the timer set at the end of the while loop
    x = 0  # variable, to check if the while loop is running for the first time or not

    while True: #endless loop to re-run the process given that the ngrok tunnel runs out after a certain amount of time

        # to kill any running ngrok session the second time the while loop is executed
        if x >= 1:
            os.system("taskkill /f /im ngrok.exe")
        x = + 1

        #start ngrok
        os.chdir(NGROK_DIRECTORY)  #changes the selected paths to where ngrok is located
        os.popen('ngrok http ' + NGROK_PORT) #executes the command

        time.sleep(5)  # pause the script to fully load ngrok

        #read the ngrok URL from the ngrok APIs
        a = requests.get("http://127.0.0.1:4040/api/tunnels").text
        b = json.loads(a)
        c = b['tunnels'][0]['public_url']

        #update the ngrok URL in the vars.yml file
        y = yaml.safe_load(open(SCRIPT_DIRECTORY + 'vars.yml'))
        y['remote_prefix'] = c
        with open(SCRIPT_DIRECTORY + 'vars.yml', 'w') as f:
            yaml.dump(y, f, default_flow_style=False)

        #update the webhook with the new ngrok url
        os.chdir(SCRIPT_DIRECTORY)  # changes the selected paths to where the vars file is located
        subprocess.run('python -m webhooksimple setup') #executes the command

        # sets a timer to 7 hours to wait before the while loop re-runs
        wakeup += 60 * 60 * 7
        while time.time() < wakeup:
            time.sleep(1)



#creates and sends the card
def card(roomId):
    '''
    This function creates an instance of Microsoft's adaptive card from https://adaptivecards.io/. The card itself is
    sent when the bot is addressed in Webex Teams and allows the user to provide input and submit the card, which stores
    the submitted information in a JSON.

    Adaptive Cards are written in JSON. To use Python instead, the following GitHub repository was used:
    https://github.com/CiscoSE/pyadaptivecards

    :param roomId: The room ID to which the card is to be sent, equals the room ID from the Webex Teams space in which the bot was addressed

    :return: nothing
    '''

    #create the body of the card
    greeting = TextBlock("Hello! I am here to help you display valuable content to your customer when visiting the Amsterdam CCC. Just let me know from which industry your customer is and if you want to show custom or default content on the screens, and I will make sure the content will be displayed on the CCC screens immediately.")
    string_choice = ['Financial Services', 'Insurance', 'Retail', 'Sports and Entertainment', 'Energy', 'Manufacturing', 'Oil and Gas', 'Utilities', 'Cities and Communities', 'Education', 'Government', 'Healthcare', 'Transportation'] #provides the choices in the drop-down menu
    choices = [Choice(s, s.lower().replace(" ", "")) for s in string_choice] #allows user input in line with the string_choice list
    industry = Choices(choices, 'industry') #creates the component in the card based on the two lines of code above
    fileupload = Toggle('Check this box if you want to upload custom content.', 'fileupload') #adds a checkbox to the card


    #create a submit action
    submit = Submit(title="Send me!")

    #put the different components of the card together
    card = AdaptiveCard(body=[greeting, industry, fileupload], actions=[submit])

    # Create a dict that will contain the card as well as some meta information
    attachment = {
        "contentType": "application/vnd.microsoft.card.adaptive",
        "content": card.to_dict(),
    }

    #post the card to the Webex Teams space in the name of the bot, draws on the Webex Teams API from the SDK
    api.messages.create(roomId=roomId, markdown="Adaptive Card", attachments=[attachment])

#state machine, to set users into different states and understand where in the process they are, to reference to it back in the webhooks
STATE_START = "START"
STATE_FILEUPLOAD = "FILEUPLOAD"
state_mapping = {} #creates a dictionary and will be used to map users against where they are in the process, i.e. user email, state, and which industry they chose in the card


#defines what happens when a message is created and addressed to the bot, i.e. when the messages created webhook is triggered
@app.route('/webhook/messages/created', methods=['POST'])
def webhook_messages_created():
    '''
    This function is triggered every time a message is sent to the bot. The response and behaviour of the bot to a
    message depends on the state, in which a user is, i.e. whether the user is starting the conversation with the bot
    (user_state = STATE_START, the bot responds with the adaptive card) or whether the message is a reaction related to
    uploading files as part of the process (user_state = STATE_FILEUPLOAD, the bot expects files and/or weblinks in the
    subsequent user input message, downloads the content, and opens the files and/or weblinks, and resets the
    user_state to STATE_START at the end of the statement).

    The state of a user is determined by the state machine that has been created at the beginning of the script and the
    state is constantly and automatically updated based on the user input. As soon as the bot finishes a process and
    reaches the end state, i.e. as soon as content is shown on the screens, the state of a user is reset so that in a
    subsequent interaction, the process starts from the start state again.

    :return: success, stored in a JSON from Flask, to trigger a 200 status code when function is executed
    '''


    #retrieve relevant information from the json file storing message information
    raw_json = request.get_json() #load the message details into a json
    messageId_json = raw_json['data']['id']
    personId_json = raw_json['data']['personId'] #store the person ID of the sender in a variable
    personEmail_json = raw_json['data']['personEmail']  # store the person ID of the sender in a variable
    roomId_json = raw_json['data']['roomId'] #store the room ID where the message was sent in a variable
    roomType_json = raw_json['data']['roomType'] #stores the type of room, i.e. personal or group, where the message was sent in a variable
    data_json = raw_json['data']


    #adds a user to the state mapping dictionary to track where in the process he is
    if personId_json not in state_mapping.keys():
        state_mapping[personId_json] = {'state': STATE_START, 'roomType': {}, 'industry': {}}

    #updates the roomType in the dictionary
    state_mapping[personId_json]['roomType'] = roomType_json

    # saves the user state in a variable to execute on in the following if statement
    user_state = state_mapping[personId_json]['state']

    if user_state == STATE_START: #checks the status of the user, and if at the beginning or reuses the bot, the card is sent; also makes sure that it is not executed when the bot is sending messages
        if personEmail_json != BOT_EMAIL: #to make sure that the bot does not reply to his own messages
            card(roomId_json)  # to send the card to the room, in which the bot has been talked to
    elif user_state == STATE_FILEUPLOAD:
        #for the files sent in the message
        if "files" in data_json:  # checks if a file has been uploaded
            for url in data_json['files']: #iterates through the values, i.e. urls, of the files key in case multiple files have been uploaded
                headers = {  # for authorization that we are allowed to download the file
                    "Authorization": "Bearer " + BOT_ACCESS_TOKEN
                }
                file = requests.get(url, headers=headers)  # retrieves the file
                filename = str(file.headers['Content-Disposition']).strip().split(" ")[1].replace('"', "").replace("filename=", "").replace("+", "")
                industry = state_mapping[personId_json]['industry']

                #defines where to save the file
                today = str(date.today())
                path = SCRIPT_DIRECTORY + '/ScreenThemes/Custom/' + today
                if not os.path.exists(path):
                    os.mkdir(path)
                filename_new = path + "/" + personEmail_json.replace("@cisco.com", "") + '_' + industry + '_' + filename
                open(filename_new, 'wb').write(file.content) #downloads the file and saves it in the specified path
                os.startfile(filename_new) #opens the file on screen

        #for the links sent in the message
        # call the api that returns the json with the text information in case links were also sent, i.e. to retrieve the links to be shown
        request_url = "https://api.ciscospark.com/v1//messages/{}".format(messageId_json)
        headers = {
            "Authorization": "Bearer " + BOT_ACCESS_TOKEN
        }
        attachment_json = requests.get(request_url, headers=headers).json()  # to store the data in a json
        #in case any and multiple links have been sent, to seperate them and store each link in a list
        if "text" in attachment_json: #checks if the message has content, i.e. if links have been uploaded
            links_list = attachment_json['text'].split(', ')
            if roomType_json == "group": #in case the bot is addressed in a room, the name of the bot must be deleted from the list
                links_list.remove(links_list[0])
            for link in links_list:  # to iterate through the list to open each link
                webbrowser.open(link)

        state_mapping[personId_json] = {'state': STATE_START, 'roomType': {}, 'industry': {}}  # updates the dictionary of the state machine
        api.messages.create(roomId=roomId_json, markdown="Fantastic! The content is shown on the screens now.") #sends a confirmation message to the user from the bot


    return jsonify({'success': True})


#defines what happens when the card is submitted, i.e. when the attachmentActions created webhook is triggered
@app.route('/webhook/attachmentActions/created', methods=['POST'])
def webhook_attachmentActions_created():
    '''
    This function is triggered when the adaptive card is submitted. The information sent through the card is
    accessed through the API call, and depending on whether the user chose to upload files himself or not, the bot
    takes according actions.

    If the user chooses to not upload files himself, the bot will open the default files that are already saved on the
    PC for the industry that the user indicated in the adaptive card. At the end of the process, the user_state is reset
    to STATE_START in the state machine, so that in a following interaction the process starts from the beginning.
    If the user chooses to upload files himself, the bot will set the user_state of the user to STATE_FILEUPLOAD and ask
    the user to upload files and/or weblinks. Once the user sends the data, the message created webhook will be
    triggered and follows the if-statement for which user_state = STATE_FILEUPLOAD is true.

    :return: success, stored in a JSON from Flask, to trigger a 200 status code when function is executed
    '''

    #retrieve relevant information from the json file storing message information
    raw_json = request.get_json()
    messageId_json = raw_json['data']['id'] #get the message ID of the submit action based on which the information is retrieved
    roomId_json = raw_json['data']['roomId']
    personId_json = raw_json['data']['personId']

    #call the api that returns the json with the information that were sent with the card through the submit action
    request_url = "https://api.ciscospark.com/v1//attachment/actions/{}".format(messageId_json)
    headers = {
        "Authorization": "Bearer " + BOT_ACCESS_TOKEN
    }
    attachment_json = requests.get(request_url, headers=headers).json() #to store the data in a json

    #loads the industry value selected into a variable
    industry_value = attachment_json['inputs']['industry']

    #to provide the opportunity to upload a file if the fileupload field is ticked in the card
    fileupload_value = attachment_json['inputs']['fileupload']
    if fileupload_value == 'true':
        # to update the values in the state machine
        state_mapping[personId_json]['state'] = STATE_FILEUPLOAD
        state_mapping[personId_json]['industry'] = industry_value

        # depending on whether the bot is interacted with in a private chat or a group chat, th example image differs
        if state_mapping[personId_json]['roomType'] == "group":
            example_image = SCRIPT_DIRECTORY + 'example_fileupload_group.png'
        elif state_mapping[personId_json]['roomType'] == "direct":
            example_image = SCRIPT_DIRECTORY + 'example_fileupload_direct.png'
        api.messages.create(roomId=roomId_json, markdown="Fantastic! Please upload the files and send the weblinks you want to be shown on the screens in a single message now. Make sure that the message looks as in the example image provided.", files=[example_image])



    elif fileupload_value == 'false':
        # to identify the correct folder based on industry values and exisiting folders on the PC
        folder_initials = {'folder_initials': []}
        path = SCRIPT_DIRECTORY + 'ScreenThemes/'
        folders = os.listdir(path)
        for folder_name in folders:
            folder_initials['folder_initials'].append(folder_name[:3].lower())
        index = folder_initials['folder_initials'].index(industry_value[:3])
        path_full = path + folders[index]

        #to open every file in the relevant folder
        files = os.listdir(path_full)
        for file_name in files:
            os.startfile(path_full + '/' + file_name)

        #sends a confirmation message to the user from the bot
        api.messages.create(roomId=roomId_json, markdown="Fantastic! The content is shown on the screens now.")


    return jsonify({'success': True})


if __name__ == "__main__":
    #starts the ngrok process and has it run in the background, i.e. in parallel to the bot
    x = threading.Thread(target=ngrok)
    x.start()

    #runs the bot
    app.run(host="0.0.0.0", port=NGROK_PORT)
