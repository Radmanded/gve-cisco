## Welcome to CCCBuddy Project

This project is related to the FY20 CSAP cohort programmmability projects. If you are interested in it, please reach out the project's owner

- Juliette Ros
- Jara Osterfeld	

CCCBuddy is a bot developed for remote screen management in the Cisco Customer Center (CCC) in Amsterdam. It is aimed to interact with account managers, who want to customize the content shown on the screens in the CCC for it to be relevant to their visiting customers.

The execution brings the bot to life and allows account managers to interact with it using Webex Teams, upload content where applicable, and display it on the screen of the main PC in the CCC immediately.


## Features

* Open an ngrok tunnel in the background and setup webhooks accordingly and automatically renew it every 8 hours for constant connectivity
* React to a message by a Webex Teams User with an Adaptive Card
* Take the input of the Adaptive Card from the user
* Based on the user input from the Adaptive Card: open default content stored on the local machine as indicated by the user; or ask the user to upload files and/or share weblinks for custom content, wait for a response from the user, receive the response, and download and save the files under a custom named, and open the files and/or the weblinks
* Send confirmation messages to the user
* Track the status of users in the process of interacting with the bot


## Solution Components

* Bot.py Script (Python v3.7)
* Microsoft Adaptive Cards from https://adaptivecards.io/, integrated into the script using the PyAdaptiveCards GitHub repository (https://github.com/CiscoSE/pyadaptivecards , v0.1.0)
* Flask (v1.0.2), ngrok, and Webhooks, incl. webhooksimple GitHub repository (https://github.com/CiscoSE/webhooksimple , v0.1.2) to automatically create and update webhooks from a YAML file
* Documentation is written using Sphinx 


### Cisco Products / Services

* Webex Teams, incl. conversational Webex Teams Bot (created at www.developer.webex.com) and Webex Teams SDK (Messages and Attachment Actions API, v1.2)


## Usage

The bot is based on Flask, which allows the local machine, on which the bot is running, to function as a webserver that is able to respond to web requests.

For Flask to access the Internet securely and to thus establish a connection to Webex Teams, it functions in combination with ngrok and webhooks: every time the bot is addressed in Webex Teams, a webhook is triggered, i.e. a Webex Teams API is called that sends the information of the message to the local machine on which the bot is running. Given that an always open connection to the Internet is not secure, ngrok is used inbetween. ngrok runs on the local machine and opens a secure tunnel between the local machine and the ngrok cloud, which is then mapped against a publicly reachable URL. This URL is used by the Webex Teams API to send the webhook to, and ngrok forwards the information received on that URL throught the secure tunnel to the local machine. Once received on the local machine, the Flask application takes the information from the webhook and directs to the correct route and function in the script.


## Installation

[WARNING] The step-by-step installation guide is written for setting the bot up on Windows. For other OS, some commands may differ. Same applies to some lines of codes in the bot.py script. Check bot.ngrok() for more information.

1. Create a bot on https://developer.webex.com/docs/bots and obtain the access token of the bot and the bot’s e-mail address

2. Clone the CCCBuddy repository from GitHub to your local machine with  `git clone https://wwwin-github.cisco.com/gve/CCC-Screen-Automation.git`

3. Once downloaded, populate the folders under /cccbuddy/ScreenThemes/ with the default content for the different industries and delete the .gitkeep file in each of the folders.

4. [Recommended] Create a Python virtual environment in the same directory as you cloned the CCCBuddy GitHub repository to, and activate it. Instructions on how to do that can be easily found on Google.

5. Install the script requirements. These contain the webexteamssdk, Flask, PyYAML, requests, and pyadaptivecards, needed for the script to work. Execute the following line from the same folder where the bot.py file is located (make sure you have the virtual environment activated if you are using it): `pip install -r requirements.txt`

6. Set the following variables as environment variables:
```
# The path pointing to where the bot.py file is located, end with '/'
set SCRIPT_DIRECTORY=C:/path/to/location/where/script/is/located/
# The path pointing to where ngrok is installed, end with '/'
set NGROK_DIRECTORY=C:/path/to/location/where/ngrok/is/installed/
# The port listening to ngrok
set NGROK_PORT=port_number
# The email address of the bot
set BOT_EMAIL=bot_name@webex.bot
# The access token of the bot
set BOT_ACCESS_TOKEN=access_token
```

7. Execute the code to bring the bot to live using the following command: `python bot.py`

Congratulations, you can now chat with your bot on Webex Teams!

## Documentation

***More detailed documentation and instructions in HTML format for the project can be found under the folder docs/index.html. Please download for better readability.***
