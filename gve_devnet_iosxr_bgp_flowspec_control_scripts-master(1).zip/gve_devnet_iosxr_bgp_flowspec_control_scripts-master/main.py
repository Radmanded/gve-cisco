from pyats.topology import loader
from lxml import etree
from pprint import pprint
from jinja2 import Environment, FileSystemLoader

env=Environment(loader=FileSystemLoader("templates"))

def get_user_selection():
    print()
    print("1. List Interfaces. ")
    print("2. Enable Flowspec for interfaces.")
    print("3. Disable Flowspec for interfaces.")
    print("4. Check Flowspec for interfaces.")
    print("0. Exit. ")
    print("Select an Operation: ")
    user_choice = int(input())
    return user_choice

def get_interfaces():
    print("Enter Interface Details (Eg: GigabitEthernet0/0/0/1,GigabitEthernet0/0/0/2 )")
    user_input=input()
    interfaces=user_input.split(',')
    return interfaces

def list_interfaces(device):
    ele_filter = etree.Element("{urn:ietf:params:xml:ns:netconf:base:1.0}filter",
                               type="subtree")
    ele_interfaces = etree.SubElement(ele_filter,"native",
                                   nsmap={None: 'urn:ietf:params:xml:ns:yang:native'})
    pprint(device.nc.get_config(source='running',filter=ele_filter).data_xml)

def netfconf_request(device,interfaces,filename,edit=False):
    template = env.get_template(filename)

    data_options={"interfaces":interfaces }
    rpc_msg=template.render(data_options)
    print(rpc_msg)
    reply=device.nc.request(rpc_msg,timeout=40)
    pprint(reply)

    if edit:
        rpc_commit=env.get_template('commit.txt')
        reply=device.nc.request(rpc_commit, timeout=40)
        pprint(reply)


def disable_flowspec(device,interfaces):
    template = env.get_template("disable-flowspec-interface.txt")
    for interface in interfaces:
        device.nc.edit(template.render('interface_name',interface))


def get_flowspec_status(device,interfaces):
    template = env.get_template("check-flowspec-interface.txt")
    ele_filter = etree.Element("{urn:ietf:params:xml:ns:netconf:base:1.0}filter", type="subtree")
    interface_flowspec = etree.SubElement(ele_filter, "Cisco-IOS-XR-flowspec-cfg",
                                          nsmap={None: 'http://cisco.com/ns/yang/ned/ios'})
    for interface in interfaces:
        device.nc.get_config(template.render('interface_name',interface))


if __name__=='__main__':

    # Load Testbed File
    testbed = loader.load('testbed.yaml')
    device = testbed.devices['device-2']
    print('Trying to establish connection to {}'.format(device.connections.netconf.ip.exploded))
    device.connect(alias='nc', via='netconf')

    if device.nc.connected:
        user_choice=get_user_selection()
        while(user_choice>0):
            if user_choice == 1:
                list_interfaces(device)
            else:
                if user_choice <5:
                    interfaces = get_interfaces()
                    if user_choice == 2:
                        netfconf_request(device,interfaces,"enable-flowspec-interface.txt",True)
                    elif user_choice == 3:
                        netfconf_request(device,interfaces,"disable-flowspec-interface.txt",True)
                    elif user_choice == 4:
                        netfconf_request(device,interfaces,"get-flowspec-interface.txt")
            user_choice = get_user_selection()
