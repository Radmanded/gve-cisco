config = {}

config['BOT_URL'] = "http://127.0.0.1:5000/"
config['WEBEX_ACCESS_TOKEN'] = ""
config['PRODUCTION_EMAIL'] = "commercialsheets@webex.bot"
config['BOT_NAME'] = "CommercialSheets"
config['APPROVED_USERS'] = {
    ""
}
