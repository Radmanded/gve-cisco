# GVE_Devnet_CommercialUK_SharepointToWebex

![Alt text](/IMAGES/gve.png)

## Contacts
* Celina Silva (celsilva@cisco.com)
* Naoise Oluwalogbon(noluwalo@cisco.com)

## Solution Components
* Webex Bot
* Python
* Hookbuster
* Adaptive Cards
* Sharepoint API

## Installation/Configuration

Clone the repo :

$ git clone (link)

(Optional) Create Virtual Environment :

Initialize a virtual environment

virtualenv venv

Activate the virtual env

Windows venv\Scripts\activate

Linux source venv/bin/activate

To install virtualenv run:

pip install virtualenv

To leave the virtual environment run:

deactivate

Install the libraries :

$ pip install -r requirements.txt

Setup:

1) Clone Hookbuster from (https://github.com/WebexSamples/hookbuster) - Follow the instructions from the hookbuster repository to install and run

2) Create a webex bot - Follow the instructions on how to create a Webex bot on https://developer.webex.com/docs/bots#creating-a-webex-bot

3) Add your Webex credentials in env.py file 

    config['BOT_URL'] = "http://127.0.0.1:5000/"
    
    config['WEBEX_ACCESS_TOKEN'] = ""
    
    config['PRODUCTION_EMAIL'] = ""
    
    config['BOT_NAME'] = ""
    
    config['APPROVED_USERS'] = {
        "(enter your cisco email)"
    }
 4) Run the script
    python bot.py
    
 5) Go on your bot in webex and enter the commands to get started






```


### LICENSE

Provided under Cisco Sample Code License, for details see [LICENSE](LICENSE.md)

### CODE_OF_CONDUCT

Our code of conduct is available [here](CODE_OF_CONDUCT.md)

### CONTRIBUTING

See our contributing guidelines [here](CONTRIBUTING.md)

#### DISCLAIMER:
<b>Please note:</b> This script is meant for demo purposes only. All tools/ scripts in this repo are released for use "AS IS" without any warranties of any kind, including, but not limited to their installation, use, or performance. Any use of these scripts and tools is at your own risk. There is no guarantee that they have been through thorough testing in a comparable environment and we are not responsible for any damage or data loss incurred with their use.
You are responsible for reviewing and testing any scripts you run thoroughly before use in any non-testing environment.
