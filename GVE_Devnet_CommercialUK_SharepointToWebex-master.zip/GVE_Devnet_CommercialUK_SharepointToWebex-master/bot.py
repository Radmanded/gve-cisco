"""
Copyright (c) 2020 Cisco and/or its affiliates.
This software is licensed to you under the terms of the Cisco Sample
Code License, Version 1.1 (the "License"). You may obtain a copy of the
License at
               https://developer.cisco.com/docs/licenses
All use of the material herein must be in accordance with the terms of
the License. All rights not expressly granted by the License are
reserved. Unless required by applicable law or agreed to separately in
writing, software distributed under the License is distributed on an "AS
IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express
or implied.
"""

import requests
import json
from pyadaptivecards.card import AdaptiveCard
from pyadaptivecards.inputs import Text, Number
from pyadaptivecards.components import TextBlock
from pyadaptivecards.actions import Submit
from webexteamsbot import TeamsBot
from webexteamsbot.models import Response
import csv
from requests.auth import HTTPBasicAuth
from openpyxl import load_workbook
import io
# from webex_bot.webex_bot import WebexBot
from requests_toolbelt.multipart.encoder import MultipartEncoder
from env import config


auth_token = config['WEBEX_ACCESS_TOKEN']
email = config['PRODUCTION_EMAIL']
bot_url = config['BOT_URL']
bot_app_name = config['BOT_NAME']
approved_users = config['APPROVED_USERS']


headers = {
    "Authorization": "Bearer " + auth_token
}
bot = TeamsBot(
    bot_app_name,
    teams_bot_token=auth_token,
    teams_bot_url=bot_url,
    teams_bot_email=email,
    debug=True,
    approved_users=approved_users,
    webhook_resource_event=[
        {"resource": "messages", "event": "created"},
        {"resource": "attachmentActions", "event": "created"},
    ],
)


def show_card(incoming_msg):
    attachment = """
    {
        "contentType": "application/vnd.microsoft.card.adaptive",
        "content": {
            "type": "AdaptiveCard",
            "body": [{
                "type": "Container",
                "items": [{
                    "type": "TextBlock",
                    "text": "Commercial Sheets."
                },{
                    "type": "Input.Text",
                    "placeholder": "Name",
                    "style": "name",
                    "maxLength": 0,
                    "id": "NameVal"
                },
                {
                    "type": "Input.Text",
                    "placeholder": "Customer",
                    "style": "name",
                    "maxLength": 0,
                    "id": "CustomerVal"
                },
                {
                    "type": "Input.Text",
                    "placeholder": "Enter Vertical",
                    "style": "name",
                    "maxLength": 0,
                    "id": "VerticalVal"
                },
                {
                    "type": "Input.ChoiceSet",
                    "id": "Portfolio",
                    "choices": [
                        {
                            "title": "Enterprise Networking",
                            "value": "EN"
                        },
                        {
                            "title": "Security",
                            "value": "Sec"
                        },
                        {
                            "title": "Collaboration",
                            "value": "Col"
                        },
                        {
                            "title": "Datacentre",
                            "value": "DC"
                        },
                        {
                            "title": "All",
                            "value": "ALL"
                        }
                    ],
                    "placeholder": "Choose Portfolio"
                }]
            }],
            "actions": [{
                    "type": "Action.Submit",
                    "title": "Submit",
                    "data": {
                        "cardType": "input",
                        "id": "inputTypesExample"
                    }
                }
            ],
                "$schema": "http://adaptivecards.io/schemas/adaptive-card.json",
                "version": "1.0"
        }
    }
    """
    backupmessage = "This is an example using Adaptive Cards."

    c = create_message_with_attachment(
        incoming_msg.roomId, msgtxt=backupmessage, attachment=json.loads(
            attachment)
    )
    print(c)
    return ""


def create_message_with_attachment(rid, msgtxt, attachment):
    headers = {
        "content-type": "application/json; charset=utf-8",
        "authorization": "Bearer " + auth_token,
    }

    url = "https://api.ciscospark.com/v1/messages"
    data = {"roomId": rid, "attachments": [attachment], "markdown": msgtxt}
    response = requests.post(url, json=data, headers=headers)
    return response


def get_attachment_actions(attachmentid):
    print("Getting attachment details")
    headers = {
        "content-type": "application/json; charset=utf-8",
        "authorization": "Bearer " + auth_token,
    }

    url = "https://api.ciscospark.com/v1/attachment/actions/" + attachmentid
    response = requests.get(url, headers=headers)
    return response.json()


def handle_cards(api, incoming_msg):

    print("handling card")
    m = get_attachment_actions(incoming_msg["data"]["id"])
    print(incoming_msg)
    sender = bot.teams.people.get(incoming_msg["data"]["personId"])
    # print(m)
    # return (m["inputs"]["NameVal"])
    fill = m["inputs"]
    print(fill)
    name = fill.get('NameVal')
    customer = fill.get('CustomerVal')
    vertical = fill.get('VerticalVal')
    portfolio = fill.get('Portfolio')

    CLIENT_ID = "955ea53b-9c37-4538-af15-a4615deb192e"
    TENANT_ID = "5ae1af62-9505-4097-a69a-c1553ef7840e"
    CLIENT_SECRET = "SrRK742IRtNj0/MW7ekEMdT7X+/7O12vYiukA82jwSc="
    AUTH_URL = "https://accounts.accesscontrol.windows.net/" + \
        TENANT_ID + "/tokens/OAuth/2"
    BASEURL = "https://cisco.sharepoint.com/sites/UKICommercialSE"

    body = {
        'grant_type': 'client_credentials',
        'client_secret': CLIENT_SECRET,
        'client_id': CLIENT_ID + "@" + TENANT_ID,
        'resource': '00000003-0000-0ff1-ce00-000000000000/cisco.sharepoint.com@5ae1af62-9505-4097-a69a-c1553ef7840e'
    }
    response = requests.post(url=AUTH_URL, data=body)

    bearer_token = json.dumps(response.json(), indent=4)
    bearer_token = json.loads(bearer_token)
    BEARER_TOKEN = bearer_token["access_token"]

    site_url = "/_api/web/GetFolderByServerRelativeUrl('Account%20Heatmaps')/Files"

    headers = {
        'Authorization': "Bearer " + BEARER_TOKEN,
        'Accept': "application/json;odata=verbose"
    }
    response = requests.get(url=f'{BASEURL}{site_url}', headers=headers)
    documentId = json.dumps(response.json(), indent=4)
    documentId = json.loads(documentId)

    for index in documentId['d']['results']:
        FOLDER_ID = index['Name']
        se_name = index['Name'].split(' ')[0]
        print(FOLDER_ID)
        if name == se_name:
            file_url = "/_api/web/GetFolderByServerRelativeUrl('Account%20Heatmaps')/Files('" + \
                FOLDER_ID + "')/$value"
            response = requests.get(
                f"{BASEURL}{file_url}", headers=headers)
            modded = response.content.strip()
            wb = load_workbook(filename=(io.BytesIO(modded)), data_only=True)
            print(wb.sheetnames)
            ws = wb[se_name]

    keys = ['AM', 'SAVID', 'Vertical', 'Customer', 'Sites', 'Employees', 'EA', 'Switching', 'Routing', 'Wireless', 'IOT/Edge', 'DNAC', 'DNA Spaces', 'SDWAN', 'Firewalls', 'Network',
            'Web/Cloud', 'Email', 'Endpoint', 'ID+Auth', 'SecureX/CTR', 'Networking', 'Storage', 'Compute', 'CWOM', 'AppD', 'Cloud', 'Meetings', 'Teams', 'Calling', 'Endpoints', 'Contact Centre']  # creates the key values, in the same order as the data in each list

    # creates a dictionary. Pairing the data with the correct field making it easy to then search later
    dic = [dict(zip(keys, row)) for row in ws.values]
    # print(dic)
    message = str(search(dic, customer, portfolio, vertical, sender))

    # ???= str(veriticals(dic,vertical))

    response = Response()
    response.markdown = message
    return response


def search(dic, customer, portfolio, vertical, sender):
    # takes input. First trail is serching by a Key
    cust = str(customer.strip())
    port = str(portfolio)
    vert = str(vertical)

    if port == "EN":  # print all nw vertical
        for element in dic:
            if cust in str(element['Customer']):
                message = ('Switching: ' + str(element['Switching']), 'Routing: ' + str(element['Routing']), 'Wireless: ' + str(element['Wireless']), 'IOT/Edge: ' + str(
                    element['IOT/Edge']), 'DNAC: ' + str(element['DNAC']), 'DNA Spaces: ' + str(element['DNA Spaces']), 'SDWAN: ' + str(element['SDWAN']))

    elif port == "DC":
        for element in dic:
            if cust in str(element['Customer']):
                message = ('Networking: ' + str(element['Networking']), 'Storage: ' + str(element['Storage']), 'Compute: ' + str(
                    element['Compute']), 'CWOM: ' + str(element['CWOM']), 'AppD: ' + str(element['AppD']), 'CLoud: ' + str(element['Cloud']))

    elif port == "Sec":
        for element in dic:
            if cust in str(element['Customer']):
                message = ('Firewalls: ' + str(element['Firewalls']), 'Network: ' + str(element['Network']), 'Web/Cloud: ' + str(element['Web/Cloud']), 'Email: ' + str(
                    element['Email']), 'Enpoint: ' + str(element['Endpoint']), 'ID+Auth: ' + str(element['ID+Auth']), 'SecureX/CTR: ' + str(element['SecureX/CTR']))

    elif port == "Col":
        for element in dic:
            if cust in str(element['Customer']):
                message = ('Meetings: ' + str(element['Meetings']), 'Teams: ' + str(element['Teams']), 'Calling: ' + str(
                    element['Calling']), 'Endpoints: ' + str(element['Endpoints']), 'Contact Centre: ' + str(element['Contact Centre']))

    elif port == "ALL":  # print everything if no vetical is entered
        # print([element for element in dic if element['Customer'] == cust])
        print("Creating Message")
        print(len(dic))
        print(cust)
        for x in range(0, len(dic)):
            if (str(dic[x]['Customer']).strip()) == cust:
                print("Found ", cust)
                message = dic[x]
                found = True
            else:
                print(dic[x]['Customer'], ' is not = to ', cust)
        #message = ([element for element in dic if cust in str(element['Customer'])])
        with open(f'{cust}_Search.csv', 'w') as f:  # You will need 'wb' mode in Python 2.x
            w = csv.DictWriter(f, message.keys())
            w.writeheader()
            w.writerow(message)
        # with open('data.csv', 'w') as f:
        #     for i in range(len(message)):
        #         output = f.write("%s, %s\n" % (i, message[i]))
        x = ("Here's the CSV you requested, "+sender.firstName+": ")
        print(x)
        sender_email = (sender.emails[0])
        m = MultipartEncoder({'toPersonEmail': sender_email, 'text': x, 'files': (
            f'{cust}_Search.csv', open(f'{cust}_Search.csv', 'rb'), 'application/csv')})
        print(m)
        r = requests.post('https://webexapis.com/v1/messages', data=m,
                          headers={'Authorization': 'Bearer ' + auth_token,
                                   'Content-Type': m.content_type})
        print(r.text)

    else:  # else if other fields are blank and its just vertical and name entered
        v = ""
        for element in dic:
            if element['Vertical'] == vert:
                # will iterate and add names to a string v
                v += element['Customer']+", "
        message = v  # this list of customers is then sent to the user
        # print(v)
    return message


def botgreeting(incoming_msg):

    sender = bot.teams.people.get(incoming_msg.personId)

    response = Response()
    # welome message
    response.markdown = "Hi {}, CommercialSheet Bot here, Please fill in the form ".format(
        sender.firstName)
    return response

# Set the bot greeting.

# Add new commands to the bot.


bot.add_command("/showcard", "show an adaptive card", show_card)
bot.add_command('attachmentActions', '*', handle_cards)

# Every bot includes a default "/echo" command.  You can remove it, or any
# other command with the remove_command(command) method.
bot.remove_command("/echo")


bot.set_greeting(botgreeting)

if __name__ == "__main__":
    # Run Bot
    bot.run()
