#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Copyright (c) 2020 Cisco and/or its affiliates.
This software is licensed to you under the terms of the Cisco Sample
Code License, Version 1.1 (the "License"). You may obtain a copy of the
License at
               https://developer.cisco.com/docs/licenses
All use of the material herein must be in accordance with the terms of
the License. All rights not expressly granted by the License are
reserved. Unless required by applicable law or agreed to separately in
writing, software distributed under the License is distributed on an "AS
IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express
or implied.
"""


__author__ = "Josh Ingeniero <jingenie@cisco.com>"
__copyright__ = "Copyright (c) 2020 Cisco and/or its affiliates."
__license__ = "Cisco Sample Code License, Version 1.1"


import cli


URL = 'http://192.168.3.1:8080/log'


print "\n\n *** Running Day0 ZTP Script *** \n\n"

print "\n\n *** Executing show version *** \n\n"
cli.executep('show version')

print "\n\n *** Change Hostname *** \n\n"
cli.configurep('hostname Router1')

print "\n\n *** Configuring the Management Interface *** \n\n"
cli.configurep(["interface GigabitEthernet1", "ip address dhcp", "vrf forwarding Mgmt-intf", "shut", "no shut", "end"])

print "\n\n *** Setup SSH *** \n\n"
cli.configurep(["username cisco privilege 15 password cisco",
                "line vty 0 15", "login local",
                "transport input all", "end"])

print "\n\n *** Configuring Loopback Interfaces *** \n\n"
cli.configurep(["interface loop 100", "ip address 10.10.10.100 255.255.255.255", "end"])
cli.configurep(["interface loop 200", "ip address 10.10.10.200 255.255.255.255", "end"])

print "\n\n *** Executing show ip interface brief *** \n\n"
cli.executep('show ip int brief')

print "\n\n *** Configuring DHCP Pool *** \n\n"
cli.configurep(["interface GigabitEthernet3", "ip address 192.168.5.1 255.255.255.0", "shut", "no shut", "end"])
cli.configurep(["ip dhcp excluded-address 192.168.5.1 192.168.5.10", "end"])
cli.configurep(["ip dhcp pool Clients", "network 192.168.5.0 255.255.255.0",
                "default-router 192.168.5.1", "dns-server 192.168.0.1", "end"])

print "\n\n *** Check DHCP Bindings *** \n\n"
cli.executep("show ip dhcp binding")

print "\n\n *** Enable RESTCONF/NETCONF *** \n\n"
cli.configurep(["ip http secure-server", "restconf", "netconf-yang", "ip http server"])

print "\n\n *** Printing show run and sending *** \n\n"
cli.executep('show run')
cli.executep('copy run %s' % URL)

print "\n\n *** ZTP Day0 Python Script Execution Complete *** \n\n"