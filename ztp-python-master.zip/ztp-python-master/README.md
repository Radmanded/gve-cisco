# ZTP Essential Setup
Providing the essential scripts for running a ZTP server for Day 0 provisioning of Cisco IOS XE devices.
A Flask server provides the HTTP server for hosting the ZTP script and receiving logs from the device.
Tested on a VMWare Fusion setup with Ubuntu Server as the ZTP Server, CSR1000v as the IOS XE device, and Alpine Linux
as a client device.

This will achieve the following Day 0 Configurations
* Configure Hostname
* Configure Management Interface
* Setup SSH
* Configure Loopback
* Configure DHCP Pool
* Enable RESTCONF and NETCONF


| :exclamation:  External repository notice   |
|:---------------------------|
| This repository is now mirrored at "PLEASE UPDATE HERE - add External repo URL after code review is completed"  Please inform a https://github.com/gve-sw/ organization admin of any changes to mirror them to the external repo |

### High Level Design

![High Level Design](IMAGES/design.png)


## Contacts
* Josh Ingeniero (jingenie@cisco.com)
* Monica Acosta (moacosta@cisco.com)

## Solution Components
* Flask
* Python
* VMWare Fusion
* Ubuntu
* Alpine Linux
* Cisco IOS-XE Guest Shell

# Installation

#### Clone the repo
```console
$ git clone https://wwwin-github.cisco.com/gve/ztp-python.git
```

#### Download images
The topology for this requires a Linux VM to act as a ZTP server, a Cisco IOS XE device image, 
and another Linux VM to act as the client. The following images were used:
* Ubuntu Server 20.04 LTS for DHCP/ZTP
* CSR1000v IOS XE Amsterdam-17.2.2 Image as the device to be provisioned
* Alpine Linux Virtual 3.12.1 as a DHCP client for testing


## Setup and Usage
### VMWare Fusion Topology
![Topology](IMAGES/topology.png)

You must create the following VNET's in VMWare Fusion or Workstation and prevent automatic DHCP IP address allocation:
* LAB - connects the device to the ZTP/DHCP server
* MGT - management network for the device
* Clients - client network where the device should run a DHCP server


### ZTP Server
Configure the Ubuntu Server Networking as follows
* Network Adapter 1 - Shared with your PC/Mac
* Network Adapter 2 - Connected to LAB VNET

Install and setup Ubuntu Server 20.04 LTS with your desired settings, do not use cloud-init.

#### Interface Configuration
You have to ensure that both network adapters are seen and configured in Ubuntu. Verify this with _ifconfig_.
```commandline
$ ifconfig
ens32: flags=4163<UP,BROADCAST,RUNNING,MULTICAST>  mtu 1500
        inet 192.168.109.129  netmask 255.255.255.0  broadcast 192.168.109.255
        inet6 fe80::20c:29ff:fea7:c59e  prefixlen 64  scopeid 0x20<link>
        ether 00:0c:29:a7:c5:9e  txqueuelen 1000  (Ethernet)
        RX packets 54347  bytes 78191447 (78.1 MB)
        RX errors 0  dropped 0  overruns 0  frame 0
        TX packets 9665  bytes 709051 (709.0 KB)
        TX errors 0  dropped 0 overruns 0  carrier 0  collisions 0

ens33: flags=4163<UP,BROADCAST,RUNNING,MULTICAST>  mtu 1500
        inet 192.168.3.1  netmask 255.255.255.0  broadcast 192.168.3.255
        inet6 fe80::20c:29ff:fea7:c5a8  prefixlen 64  scopeid 0x20<link>
        ether 00:0c:29:a7:c5:a8  txqueuelen 1000  (Ethernet)
        RX packets 0  bytes 0 (0.0 B)
        RX errors 0  dropped 0  overruns 0  frame 0
        TX packets 44  bytes 3272 (3.2 KB)
        TX errors 0  dropped 0 overruns 0  carrier 0  collisions 0

lo: flags=73<UP,LOOPBACK,RUNNING>  mtu 65536
        inet 127.0.0.1  netmask 255.0.0.0
        inet6 ::1  prefixlen 128  scopeid 0x10<host>
        loop  txqueuelen 1000  (Local Loopback)
        RX packets 300  bytes 25987 (25.9 KB)
        RX errors 0  dropped 0  overruns 0  frame 0
        TX packets 300  bytes 25987 (25.9 KB)
        TX errors 0  dropped 0 overruns 0  carrier 0  collisions 0
```

In this _ifconfig_ output, ens32 is Adapter #1 and ens33 is Adapter #2. ens32 is configured as our internet access/connectivity
interface and is shared via my PC, while ens33 is configured as the interface for DHCP/ZTP on the LAB network.
If the interfaces are not available, you must enable them. You may refer to the following or this [guide](https://www.computerhope.com/unix/uifconfi.htm).

```commandline
# Check for interfaces
$ ifconfig -a

# Enable an interface
$ sudo ifconfig [interface_name] up
```

Once the interfaces are up, you must configure the LAB-facing interface with a static IP address according to this 
[guide](https://www.linuxtechi.com/assign-static-ip-address-ubuntu-20-04-lts/). You will have to edit your netplan with
a similar configuration as [00-installer-config.yaml](configuration/00-installer-config.yaml)

```yaml
# /etc/netplan/00-installer-config.yaml
# This is the network config written by 'subiquity'
network:
  ethernets:
    ens32:
      dhcp4: true
    ens33:
      addresses: [192.168.3.1/24]
      dhcp4: false
      nameservers:
        addresses: [8.8.8.8]
  version: 2
```

Then run
```commandline
# Apply netplan
$ sudo netplan apply

# Verify interfaces
$ ifconfig
```


#### DHCP Configuration
You will then proceed to install a DHCP server
and configure it according to this [guide](https://devtutorial.io/how-to-setup-dhcp-server-in-ubuntu-server-20-04.html)
You may use the [dhcpd.conf](configuration/dhcpd.conf) for the DHCP server configuration. You may change the following lines:
at the end of the file
```

subnet 192.168.3.0 netmask 255.255.255.0 {
        range 192.168.3.10 192.168.3.100;
        option routers                  192.168.3.1;
        option subnet-mask              255.255.255.0;
        option domain-name-servers      192.168.3.1, 8.8.8.8;
        option bootfile-name "http://192.168.3.1:8080/file/script.py";
}

```
This configures the server to assign addresses to the _192.168.3.0/24_ network from .10 to .100,
points the ZTP and DNS servers to the Ubuntu server, and the script to the specific URL endpoint.

#### ZTP Server Configuration
Finally, you will then set up the ZTP Server running on a Flask Python environment. You need to verify
the installed python and install pip.

```commandline
# Update repositories
$ sudo apt update
$ sudo apt -y upgrade

# Verify python version
$ python3 -V

# Install pip
$ sudo apt install -y python3-pip
```

Then, you have to use SFTP to copy the [ztp-server](ztp-server) folder and files to the server. You may use
WinSCP for Windows or Cyberduck on Mac, or any FTP client to copy the files. You may also opt to clone the repository
in the Ubuntu server filesystem. Once you have the files ready, you may change the current configuration script
found in [script.py](ztp-server/script.py), install the required packages and run the server

```commandline
# Install required packages
$ cd ztp-server
ztp-server$ pip3 install -r requirements.txt
```

```python
# Cisco IOS XE Configuration Script
import cli


URL = 'http://192.168.3.1:8080/log'


print "\n\n *** Running Day0 ZTP Script *** \n\n"

print "\n\n *** Executing show version *** \n\n"
cli.executep('show version')

print "\n\n *** Change Hostname *** \n\n"
cli.configurep('hostname Router1')

print "\n\n *** Configuring the Management Interface *** \n\n"
cli.configurep(["interface GigabitEthernet1", "ip address dhcp", "vrf forwarding Mgmt-intf", "shut", "no shut", "end"])

print "\n\n *** Setup SSH *** \n\n"
cli.configurep(["username cisco privilege 15 password cisco",
                "line vty 0 15", "login local",
                "transport input all", "end"])

print "\n\n *** Configuring Loopback Interfaces *** \n\n"
cli.configurep(["interface loop 100", "ip address 10.10.10.100 255.255.255.255", "end"])
cli.configurep(["interface loop 200", "ip address 10.10.10.200 255.255.255.255", "end"])

print "\n\n *** Executing show ip interface brief *** \n\n"
cli.executep('show ip int brief')

print "\n\n *** Configuring DHCP Pool *** \n\n"
cli.configurep(["interface GigabitEthernet3", "ip address 192.168.5.1 255.255.255.0", "shut", "no shut", "end"])
cli.configurep(["ip dhcp excluded-address 192.168.5.1 192.168.5.10", "end"])
cli.configurep(["ip dhcp pool Clients", "network 192.168.5.0 255.255.255.0",
                "default-router 192.168.5.1", "dns-server 192.168.0.1", "end"])

print "\n\n *** Check DHCP Bindings *** \n\n"
cli.executep("show ip dhcp binding")

print "\n\n *** Enable RESTCONF/NETCONF *** \n\n"
cli.configurep(["ip http secure-server", "restconf", "netconf-yang", "ip http server"])

print "\n\n *** Printing show run and sending *** \n\n"
cli.executep('show run')
cli.executep('copy run %s' % URL)

print "\n\n *** ZTP Day0 Python Script Execution Complete *** \n\n"
```

```commandline
# Run the server
ztp-server$ python3 server.py
```


### Router
You would need the CSR1000v IOS XE Amsterdam-17.2.2 Image, which you can download from [software.cisco.com](software.cisco.com)
which we will run with unlicensed for testing purposes. Import the image into VMWare Fusion with the following
settings. These steps would be similar for VMWare Workstation.

![/IMAGES/router1.png](IMAGES/router1.png)

Make sure that all fields in _Bootstrap Properties_ are empty, and everything else is set to the default
settings.

![/IMAGES/router2.png](IMAGES/router2.png)

Proceed to import the image then click Finish, and immediately shutdown the VM.

![/IMAGES/router3.png](IMAGES/router3.png)

You will then edit the Network Adapters 1 to 3, add additional ones if needed.

![/IMAGES/router4.png](IMAGES/router4.png)

Use the following Network Configurations:

| Network Adapter  | VNET |
| ------------- | ------------- |
| Adapter 1  | MGT  |
| Adapter 2  | LAB  |
| Adapter 3  | Clients  |

![/IMAGES/router5.png](IMAGES/router5.png)

Afterwards, you can proceed to run the Router. Do not touch or press any keys during the process,
as that might interrupt the automatic ZTP process.

![/IMAGES/router6.png](IMAGES/router6.png)

Router starting the ZTP process.

Once the router has finished the ZTP process, you may verify the configuration with _show run_ or use the logging
feature of the ZTP server. Run the following command to save a [log.txt](ztp-server/log.txt) file with the current
running configuration on the ZTP server filesystem.

```commandline
Router> en
Router# show run
Router# copy run http://192.168.3.1:8080/log
```

```commandline
! Running Config

!
! Last configuration change at 02:31:39 UTC Tue Nov 3 2020
!
version 17.2
service timestamps debug datetime msec
service timestamps log datetime msec
! Call-home is enabled by Smart-Licensing.
service call-home
platform qfp utilization monitor load 80
platform punt-keepalive disable-kernel-core
platform console virtual
!
hostname Router1
!
boot-start-marker
boot-end-marker
!
!
!
no aaa new-model
!
!
!
!
!
!
!
ip dhcp excluded-address 192.168.5.1 192.168.5.10
!
ip dhcp pool Clients
 network 192.168.5.0 255.255.255.0
 default-router 192.168.5.1 
 dns-server 192.168.0.1 
!
!
!
login on-success log
!
!
!
!
!
!
!
subscriber templating
! 
! 
! 
! 
!
!
multilink bundle-name authenticated
!
!
!
!
!
!
!
!
!
!
!
!
!
!
!
crypto pki trustpoint SLA-TrustPoint
 enrollment pkcs12
 revocation-check crl
!
crypto pki trustpoint TP-self-signed-3155344967
 enrollment selfsigned
 subject-name cn=IOS-Self-Signed-Certificate-3155344967
 revocation-check none
 rsakeypair TP-self-signed-3155344967
!
!
crypto pki certificate chain SLA-TrustPoint
 certificate ca 01
  30820321 30820209 A0030201 02020101 300D0609 2A864886 F70D0101 0B050030 
  32310E30 0C060355 040A1305 43697363 6F312030 1E060355 04031317 43697363 
  6F204C69 63656E73 696E6720 526F6F74 20434130 1E170D31 33303533 30313934 
  3834375A 170D3338 30353330 31393438 34375A30 32310E30 0C060355 040A1305 
  43697363 6F312030 1E060355 04031317 43697363 6F204C69 63656E73 696E6720 
  526F6F74 20434130 82012230 0D06092A 864886F7 0D010101 05000382 010F0030 
  82010A02 82010100 A6BCBD96 131E05F7 145EA72C 2CD686E6 17222EA1 F1EFF64D 
  CBB4C798 212AA147 C655D8D7 9471380D 8711441E 1AAF071A 9CAE6388 8A38E520 
  1C394D78 462EF239 C659F715 B98C0A59 5BBB5CBD 0CFEBEA3 700A8BF7 D8F256EE 
  4AA4E80D DB6FD1C9 60B1FD18 FFC69C96 6FA68957 A2617DE7 104FDC5F EA2956AC 
  7390A3EB 2B5436AD C847A2C5 DAB553EB 69A9A535 58E9F3E3 C0BD23CF 58BD7188 
  68E69491 20F320E7 948E71D7 AE3BCC84 F10684C7 4BC8E00F 539BA42B 42C68BB7 
  C7479096 B4CB2D62 EA2F505D C7B062A4 6811D95B E8250FC4 5D5D5FB8 8F27D191 
  C55F0D76 61F9A4CD 3D992327 A8BB03BD 4E6D7069 7CBADF8B DF5F4368 95135E44 
  DFC7C6CF 04DD7FD1 02030100 01A34230 40300E06 03551D0F 0101FF04 04030201 
  06300F06 03551D13 0101FF04 05300301 01FF301D 0603551D 0E041604 1449DC85 
  4B3D31E5 1B3E6A17 606AF333 3D3B4C73 E8300D06 092A8648 86F70D01 010B0500 
  03820101 00507F24 D3932A66 86025D9F E838AE5C 6D4DF6B0 49631C78 240DA905 
  604EDCDE FF4FED2B 77FC460E CD636FDB DD44681E 3A5673AB 9093D3B1 6C9E3D8B 
  D98987BF E40CBD9E 1AECA0C2 2189BB5C 8FA85686 CD98B646 5575B146 8DFC66A8 
  467A3DF4 4D565700 6ADF0F0D CF835015 3C04FF7C 21E878AC 11BA9CD2 55A9232C 
  7CA7B7E6 C1AF74F6 152E99B7 B1FCF9BB E973DE7F 5BDDEB86 C71E3B49 1765308B 
  5FB0DA06 B92AFE7F 494E8A9E 07B85737 F3A58BE1 1A48A229 C37C1E69 39F08678 
  80DDCD16 D6BACECA EEBC7CF9 8428787B 35202CDC 60E4616A B623CDBD 230E3AFB 
  418616A9 4093E049 4D10AB75 27E86F73 932E35B5 8862FDAE 0275156F 719BB2F0 
  D697DF7F 28
  	quit
crypto pki certificate chain TP-self-signed-3155344967
 certificate self-signed 01
  30820330 30820218 A0030201 02020101 300D0609 2A864886 F70D0101 05050030 
  31312F30 2D060355 04031326 494F532D 53656C66 2D536967 6E65642D 43657274 
  69666963 6174652D 33313535 33343439 3637301E 170D3230 31313033 30323330 
  32365A17 0D333030 31303130 30303030 305A3031 312F302D 06035504 03132649 
  4F532D53 656C662D 5369676E 65642D43 65727469 66696361 74652D33 31353533 
  34343936 37308201 22300D06 092A8648 86F70D01 01010500 0382010F 00308201 
  0A028201 0100B1DE A96DADB7 B95B34D8 BD9097E4 14BC687E BEB0BE67 2A56D3A8 
  55CF85EF 49C98897 18FF8B46 A94FBC86 A456D221 5165BCC5 A028C5CC 92222C38 
  DC9B6F51 051D7F38 3DE71A5C 2DBC132E 9B280ADF 55E2265C 431424E9 0C0B8568 
  74DAB846 F7DB6487 88B3C936 99C0AA2E 88C59ABC ACBF2C68 B737BF4A 4504FF2E 
  9D086DB3 15D837AD BE515CF3 5B9D454E 4A9F85F4 0D603BC1 0D9BA064 14D3E13A 
  44EE9032 4E78E7FE 5E2784FB 9FD18FE9 9DEB8AF3 D063627F 4BA57D81 10A8FCD6 
  39880DE6 896F6D6C C82D792C FBEB1790 34A9EE36 728247DE F46C4922 7970DD27 
  C9FFC2E5 D6AB4E65 42685184 939FAE14 98095085 5C60FB79 8E96E0DE 63486F90 
  9F479B62 08A70203 010001A3 53305130 0F060355 1D130101 FF040530 030101FF 
  301F0603 551D2304 18301680 14F69871 20CF7686 5087F958 6CA82E93 CB196E63 
  10301D06 03551D0E 04160414 F6987120 CF768650 87F9586C A82E93CB 196E6310 
  300D0609 2A864886 F70D0101 05050003 82010100 264D1E65 65AC0A75 261BBA99 
  66AB124C 68DB2970 61D05876 ED6401B3 AF1D6CDE D6549E64 FEAF58B1 67DAA0FB 
  227F0B12 C377DF99 A0E01D07 F54DB44E 104F4ECF 6CCF03E6 5CBF116B 55CB2998 
  3E94C45B 0244DF78 C202DD82 51231B1C 3054E9F2 999E73BD 904966E1 3854E702 
  1D001D25 00051265 23FAFC1A 228D42F6 065E3287 BD2DEAA8 C1F1F37F E8255748 
  B312B33E D19283E3 E70BBAAE 56BBAEA2 544657C1 5CE7C6A0 F85F79C4 5B646FA5 
  51C930F3 918B1290 DACBB62F 57A1E10A DE2AAD3E AD5CE991 61596F61 E6853777 
  A4379C59 3DE5FB97 586D3147 548E046B 24E2D1A0 7121AB3B 5BA0CB66 4A58B704 
  C018CCA2 D04EF0B9 8B156AB8 F424E01C EFD24763
  	quit
!
license udi pid CSR1000V sn 92WWKOCFBDP
diagnostic bootup level minimal
memory free low-watermark processor 71862
!
!
spanning-tree extend system-id
!
username cisco privilege 15 password 0 cisco
!
redundancy
!
!
!
!
!
!
!
! 
!
!
!
!
!
!
!
!
!
!
!
!
!
! 
! 
!
!
interface Loopback100
 ip address 10.10.10.100 255.255.255.255
!
interface Loopback200
 ip address 10.10.10.200 255.255.255.255
!
interface GigabitEthernet1
 ip address dhcp
 negotiation auto
 no mop enabled
 no mop sysid
!
interface GigabitEthernet2
 ip dhcp client client-id ascii cisco-000c.2925.cd56-Gi2
 ip address dhcp
 negotiation auto
 no mop enabled
 no mop sysid
!
interface GigabitEthernet3
 ip address 192.168.5.1 255.255.255.0
 negotiation auto
 no mop enabled
 no mop sysid
!
ip forward-protocol nd
ip http server
ip http authentication local
ip http secure-server
ip http client source-interface GigabitEthernet2
!
ip nat inside source list NAT_ACL interface GigabitEthernet2 overload
ip tftp source-interface GigabitEthernet2
!
ip access-list standard NAT_ACL
 10 permit 192.168.0.0 0.0.255.255
!
!
!
!
!
!
!
control-plane
!
!
!
!
!
!
line con 0
 stopbits 1
line vty 0 4
 login local
 length 0
 transport input all
line vty 5 15
 login local
 length 0
 transport input all
!
call-home
 ! If contact email address in call-home is configured as sch-smart-licensing@cisco.com
 ! the email address configured in Cisco Smart License Portal will be used as contact email address to send SCH notifications.
 contact-email-addr sch-smart-licensing@cisco.com
 profile "CiscoTAC-1"
  active
  destination transport-method http
!
!
!
!
!
!
netconf-yang
restconf
end

```

### Client
To verify the DHCP server on the router or ZTP/DHCP server, you can run a VM acting as the client. Download 
Alpine Linux Virtual 3.12.1 to use as a lightweight client. Create a new VM in VMWare using the ISO and configure
the Network Adapter to connect to the VNET LAB or Clients, depending on which DHCP server you want to check.

![/IMAGES/client1.png](IMAGES/client1.png)

You will then have to boot up the VM and run _setup-alpine_ with your preferred settings, until you reach DHCP.
You can verify if the DHCP server is running and is providing IP addresses by checking the returned IP
address by udhcpc.

```commandline
udhcpc: started, v1.31.1
udhcpc: sending discover
udhcpc: sending discover
udhcpc: sending select for 192.168.5.11
udhcpc: lease of 192.168.5.11 obtained, lease time 86400
```


![/IMAGES/0image.png](IMAGES/0image.png)

### LICENSE

Provided under Cisco Sample Code License, for details see [LICENSE](LICENSE.md)

### CODE OF CONDUCT

Our code of conduct is available [here](CODE_OF_CONDUCT.md)

### CONTRIBUTING

See our contributing guidelines [here](CONTRIBUTING.md)

#### DISCLAIMER:
<b>Please note:</b> This script is meant for demo purposes only. All tools/ scripts in this repo are released for use "AS IS" without any warranties of any kind, including, but not limited to their installation, use, or performance. Any use of these scripts and tools is at your own risk. There is no guarantee that they have been through thorough testing in a comparable environment and we are not responsible for any damage or data loss incurred with their use.
You are responsible for reviewing and testing any scripts you run thoroughly before use in any non-testing environment.