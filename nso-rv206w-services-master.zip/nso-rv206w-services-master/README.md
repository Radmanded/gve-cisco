# **NSO PROJECT DOCUMENTATION**

This document describes different procedures that have been done in order to configure a RV206W Cisco router from NSO platform.

|Version|    Date    |   Author   |
|-------|------------|------------|
|  1.0  | 21-02-2020 |  mgarcia4  |
|-------|------------|------------|
|  1.1  | 02-03-2020 |  mgarcia4  |
|-------|------------|------------|
|  1.2  | 30-03-2020 |  nchiarap  |
|-------|------------|------------|
|  1.3  | 05-04-2020 |  seberhar  |
|-------|------------|------------|
|  1.4  | 17-04-2020 |  nchiarap  |
|-------|------------|------------|
|  1.5  | 20-04-2020 |  mgarcia4  |
|-------|------------|------------|
|  1.6  | 05-05-2020 |  seberhar  |
|-------|------------|------------|
|  1.7  | 08-05-2020 |  mgarcia4  |
|-------|------------|------------|
|  1.8  | 11-05-2020 |  nchiarap  |

***

## **CONTENT OF THE DOCUMENT**

1. [Access credentials (Madrid Lab)](#1-access-credentials-madrid-lab)
2. [Documentation's format and commands](#2-documentations-format-and-commands)
3. [Connect a device to NSO (NETCONF device)](#3-connect-a-device-to-nso-netconf-device)
4. [Create new NSO service (general example)](#4-create-new-nso-service-general-example)
5. [Service creation for Cisco router model rv260w](#5-service-creation-for-cisco-router-model-rv260w)

      5.1 SSID service

      5.2 Content filtering service

      5.3 NTP service

      5.4 Static WAN service

      5.5 Static IPv4 route service

6. [Service creation with Python API](#6-service-creation-python)
7. [Service creation with Python and XML template](#7-service-creation-with-python-and-xml-template)
8. [Services Stack](#8-services-stack)

  ***

##  **1. ACCESS CREDENTIALS (MADRID LAB)**

These credentials are private. In order to access a laboratory if you need one, please contact us. 

***

## **2. DOCUMENTATION'S FORMAT AND COMMANDS**

### 2.1 Document format
In order to understand where the commands should be run, let's make the same assumptions:

  - `$ command`: running from the terminal at ncs/nso directory
  - `# command`: running from ncs cli. You can access with the following command:

      `$ ncs_cli -u admin -C`
  - `(config)# command`: running from ncs config mode. You can access with the following command:

      `# config`

### 2.2 Some useful commands

Every time you add a new package to NSO it is necessary to reload it. There are to ways to do so:

1. Exiting NCS:
~~~~
# ncs --stop
# ncs --with-package-reload
~~~~
2. Without exiting NCS:
~~~~
# package reload
~~~~

***

## **3. CONNECT A DEVICE TO NSO (NETCONF DEVICE)**

In this section we will set up the connectivity of NSO with the device.

  1. Set up connection
  2. Connect the device
  3. Synchronize configuration between NSO DB and the device

Prerequisites that you will need to perform this task:

  - Device user
  - Device password
  - Device ip address
  - Device port

### 3.1 Set up the connection

1. Create the proper authorization group in NSO with the credentials to access the device

Configure new authgroup with the following parameters:
  - group: rv-group
  - remote-name: cisco
  - remote-password: admin

~~~
(config)# devices authgroups group rv-group default-map remote-name \
          cisco remote-password admin
(config-group-rv-group)# commit
(config)# exit
~~~

This command will show the current configured authgroups
~~~
(config)# show full-configuration devices authgroups
~~~
Output of the command:
~~~
devices authgroups group default
umap admin
remote-name     admin
remote-password $8$wPJNnorFQPv9yuuyewJ43tBUENr67h4NpvCDUgXCBSg=
!
umap oper
remote-name     oper
remote-password $8$i9vSrNZh2QRXkmIvKQI9n5DzJkzw1aovV+yvJxkjYCY=
!
!
devices authgroups group rv-group
default-map remote-name cisco
default-map remote-password $8$7+w7BanBN8hMsIXi0WHSq1TthL+BZlY4DqLgYwoZvDs=
~~~

### 3.2 Create a new device in NSO using the NED

Configure new device with the following parameters:

  - device: rv260w
  - address: 10.1.20.5
  - authgroup: rv-group
  - device-type: netconf
  - ned-id: cisco-rv260-nc-1.0.00.16

> **Note:** Before committing the change form NSO to the device, make sure to change the default admin-state to unlocked.
~~~
(config)# devices device rv260w address 10.1.20.51 port 830 authgroup \
          rv-group device-type netconf ned-id cisco-rv260-nc-1.0.00.16
(config-device-rv260w)# state admin-state unlocked
(config-device-rv260w)# commit
~~~

This command will show the current devices in NSO:
~~~
# show devices list
~~~
Output of the command:
~~~
NAME    ADDRESS     DESCRIPTION  NED ID                    ADMIN STATE
----------------------------------------------------------------------
rv260w  10.1.20.51  -            cisco-rv260-nc-1.0.00.16  unlocked
~~~

### 3.3 Fetch host key in order to make possible the remote connection to the device
~~~~
# devices device rv260w ssh fetch-host-keys
~~~~
The output should look like this:
~~~~
result updated
fingerprint {
    algorithm ssh-rsa
    value 86:a6:78:39:a8:a5:ec:51:ef:9a:ce:6b:19:59:2e:aa
}
~~~~

### 3.4 Connect the device to NSO
~~~~
# devices connect
~~~~
If the connection was successful it should retrieve the following output:
~~~~
connect-result {
    device rv260w
    result true
    info (admin) Connected to rv260w - 10.1.20.51:830
}
~~~~

### 3.5 Sync configuration from the physical device to NSO DB
~~~~
# devices device rv260w sync-from
~~~~
The output:
~~~~
result true
~~~~

You can always check the synchronization status with the following command
~~~~
# devices device rv260w check-sync
~~~~
If the device is sync, you will get:
~~~~
result in-sync
~~~~

***

## **4. CREATE NEW NSO SERVICE (GENERAL EXAMPLE)**

In this section we are going to create a new service. In particular a service that will change the hostname of our device. For that, we will follow the next steps:

  1. Create service package template
  2. Define the yang model
  3. Create the mapping xml file
  4. Run the service on the device from NSO

### 4.1 Create service package template

Go to `../packages` of NSO directory and create a new service template.
This time we will call the service *hostname*

~~~~
$ ncs-make-package --service-skeleton template --augment /ncs:services hostname
~~~~

### 4.2 Define the yang model

The YANG model template of the new service has been created at `../packages/hostname/src/hostname.yang`.
Modify it in order to define the parameters that should be configured when deploying this service.

In this case, the YANG model is very simple, since we just need to modify the hostname of the device. The YANG model we look like this:

~~~~
module hostname {
  namespace "http://com/example/hostname";
  prefix hostname;

  import ietf-inet-types {
    prefix inet;
  }
  import tailf-ncs {
    prefix ncs;
  }

  list hostname {
    key hostname;

    uses ncs:service-data;
    ncs:servicepoint "hostname";

    leaf hostname {
      mandatory true;
      type string;
    }

    leaf device {
      type leafref {
        path "/ncs:devices/ncs:device/ncs:name";
      }
    }

  }
}
~~~~

### 4.3 Create the mapping xml file

A new xml template file was also created when generating the skeleton of the new service. You can find this file at `../packages/hostname/templates/hostname-template.xml`.

This file will stablish the mapping between the service YANG model and the actual configuration of the device.

The easiest way to modify this xml file is to take as a model the current configuration of the device. This means that:

  1. We will export the current running-config of the device into a XML file
  2. We will extract from that file the lines that actually help us to configure our services
  3. We will copy those lines into our mapping XML and define the variables that we will take from the service YANG model

Let´s export the running-config of the device and save it into *rv260conf21022020.xml*
~~~~
# show running-config devices device rv260w config | display xml \
  | save rv260conf21022020.xml
~~~~

From the complete running-config file that we exported from the device, we keep only the lines that we will need to configure our service:
~~~~
File: "rv260conf21022020.xml"

<config xmlns="http://tail-f.com/ns/config/1.0">
  <devices xmlns="http://tail-f.com/ns/ncs">
  <device>
    <name>rv260w</name>
      <config>
        <system xmlns="urn:ietf:params:xml:ns:yang:ietf-system">
          <hostname>acifuent</hostname>
        </system>
      </config>
  </device>
  </devices>
</config>
~~~~

Copy those lines from the expored XML file into `../packages/hostname/templates/hostname-template.xml` and replace the fixed values with the variables that are defined in the YANG model of the service.

The final XML used for the mapping should look like this:
~~~~
File: "./packages/hostname/templates/hostname-template.xml"

<config-template xmlns="http://tail-f.com/ns/config/1.0"
                 servicepoint="hostname">
  <devices xmlns="http://tail-f.com/ns/ncs">
    <device>
    <name>{/device}</name>
      <config>
        <system xmlns="urn:ietf:params:xml:ns:yang:ietf-system">
          <hostname>{/hostname}</hostname>
        </system>
      </config>
  </device>
  </devices>
</config-template>
~~~~

> **Note** that in this case we basically modified the tags `<name>rv260w</name>` to `<name>{/device}</name>` and `<hostname>acifuent</hostname>` to `<hostname>{/hostname}</hostname>`. That is how we map the YANG model of the service with the device configuration.

Finally we will compile the new package of the service *hostname* running the following command from `../packages`
~~~~
$ make -C hostname/src/
~~~~
This command will return the following output:
~~~~
make: Entering directory '/home/acifuent/ncs-run/packages/hostname/src'
mkdir -p ../load-dir
/home/acifuent/ncs-5.2.1/bin/ncsc  `ls hostname-ann.yang  \
              > /dev/null 2>&1 && echo "-a hostname-ann.yang"` \
              -c -o ../load-dir/hostname.fxs yang/hostname.yang
make: Leaving directory '/home/acifuent/ncs-run/packages/hostname/src'
~~~~

Finally, reload packages at NCS
~~~~
# packages reload
~~~~

And check the status of the packages at NCS
~~~~
# show packages package * oper-status
~~~~

That should return the following output:
~~~~
PACKAGE
PROGRAM                                                        META    \
CODE     JAVA           BAD NCS  PACKAGE  PACKAGE  CIRCULAR    DATA    \
NAME                      UP  ERROR    UNINITIALIZED  VERSION  NAME    \
--------------------------------------------------------------------   \
cisco-rv260-nc-1.0.00.16  X   -        -              -        -       \
hostname                  X   -        -              -        -       \

FILE
LOAD   ERROR
VERSION  DEPENDENCY  ERROR    ERROR  INFO
------------------------------------------------
 -        -           -        -      -
 -        -           -        -      -
~~~~

### 4.4 Run the service on the device from NSO

After enabling the service in NCS, we can run the following command to apply the service to our device. As parameters we will define:

  - hostname: router1
  - device: rv260w

~~~~
(config)# hostname router1 device rv260w
~~~~

It is possible to check the changes that will be applied on the configuration with this command:
~~~~
(config-hostname-router1)# commit dry-run
~~~~

The output will look like this:
~~~~
cli {
    local-node {
        data  devices {
                  device rv260w {
                      config {
                          sys:system {
             -                hostname acifuent;
             +                hostname router1;
                          }
                      }
                  }
              }
             +hostname router1 {
             +    device rv260w;
             +}
    }
}
~~~~

If everything it's okay, you can definitely commit the new config to the device.
~~~~
(config-hostname-router1)# commit
~~~~

Check if both the configuration at the device and in NSO are sync
~~~~
# devices device rv260w check-sync
result in-sync
~~~~

***

## **5. Service creation for Cisco router model rv260w**

In this section we will detail the creation of different services that will enable configuration via NSO of a Cisco rv260 router.
For the following services you will be able to find:

- YANG model
- XML mapping FILE
- Service execution on the lab's router
- Screenshots from the web GUI of the router showing results

***

### 5.1 SSID service

Description:

This service will deploy the wireless LAN in the RV260 model. Due to the
configuration's constrains of this model, multiple settings should be defined
when creating a new SSID. In order to make easier to understand the way the YANG
model of the service was defined we can mention three main blocks of configuration:

1. WLANS: It defines the new WLAN that we created.
  - ssid
  - radio-mode
  - password
  - vlan-id

2. Interfaces: The definition of a new VLAN for the SSID implies extra configuration in the existing interfaces, as well as the definition of a new interface section for the new VLAN. In the definition of the VLAN it is also necessary to specify:
- IPv4 address
- IPV4 network mask
- IPV6 prefix

3.  Routing: since a new VLAN has been added, it is also necessary to define it in the routing instances of the router. For that we will set up default values in order to simplify the service definition.

> ***Important note:*** for simplification reasons there are multiple parameters that are set up as default. The service yang model could be also modified in order to make possible the manual configuration of those parameters. However, it will be more interesting to set those values once we are able to run the service in python (it gives more flexibility and it is easier to program).

#### 5.1.2 SSID service YANG model

This is the service yang model:
~~~~
module ssid {
  namespace "http://com/example/ssid";
  prefix ssid;

  import ietf-inet-types {
    prefix inet;
  }
  import tailf-ncs {
    prefix ncs;
  }

  list ssid {
    key ssid;

    uses ncs:service-data;
    ncs:servicepoint "ssid";

    leaf ssid {
      mandatory true;
      type string;

    }

    leaf device {
      type leafref {
        path "/ncs:devices/ncs:device/ncs:name";
      }
    }

    leaf radio-mode {
      type enumeration{
        enum BOTH {
          description "Both 2.4Ghz and 5Ghz are active";
        }
        enum WLAN0 {
          description "Only 5Ghz is active";
        }
        enum WLAN1 {
          description "Only 2.4Ghz is active";
        }
      }
    }

    leaf password {
      mandatory true;
      type string;
    }

    leaf vlan-id {
      mandatory true;
      type uint16;
    }

    leaf ipv4-addr{
      type inet:ipv4-address;
    }

    leaf ipv4-netmask{
      type inet:ipv4-address;
    }

    leaf ipv6-prefix{
      type string;
      description "IPv6 address prefix(default prefix of /64)";
    }
  }
}
~~~~

Let's analyze the different parameters that we will need to enter when defining the service for a particular SSID.

The ssid is a string and is a mandatory value. We also need to define to which device we want to apply this new configuration.
~~~~
leaf ssid {
  mandatory true;
  type string;
}

leaf device {
  type leafref {
    path "/ncs:devices/ncs:device/ncs:name";
  }
}
~~~~

Our router's AP is able to work at 2.4Ghz and/or 5Ghz. The radio-mode parameter will define in which mode we are going to work for this particular SSID. As you can see, only **three** values are accepted. Find their description in the YANG model definition.
~~~~
leaf radio-mode {
  type enumeration{
    enum BOTH {
      description "Both 2.4Ghz and 5Ghz are active";
    }
    enum WLAN0 {
      description "Only 5Ghz is active";
    }
    enum WLAN1 {
      description "Only 2.4Ghz is active";
    }
  }
}
~~~~

A password must be also defined to access the wireless network.
> ***Note:*** There are different authorization and authentication methods for the WLAN. However, in order to simplify the service definition we enabled as default **WPA2-Personal**. You will be able to see this configuration in the ***ssid-template.xml*** file showed in the next section.
~~~~
leaf password {
  mandatory true;
  type string;
}
~~~~

As said before, it is compulsory to define a VLAN for this SSID. Following the configuration that we decided for the service, the VLAN will be automatically defined in the router, with all the subsequence configuration that is needed at the interface and routing level ***check the ssid-template.xml file to understand which parameters need to be set up for VLAN definition***
~~~~
leaf vlan-id {
  mandatory true;
  type uint16;
}
~~~~

Finally, it is necessary to define the IPv4 and IPv6 address space that will be used in this vlan.
> ***Note:*** The configuration at this point is very basic in order to simplify the service definition. We suggest to generate a service defined in python in order to automatically assig values to this ip networks.

In the example of how to execute this service definition you will have a clearer idea of the kind of values that we need to enter for these parameters.
~~~~
leaf ipv4-addr{
  type inet:ipv4-address;
}

leaf ipv4-netmask{
  type inet:ipv4-address;
}

leaf ipv6-prefix{
  type string;
  description "IPv6 address prefix(default prefix of /64)";
}
~~~~

#### 5.1.2 SSID service XML mapping file

In this section you will have a look into the service mapping XML file, so you will be able to understand how the parameters that we defined for the service in the yang model are applied into the actual configuration of the router.

In order to simplify the understanding on **where** do we enter such parameters, we will show in separate code block the lines in which we instantiate any of the YANG parameters.

~~~~
<config-template xmlns="http://tail-f.com/ns/config/1.0"
                 servicepoint="ssid">
  <devices xmlns="http://tail-f.com/ns/ncs">
    <device>
      <name>{/device}</name>
      <config>

      <!-- Configuration of the WLAN -->
      <!--Used parameters /ssid, /radio-mode, /password, /vlan-id -->

        <wlans xmlns="http://cisco.com/ns/ciscosb/wifi">
          <ssid>
              <ssid>{/ssid}</ssid>
              <radio>{/radio-mode}</radio>
              <enable>true</enable>
              <ssid-advertisment-enable>true</ssid-advertisment-enable>
              <wmm-enable>true</wmm-enable>
              <captive-portal-enable>false</captive-portal-enable>
              <isolation-with-ssid>false</isolation-with-ssid>
              <security>
                <mode-enabled>WPA2-Personal</mode-enabled>
                <WPA2-Personal>
                  <key-passphrase>{/password}</key-passphrase>
                </WPA2-Personal>
              </security>
              <schedule>Always</schedule>
              <pmf>capable</pmf>
              <vlan_id>{/vlan-id}</vlan_id>
              <mac-filter>
                <enable>false</enable>
              </mac-filter>
              <wps>
                <enable>false</enable>
              </wps>
            </ssid>
         </wlans>

         <interfaces xmlns="urn:ietf:params:xml:ns:yang:ietf-interfaces">

         <!-- Configuration of the interfaces -->
         <!-- For each port we define the vlan as untagged -->
         <!--Used parameters /vlan-id -->

         <interface>
           <name>LAG1</name>
           <type xmlns:ianaift="urn:ietf:params:xml:ns:yang:iana-if-type">
           ianaift:ieee8023adLag
           </type>
           <vlan-settings xmlns="http://cisco.com/ns/ciscosb/vlan">

             <tagged-vlans>
               <vlan-id>{/vlan-id}</vlan-id>
             </tagged-vlans>

           </vlan-settings>
         </interface>
         <interface>
           <name>LAN1</name>
           <type xmlns:ianaift="urn:ietf:params:xml:ns:yang:iana-if-type">
           ianaift:ethernetCsmacd
           </type>
           <vlan-settings xmlns="http://cisco.com/ns/ciscosb/vlan">

             <tagged-vlans>
               <vlan-id>{/vlan-id}</vlan-id>
             </tagged-vlans>
           </vlan-settings>

         </interface>
         <interface>
           <name>LAN2</name>
           <type xmlns:ianaift="urn:ietf:params:xml:ns:yang:iana-if-type">
           ianaift:ethernetCsmacd
           </type>
           <vlan-settings xmlns="http://cisco.com/ns/ciscosb/vlan">

             <tagged-vlans>
               <vlan-id>{/vlan-id}</vlan-id>
             </tagged-vlans>
           </vlan-settings>

         </interface>
         <interface>
           <name>LAN3</name>
           <type xmlns:ianaift="urn:ietf:params:xml:ns:yang:iana-if-type">
           ianaift:ethernetCsmacd
           </type>
           <vlan-settings xmlns="http://cisco.com/ns/ciscosb/vlan">

             <tagged-vlans>
               <vlan-id>{/vlan-id}</vlan-id>
             </tagged-vlans>
           </vlan-settings>

         </interface>
         <interface>
           <name>LAN4</name>
           <type xmlns:ianaift="urn:ietf:params:xml:ns:yang:iana-if-type">
           ianaift:ethernetCsmacd
           </type>
           <vlan-settings xmlns="http://cisco.com/ns/ciscosb/vlan">

             <tagged-vlans>
               <vlan-id>{/vlan-id}</vlan-id>
             </tagged-vlans>
           </vlan-settings>

         </interface>
         <interface>
           <name>LAN5</name>
           <type xmlns:ianaift="urn:ietf:params:xml:ns:yang:iana-if-type">
           ianaift:ethernetCsmacd
           </type>
           <vlan-settings xmlns="http://cisco.com/ns/ciscosb/vlan">

             <tagged-vlans>
               <vlan-id>{/vlan-id}</vlan-id>
             </tagged-vlans>
           </vlan-settings>

         </interface>
         <interface>
           <name>LAN6</name>
           <type xmlns:ianaift="urn:ietf:params:xml:ns:yang:iana-if-type">
           ianaift:ethernetCsmacd
           </type>
           <vlan-settings xmlns="http://cisco.com/ns/ciscosb/vlan">

             <tagged-vlans>
               <vlan-id>{/vlan-id}</vlan-id>
             </tagged-vlans>
           </vlan-settings>

         </interface>
         <interface>
           <name>LAN8</name>
           <type xmlns:ianaift="urn:ietf:params:xml:ns:yang:iana-if-type">
           ianaift:ethernetCsmacd
           </type>
           <vlan-settings xmlns="http://cisco.com/ns/ciscosb/vlan">

             <tagged-vlans>
               <vlan-id>{/vlan-id}</vlan-id>
             </tagged-vlans>
           </vlan-settings>

         </interface>

         <!-- Definition of the VLAN -->
         <!-- We need to define the VLAN and the ipv4/ipv6 addresses -->
         <!--Used parameters /vlan-id, /ssid, /ipv4-addr, /ipv4-netmask,
         /ipv6-prefix -->

         <interface>

           <name>VLAN{/vlan-id}</name>
           <description>{/ssid}</description>

           <type xmlns:ianaift="urn:ietf:params:xml:ns:yang:iana-if-type">
           ianaift:l2vlan
           </type>
           <vlan-interface-settings xmlns="http://cisco.com/ns/ciscosb/vlan">

             <vlan-id>{/vlan-id}</vlan-id>

             <inter-vlan-routing>false</inter-vlan-routing>
             <enable-management>true</enable-management>
           </vlan-interface-settings>
           <ipv4 xmlns="urn:ietf:params:xml:ns:yang:ietf-ip">
             <address>

               <ip>{/ipv4-addr}</ip>
               <netmask>{/ipv4-netmask}</netmask>

             </address>
           </ipv4>
           <ipv6 xmlns="urn:ietf:params:xml:ns:yang:ietf-ip">
             <address>

               <ip>{/ipv6-prefix}1</ip>

               <!-- As mentioned in the YANG model, we set 64 as the default
               prefix length -->

               <prefix-length>64</prefix-length>

               <static xmlns="http://cisco.com/ns/ciscosb/vlan"/>
               <user-define xmlns="http://cisco.com/ns/ciscosb/vlan">
               1
               </user-define>
             </address>
             <ipv6-router-advertisements xmlns="urn:ietf:params:xml:ns:yang:ietf-ipv6-unicast-routing">
                <send-advertisements>false</send-advertisements>
                <max-rtr-adv-interval>30</max-rtr-adv-interval>
                <managed-flag>false</managed-flag>
                <other-config-flag>false</other-config-flag>
                <link-mtu>1500</link-mtu>
                <default-lifetime>3600</default-lifetime>
                <prefix-list>
                  <prefix>

                    <prefix-spec>{/ipv6-prefix}/64</prefix-spec>

                    <valid-lifetime>2592000</valid-lifetime>
                    <preferred-lifetime>3600</preferred-lifetime>
                    <static xmlns="http://cisco.com/ns/ciscosb/routing"/>
                  </prefix>
                </prefix-list>
                <router-preference xmlns="http://cisco.com/ns/ciscosb/routing">
                high
                </router-preference>
                <mode xmlns="http://cisco.com/ns/ciscosb/routing">
                unsolicited-multicast
                </mode>
              </ipv6-router-advertisements>
           </ipv6>
         </interface>
        </interfaces>

        <!-- Configuration of the routing protocols -->
        <!-- We need to define the VLAN configuration for each of the protocols
        available in the router -->
        <!--Used parameters /vlan-id -->

        <routing xmlns="urn:ietf:params:xml:ns:yang:ietf-routing">
         <routing-instance>
           <name>local</name>

           <interfaces>
             <interface>VLAN{/vlan-id}</interface>
           </interfaces>

           <routing-protocols>
             <routing-protocol>
               <type xmlns:ciscosb-routing-rip="http://cisco.com/ns/ciscosb/routing-rip">
               ciscosb-routing-rip:ripv1
               </type>
               <name>rip</name>
               <rip xmlns="http://cisco.com/ns/ciscosb/routing-rip">
                 <ripv1>
                   <interfaces>
                     <interface>

                       <name>VLAN{/vlan-id}</name>

                       <!-- Default configuration: -->
                       <!-- Routing protocol disable in the vlan -->
                       <!-- Vlan set as passive interface for the routing
                       protocol -->

                       <enabled>false</enabled>
                       <passive>true</passive>

                     </interface>
                   </interfaces>
                 </ripv1>
               </rip>
             </routing-protocol>
             <routing-protocol>
               <type xmlns:ciscosb-routing-rip="http://cisco.com/ns/ciscosb/routing-rip">
               ciscosb-routing-rip:ripv2
               </type>
               <name>rip</name>
               <rip xmlns="http://cisco.com/ns/ciscosb/routing-rip">
                 <ripv2>
                   <interfaces>
                     <interface>

                       <name>VLAN{/vlan-id}</name>

                       <!-- Default configuration: -->
                       <!-- Routing protocol disable in the vlan -->
                       <!-- Vlan set as passive interface for the routing
                       protocol -->

                       <enabled>false</enabled>
                       <passive>true</passive>

                     </interface>
                   </interfaces>
                 </ripv2>
               </rip>
             </routing-protocol>
             <routing-protocol>
               <type xmlns:ciscosb-routing-rip="http://cisco.com/ns/ciscosb/routing-rip">
               ciscosb-routing-rip:ripng
               </type>
               <name>rip</name>
               <rip xmlns="http://cisco.com/ns/ciscosb/routing-rip">
                 <ripng>
                   <interfaces>
                     <interface>

                       <name>VLAN{/vlan-id}</name>

                       <!-- Default configuration: -->
                       <!-- Routing protocol disable in the vlan -->
                       <!-- Vlan set as passive interface for the routing
                       protocol -->

                       <enabled>false</enabled>
                       <passive>true</passive>

                       <authentication>
                         <enable>false</enable>
                       </authentication>
                     </interface>
                   </interfaces>
                 </ripng>
               </rip>
             </routing-protocol>
           </routing-protocols>
         </routing-instance>
       </routing>
      </config>
    </device>
  </devices>
</config-template>
~~~~

#### 5.1.3 Execute SSID service from NSO

We will create a new Guest SSID with the following parameters:

- ssid: wifi-guest
- device: rv260w
- radio-mode: WLAN0
- password: cisco123
- vlan-id: 30
- ipv4-addr: 192.168.10.1
- ipv4-netmask: 255.255.255.0
- ipv6-prefix: fec0:10::

~~~~
ssid wifi-guest device rv260w radio-mode WLAN0 password cisco123 vlan-id 30 \
ipv4-addr 192.168.10.1 ipv4-netmask 255.255.255.0 ipv6-prefix fec0:10::
~~~~

> **Improvements**
> - Set automatically ipv4 and ipv6 spaces for the Vlan
> - Be able to define the port in which the VLAN will be untagged (if necessary)
> - Define DHCP services

#### 5.1.4 Resulting configuration

Look below that the configuration has been committed to the router and we can
see ssid, vlan ad routing configuration through the WEB GUI.

1. Configuration of ssid

![Image of ssid](screenshots/wifi_config/wifi-guest-vlan30-nso-service.png)

2. Configuration of Vlan

![Image of vlan](screenshots/wifi_config/vlan30-nso-service.png)

3. Configuration of routing protocol

![Image of routing protocol](screenshots/wifi_config/vlan30-routing-nso-service.png)

***

### 5.2 Content Filtering service

Description:

This service will deploy a content filtering rule in the RV260 model. There are two types of content filtering possible in the rv260 ("Block Matching URLs or Allow Only Matching URLs): for the sake of simplicity this service will implement only a "Block Matching URLs" logic. In order to make easier for the reader to understand the way the YANG model of the service was defined, here are the main informations that we need for this service:

1. filtering-type: It defines the logic of the filtering
  - BLOCK_LIST ("Block Matching URLs" logic);
  - ALLOW_LIST ("Allow Only Matching URLs" logic);

2. domain-name: The domain to filter or allow;

3. schedule: specify when the content filtering rules are active. Different options are available here, depending on the schedules configured in the related configuration "Schedules" section of the device. Possible examples are "Always" (enforce 24/7), BUSINESS (9AM-5.30PM on Weekdays) etc. Please note that these schedules are customizable by the end user.

> ***Important note:*** for simplification reasons there are multiple parameters that are set up as default. The service yang model could be also modified in order to make possible the manual configuration of those parameters. However, it will be more interesting to set those values once we are able to run the service in python (it gives more flexibility and it is easier to program).

#### 5.2.1 Content filtering service YANG model

This is the service yang model:
~~~~
module content_filtering {
  namespace "http://com/example/content_filtering";
  prefix content_filtering;

  import ietf-inet-types {
    prefix inet;
  }
  import tailf-ncs {
    prefix ncs;
  }

  list content_filtering {
    key content_filtering;

    uses ncs:service-data;
    ncs:servicepoint "content_filtering";

    leaf content_filtering {
      mandatory true;
      type string;
    }

    leaf device {
      type leafref {
        path "/ncs:devices/ncs:device/ncs:name";
      }
    }

    leaf domain_name {
      mandatory true;
      type string;
    }

    leaf schedule_name {
      mandatory true;
      type string;
    }
  }
}
~~~~

Let's analyze the different parameters that we will need to enter when defining the service for a particular Content Filtering rule.

The content_filtering is a string and is a mandatory value. We also need to define to which device we want to apply this new configuration.
~~~~
leaf content_filtering {
  mandatory true;
  type string;
}

leaf device {
  type leafref {
	path "/ncs:devices/ncs:device/ncs:name";
  }
}
~~~~

Now we need to define which domain name we want to block and when to enforce our policy that is define the right schedule. In order to do this we define the **domain_name** and **schedule_name** leafs in our YANG model.
~~~~
leaf domain_name {
  mandatory true;
  type string;
}

leaf schedule_name {
  mandatory true;
  type string;
}
~~~~

#### 5.2.2 Content filtering service XML mapping file

In this section you will have a look into the service mapping XML file, so you will be able to understand how the parameters that we defined for the service in the yang model are applied into the actual configuration of the router.

~~~~
<config-template xmlns="http://tail-f.com/ns/config/1.0"
                 servicepoint="content_filtering">
  <devices xmlns="http://tail-f.com/ns/ncs">
    <device>
      <name>{/device}</name>
      <config>
        <content-filtering xmlns="http://cisco.com/ns/ciscosb/content-filtering">
          <enable>true</enable>
          <filtering-type>BLOCK_LIST</filtering-type>
          <block_rules>
            <block_url_rules>
              <domain-name>{/domain_name}</domain-name>
              <schedule>{/schedule_name}</schedule>
            </block_url_rules>
          </block_rules>
        </content-filtering>
      </config>
    </device>
  </devices>
</config-template>
~~~~

#### 5.2.3 Execute Content filtering service from NSO

We will create a new Content filtering rule with the following example parameters:

- device: rv260w
- domain-name: abaddomain.com
- schedule: Always

~~~~
content_filtering cf device rv260w domain_name abaddomain.com schedule_name Always
~~~~

> **Improvements**
> - Create a new service to define Schedules
> - Be able to define also Allowed URLs. Please note that it's not just a matter of changing the filtering-type attribute but we also need to define a new "allow_rules" block:

~~~~
<allow_rules>
  <allow_url_rules>
    <domain-name>good_domain.com</domain-name>
    <schedule>Always</schedule>
  </allow_url_rules>
</allow_rules>
~~~~

> This can be done through a new service (since we can't define optional conf blocks in the mapping through xml) or probably through dynamic checks implementing the service in python.

#### 5.2.4 Resulting configuration

Now check that the configuration has been committed to the router and we can see the domain-name and schedule configuration of the rule through the WEB GUI. We can also check for the other schedules configured on the device in the System Configuration/Schedules section.

1. Configuration of the new content filtering rule

![Content filtering Rule conf on the device](screenshots/content_filtering/content_filtering_conf_check.png)

2. Configuration of Schedules

![Schedules configured on the device](screenshots/content_filtering/schedules.png)

***

### 5.3 NTP service

Description:

This service allows the user to configure the NTP settings as well as the summer time settings in the RV260 model. For NTP the options are to disable it, or to enable it and set up to four NTP servers to synchronize from. If disabled, the last valid time is used and the user has the option to manually adjust the time. Since the manual adjustment of the time is not advised, it is also not supported in this service but could be extended upon.
The second configuration that was demonstrated here is the summer time settings, which can be, like the NTP server, be enabled or disabled. If enabled, the user can adjust the date and time of when it starts and stops. Since this serves as a demonstration the default offset of 60min was kept and the service would need to be extended to alter this value.
Per default this service enables NTP with the out-of-the-box provided NTP servers configured and disables the summer time settings.
The most important variables are:

1. ntp-enabled: Boolean for enabling and disabling NTP.

2. ntp{1-4}_address: The NTP servers to synchronize from if NTP is enabled.

3. summer-time-enabled: Boolean for enabling and disabling the summer time.

4. {start|end}-{month|day|time}: Different date and time variables for the start and end of the summer time.

5. device: For this service we use the RV260 model.

> ***Important note:*** for simplification reasons there are multiple parameters that are set up as default. The service yang model could be also modified in order to make possible the manual configuration of those parameters. However, it will be more interesting to set those values once we are able to run the service in python (it gives more flexibility and it is easier to program).

#### 5.3.1 NTP service YANG model

This is the service yang model:
~~~~
module ntp {
  namespace "http://com/example/ntp";
  prefix ntp;

  import ietf-inet-types {
    prefix inet;
  }
  import tailf-ncs {
    prefix ncs;
  }

  list ntp {
    key ntp_config;

    uses ncs:service-data;
    ncs:servicepoint "ntp";

    leaf ntp_config {
      type string;
      mandatory true;
    }

    leaf-list device {
      type leafref {
        path "/ncs:devices/ncs:device/ncs:name";
      }
    }

    leaf ntp-enabled {
      type boolean;
      default true;
    }

    leaf ntp1_address {
      type inet:domain-name;
      default "0.ciscosb.pool.ntp.org";
    }

    leaf ntp2_address {
      type inet:domain-name;
      default "1.ciscosb.pool.ntp.org";
    }

    leaf ntp3_address {
      type inet:domain-name;
      default "2.ciscosb.pool.ntp.org";
    }

    leaf ntp4_address {
      type inet:domain-name;
      default "3.ciscosb.pool.ntp.org";
    }

    leaf summer-time-enabled {
      type boolean;
      default false;
    }

    leaf start-month {
      type uint8 {
        range "1..12";
      }
      default 1;
    }

    leaf start-time {
      type string;
      default "00:00";
    }

    leaf start-day {
      type uint8 {
        range "1..31";
      }
      default 1;
    }

    leaf end-month {
      type uint8 {
        range "1..12";
      }
      default 1;
    }

    leaf end-time {
      type string;
      default "00:00";
    }

    leaf end-day {
      type uint8 {
        range "1..31";
      }
      default 1;
    }
  }
}
~~~~

#### 5.3.2 NTP service XML mapping file

In this section you will have a look into the service mapping XML file, so you will be able to understand how the parameters that we defined for the service in the yang model are applied into the actual configuration of the router.

~~~~
<config-template xmlns="http://tail-f.com/ns/config/1.0"
                 servicepoint="ntp">
  <devices xmlns="http://tail-f.com/ns/ncs">
    <device>
    <name>{/device}</name>
      <config>
        <system xmlns="urn:ietf:params:xml:ns:yang:ietf-system">
          <clock>
            <timezone-name>Dublin, Edinburgh, Lisbon, London</timezone-name>
            <timezone-summer-time xmlns="http://cisco.com/ns/ciscosb/system">
              <enabled>{/summer-time-enabled}</enabled>
              <start-date>
                <month>{/start-month}</month>
                <time>{/start-time}</time>
                <day>{/start-day}</day>
              </start-date>
              <end-date>
                <month>{/end-month}</month>
                <time>{/end-time}</time>
                <day>{/end-day}</day>
              </end-date>
              <saving-offset>60</saving-offset>
              <recurring>false</recurring>
            </timezone-summer-time>
          </clock>
          <ntp>
            <enabled>{/ntp-enabled}</enabled>
            <server>
              <name>ntp1</name>
              <udp>
                <address>{/ntp1_address}</address>
              </udp>
            </server>
            <server>
              <name>ntp2</name>
              <udp>
                <address>{/ntp2_address}</address>
              </udp>
            </server>
            <server>
              <name>ntp3</name>
              <udp>
                <address>{/ntp3_address}</address>
              </udp>
            </server>
            <server>
              <name>ntp4</name>
              <udp>
                <address>{/ntp4_address}</address>
              </udp>
            </server>
          </ntp>
        </system>
      </config>
  </device>
  </devices>
</config-template>
~~~~

#### 5.3.3 Execute NTP service from NSO

We will modify the NTP settings with the following parameters

- device: rv260w
- ntp-enabled: true
- ntp1_address: time.nist.gov
- summer-time-enabled: false

~~~~
ntp nc device rv260w ntp-enabled true ntp1_address time.nist.gov summer-time-enabled false
~~~~

#### 5.3.4 Resulting configuration

Now check that the configuration has been committed to the router and we can see the time settings through the WEB GUI.

1. Configuration of the NTP server and summer time settings

![NTP conf on the device](screenshots/ntp/ntp_conf_check.png)

***

### 5.4 Static WAN service

Description:

This service will deploy a static WAN configuration in the RV260 model. Here are the main informations that we need for this service:

1. Interface Name (interface-name): It defines the name of the interface we are configuring

2. IPv4 Address (ipv4-addr): It defines the IPv4 address of the interface we are configuring

3. Network mask (ipv4-netmask): It defines the network mask for the IPv4 address of the interface we are configuring

4. Gateway IP Address (ipv4-gateway-addr): It defines the IPv4 address of the network gateway

5. DNS Servers IP Addresses (primary-naming-server and secondary-naming-server)

> ***Important note:*** Please bear in mind that each of these informations, except for the secondary DNS server IP address, is mandatory to make this configuration.

#### 5.4.1 Static WAN service YANG model

This is the service yang model:
~~~~
module wan-static {
  namespace "http://com/example/wanstatic";
  prefix wan-static;

  import ietf-inet-types {
    prefix inet;
  }
  import tailf-ncs {
    prefix ncs;
  }

  list wan-static {
    key wan-static;

    uses ncs:service-data;
    ncs:servicepoint "wan-static";

    leaf wan-static {
      mandatory true;
      type string;
    }

    leaf device {
      type leafref {
        path "/ncs:devices/ncs:device/ncs:name";
      }
    }

    leaf ipv4-addr {
      mandatory true;
      type inet:ipv4-address;
    }

    leaf ipv4-netmask {
      mandatory true;
      type inet:ipv4-address;
    }

    leaf ipv4-gateway-addr {
      mandatory true;
      type inet:ipv4-address;
    }

    leaf interface-name {
      mandatory true;
      type string;
    }

    leaf primary-naming-server {
      mandatory true;
      type inet:ipv4-address;
    }

    leaf secondary-naming-server {
      mandatory false;
      type inet:ipv4-address;
    }

  }
}
~~~~

Let's analyze the different parameters that we will need to enter when defining the service for a particular WAN configuration.

The wan-static is a string and is a mandatory value: it identifies the particular configuration we want to use. We also need to define to which device we want to apply this new configuration.
~~~~
leaf wan-static {
  mandatory true;
  type string;
}

leaf device {
  type leafref {
	path "/ncs:devices/ncs:device/ncs:name";
  }
}
~~~~

Now we need to define the interface for which we want to configure the WAN section. In order to do this we define the **interface-name** leaf in our YANG model.

~~~~
leaf interface-name {
  mandatory true;
  type string;
}
~~~~

Now we need to define the IPv4 address and the netmask we want to configure on the interface we just specified. In order to do this we define the **ipv4-addr** and **ipv4-netmask** leafs in our YANG model.
~~~~
leaf ipv4-addr {
  mandatory true;
  type inet:ipv4-address;
}

leaf ipv4-netmask {
  mandatory true;
  type inet:ipv4-address;
}
~~~~

We then define the IPv4 address of the gateway through the **ipv4-gateway-addr** leaf:

~~~~
leaf ipv4-gateway-addr {
  mandatory true;
  type inet:ipv4-address;
}
~~~~

Finally we specify a primary DNS server and optionally a secondary DNS server, specifying of course their IPv4 addresses through the leafs **primary-naming-server** and the optional **secondary-naming-server**:

~~~~
leaf primary-naming-server {
  mandatory true;
  type inet:ipv4-address;
}

leaf secondary-naming-server {
  mandatory false;
  type inet:ipv4-address;
}
~~~~

#### 5.4.2 Static WAN service XML mapping file

In this section you will have a look into the service mapping XML file, so you will be able to understand how the parameters that we defined for the service in the yang model are applied into the actual configuration of the router.

~~~~
<config-template xmlns="http://tail-f.com/ns/config/1.0"
                 servicepoint="wan-static">
  <devices xmlns="http://tail-f.com/ns/ncs">
    <device>
      <name>{/device}</name>
      <config>
        <interfaces xmlns="urn:ietf:params:xml:ns:yang:ietf-interfaces">
          <interface>
            <name>{/interface-name}</name>
            <ipv4 xmlns="urn:ietf:params:xml:ns:yang:ietf-ip">
              <address>
                <ip>{/ipv4-addr}</ip>
                <netmask>{/ipv4-netmask}</netmask>
              </address>
              <setting xmlns="http://cisco.com/ns/ciscosb/wan-ip">
                <static>
                  <gateway>{/ipv4-gateway-addr}</gateway>
                  <ifname>{/interface-name}</ifname>
                  <naming-server>
                    <servers>{/primary-naming-server}</servers>
                    <?if {/secondary-naming-server}?>
                    <servers>{/secondary-naming-server}</servers>
                    <?end?>
                  </naming-server>
                </static>
              </setting>
            </ipv4>
          </interface>
        </interfaces>
      </config>
    </device>
  </devices>
</config-template>
~~~~

> ***Important note:*** Please note that we used a conditional statement for the secondary-naming-server leaf. The second <servers> tag (including its own information) will be then included in the configuration if and only if we have defined the secondary-naming-server leaf during the definition of the service through the NSO CLI.

#### 5.4.3 Execute Static WAN service from NSO

We will create a new WAN configuration with the following example parameters:

- device: rv260w
- Interface: WAN1
- IPv4 address: 10.1.20.51
- Netmask: 255.255.255.0
- Default Gateway: 10.1.20.254
- Static DNS 1: 10.1.3.11
- Static DNS 2: 10.1.3.12

~~~~
wan-static ws device rv260w interface-name WAN1 ipv4-addr 10.1.20.51 ipv4-netmask 255.255.255.0 ipv4-gateway-addr 10.1.20.254 primary-naming-server 10.1.3.11 secondary-naming-server 10.1.3.12
~~~~

> **Improvements**
> - Create a new service or be able to define also flexibly configurations via DHCP/PPPoE/PPTP/L2TP.

#### 5.4.4 Resulting configuration

After issuing the **commit** command we can now check that the configuration has been committed to the router and we can see the Static WAN configuration through the WEB GUI.

![WAN static conf on the device](screenshots/wan-config/wan.png)

***

### 5.5 Static IPv4 route service

Description:

This service defines an IPv4 static route. The parameters that need to be considered are:
 - Route's destination IPv4 address and prefix length
 - Next hop IPv4 address
 - Router's interface to reach the next hop

> ***Note:*** for every new static route defined in this router, the weight will be set to 1 by default.

#### 5.5.1 Static IPv4 route service YANG model

~~~
module route-static {
namespace "http://com/example/route-static";

 import ietf-inet-types {
   prefix inet;
 }
 import tailf-ncs {
   prefix ncs;
 }

 list route-static {
   key route-static;

   uses ncs:service-data;
   ncs:servicepoint "route-static";

   leaf route-static{
     //Identification of the static route. String, single word.
     mandatory true;
     type string;
   }

   leaf device {
     type leafref {
       path "/ncs:devices/ncs:device/ncs:name";
     }
   }

   leaf dest {
     //IPv4 address of the route destination
     mandatory true;
     type inet:ipv4-address;
   }

   leaf pref-length{
     //Length of the destination prefix. Example: Type the value 32 for 1.2.3.4/32
     mandatory true;
     type uint16;
   }

   leaf next-hop {
     //IPv4 address of the next hop
     mandatory true;
     type inet:ipv4-address;
   }

   leaf int {
     //Interface to reach the next hop.
     //Ideally this leaf should be a type enumeration.
     mandatory true;
       type string;
   }
 }
}
~~~

It is important to note that we need to define a string in order to identify this route.
This string won't be visible at the router web GUI, it is only internal for NSO.

#### 5.5.2 Static IPv4 route service XML mapping file

~~~
<config-template xmlns="http://tail-f.com/ns/config/1.0"
                 servicepoint="route-static">
  <devices xmlns="http://tail-f.com/ns/ncs">
    <device>
      <name>{/device}</name>
      <config>
        <!-- Configuration of static route -->
        <!--Used parameters /dest, /pref-length, /next-hop, /int -->
        <routing xmlns="urn:ietf:params:xml:ns:yang:ietf-routing">
          <routing-instance>
            <name>local</name>
            <routing-protocols>
              <routing-protocol>
                <type>static</type>
                <name>local</name>
                <description>local</description>
                <enabled>true</enabled>
                <static-routes>
                  <ipv4 xmlns="urn:ietf:params:xml:ns:yang:ietf-ipv4-unicast-routing">
                    <route>
                      <destination-prefix>{/dest}/{/pref-length}</destination-prefix>
                      <next-hop>
                        <outgoing-interface>{/int}</outgoing-interface>
                        <next-hop-address xmlns="http://cisco.com/ns/ciscosb/routing">{/next-hop}</next-hop-address>
                      </next-hop>
                      <metric xmlns="http://cisco.com/ns/ciscosb/routing">1</metric>
                    </route>
                    </ipv4>
                </static-routes>
              </routing-protocol>
            </routing-protocols>
          </routing-instance>
        </routing>
      </config>
    </device>
  </devices>
</config-template>
~~~~

Take care in the definition of the default value of the metric of the route.
If you want to make this value variable, it will be need it to add it as a leaf of the YANG model and modify the XML file.

~~~~
<metric xmlns="http://cisco.com/ns/ciscosb/routing">1</metric>
~~~~

#### 5.5.3 Execute static IPv4 route service from NSO

We will create a new static route with de following parameters:

- route-static: internet
- device: rv260w
- dest: 1.2.3.4
- pref-length: 32
- next-hop: 10.50.0.78
- int: WAN1

~~~~
route-static internet dest 1.2.3.4 pref-length 32 next-hop 10.50.0.78 int WAN1
~~~~

#### 5.5.4 Resulting configuration

Here you can see the resulting info that will appear afterwards in the router's web GUI.

![Static route configured on the device](screenshots/static_route/static-route.png)

***

## **6. SERVICE CREATION WITH PYTHON API**

Sometimes more flexibility than what is provided by XML is needed, or maybe one wants to integrate the services in other software, in which case the NSO API can be used. Here we show a Python script to combine different use cases.

### 6.1 Requirements

The first thing we need is to import ncs to get MAAPI, for the connection, and MAAGIC, for data access. The ncs library is automatically installed alsongside the NSO installation. Apart from that, the only requirement is to run the script on a host with access to NSO and a python interpreter.

### 6.2 Hostname expample

To see how individual services in the Python script work, let us take a look at the hostname service.

~~~
def write_hostname(device_name, new_hostname):
    with ncs.maapi.single_write_trans('admin', 'admin', groups=['ncsadmin']) as t:
        root = ncs.maagic.get_root(t)
        print("Old hostname: ", root.devices.device[device_name].config.sys__system.hostname)
        root.devices.device[device_name].config.sys__system.hostname = new_hostname;
        print("New hostname: ", root.devices.device[device_name].config.sys__system.hostname)
        t.apply()
~~~

The function write_hostname takes two paramenters, the device on which the configuration shall happen and the new hostname that shall be configured.

The first step in our function is to create a transaction with MAAPI. Since NSO implements full ACID propoerties, either everything or nothing inside a transaction is applied. This is to make sure that there are no partial configurations in case something goes wrong. Furthermore after the transaction is over the device has to be in a valid state and the transaction can not run concurrently with another transaction if those two transactions have overlapping configurations.

We create the transaction with the username and password of the account with whom we want to make this configuration, in this case the admin account with password admin, as well as the group.

Once we have opened the transaction we get the root of the NSO database. From this root we can traverse to the relevant information, in this case we go to the device list and look for the device that we want to configure with "device[device_name]" and then set the new hostname in the "config.sys__system" settings under the leaf hostname.
After we finished the configuration we have to notify NSO to apply that transaction to the device, which we do with "t.apply()"

### 6.3 Using the services

Since our services are just simply functions inside Python we can call that like any other Python function. In the case of our hostname example that would be for example "write_hostname("rv260w", "routerA0B671")".

## **7. Service creation with Python and XML template**

The following reference resources were used for this new implementation of services:

Cisco NSO on demand learning:
https://ondemandelearning.cisco.com/cisco-cte/nso201v30/sections/14/pages/6

Devnet NSO introduction presentation:
https://pubhub.devnetcloud.com/media/netdevops-live/site/files/s02t06.pdf

Github python-and-template service creation:
https://github.com/kecorbin/nso-service-development

Devnet NSO service creation best practices:
https://developer.cisco.com/docs/nso/#!service-design/basics

The idea is basicacally to add some Python-based middleware for an scalable and powerful mapping between the YANG model and the XML file. In this section we will also explain how to make YANG models reusables.

### 7.1. Python service skeleton

NSO also provides a command to autogenerate the needed directory to support python and xml in a service's definition. Issue the following command at ../packages:

~~~~
ncs-make-package --service-skeleton python-and-template wlan
~~~~

This commad will provide (among other things) the following files on which we will work:

- src/yang/wlan.yang
- templates/wlan-template.xml
- python/wlan/main.py


### 7.2. Define a YANG model to be reused
In the future it might be needed to stack services. An easy way of implementation is to define modular YANG models that can be reused by a higher-level YANG model. In order to make this possible, we have modify the previously defined YANG models in the following way:

Let see the simplified example of the SSID service:
~~~~
module wlan {

  namespace "http://example.com/wlan";
  prefix wlan;

  import ietf-inet-types {prefix inet;}
  import tailf-common {prefix tailf;}
  import tailf-ncs {prefix ncs;}

  description
    "Configuration of new SSID";

  revision 2016-01-01 {
    description
      "Initial revision.";
  }

  grouping wlan_conf{

    leaf ssid {
      mandatory true;
      type string;

    }

    leaf ssid-radio {
      tailf:info "Radio mode. Default 5Ghz";
      mandatory true;
      type enumeration{
        enum BOTH {
          description "Both 2.4Ghz and 5Ghz are active";
        }
        enum 5Ghz {
          //WLAN0
          description "Only 5Ghz is active";
        }
        enum 2.4Ghz {
          //WLAN1
          description "Only 2.4Ghz is active";
        }
      }
    }

    leaf ssid-password {
      tailf:info "SSID password";
      mandatory true;
      type string;
    }

    leaf ssid-vlan {
      tailf:info "Associated VLAN";
      mandatory true;
      type uint32 {
        range "1..4096";
      }
    }

    leaf ssid-schedule {
      tailf:info "Time of the day access";
      //This should be actually a enum with the differente option. To be configured
      type string;
      default Always;
    }

  }

  augment /ncs:services {
  list wlan {
    tailf:info "Deploy new SSID";
    description "Deploy new SSID";

    key name;
    leaf name {
      tailf:info "Unique service id";
      tailf:cli-allow-range;
      type string;
    }

    uses ncs:service-data;
    ncs:servicepoint wlan-servicepoint;

    leaf device {
      tailf:info "Router to be configured with the new SSID";
      mandatory true;
      type leafref {
        path "/ncs:devices/ncs:device/ncs:name";
      }
    }

    uses wlan:wlan_conf;


  }
  } // augment /ncs:services {
}
~~~~

Note first the grouping statement. Following YANG RFC definitions, we can create a group of leafs to be reused when needed. In this case, all the unique characteristics of our service have been grouped to be exported to other YAND models.

~~~~
grouping wlan_conf{

  leaf ssid {
    mandatory true;
    type string;

  }

  leaf ssid-radio {
    tailf:info "Radio mode. Default 5Ghz";
    mandatory true;
    type enumeration{
      enum BOTH {
        description "Both 2.4Ghz and 5Ghz are active";
      }
      enum 5Ghz {
        //WLAN0
        description "Only 5Ghz is active";
      }
      enum 2.4Ghz {
        //WLAN1
        description "Only 2.4Ghz is active";
      }
    }
  }

  leaf ssid-password {
    tailf:info "SSID password";
    mandatory true;
    type string;
  }

  leaf ssid-vlan {
    tailf:info "Associated VLAN";
    mandatory true;
    type uint32 {
      range "1..4096";
    }
  }

  leaf ssid-schedule {
    tailf:info "Time of the day access";
    //This should be actually a enum with the differente option. To be configured
    type string;
    default Always;
  }

}
~~~~

Now, instead of defining the leafs inside the "list wlan {...}" statement, we will just state that we will use the group wlan:wlan_conf.

>*Note:* since the leafs might me reused in a more complex service, is a good practice to correctly tag them, so it is possible to identify to which micro-service they belong.

~~~~
    uses wlan:wlan_conf;
~~~~

### 7.3 Define your Python code
Modify the main.py file of your new service in order to handle the different variables and pass them to the XML file.

~~~~
# -*- mode: python; python-indent: 4 -*-
import ncs
from ncs.application import Service


# ------------------------
# SERVICE CALLBACK EXAMPLE
# ------------------------
class ServiceCallbacks(Service):

    # The create() callback is invoked inside NCS FASTMAP and
    # must always exist.
    @Service.create
    def cb_create(self, tctx, root, service, proplist):
        self.log.info('Service create(service=', service._path, ')')

        wlan = ncs.template.Variables()

        wlan.add('DEVICE', service.device)
        wlan.add('SSID', service.ssid)

        # Selection of radio mode
        radio = str(service.ssid_radio)
        if  radio == "5Ghz":
          wlan.add('RADIO', 'WLAN0')
        if radio == "2.5Ghz":
          wlan.add('RADIO', 'WLAN1')
        else:
          wlan.add('RADIO', 'BOTH')

        wlan.add('PWD', service.ssid_password)
        wlan.add('SCHEDULE', service.ssid_schedule)
        wlan.add('VLANID', service.ssid_vlan)

        template = ncs.template.Template(service)
        template.apply('wlan-template', wlan)

    # The pre_modification() and post_modification() callbacks are optional,
    # and are invoked outside FASTMAP. pre_modification() is invoked before
    # create, update, or delete of the service, as indicated by the enum
    # ncs_service_operation op parameter. Conversely
    # post_modification() is invoked after create, update, or delete
    # of the service. These functions can be useful e.g. for
    # allocations that should be stored and existing also when the
    # service instance is removed.

    # @Service.pre_lock_create
    # def cb_pre_lock_create(self, tctx, root, service, proplist):
    #     self.log.info('Service plcreate(service=', service._path, ')')

    # @Service.pre_modification
    # def cb_pre_modification(self, tctx, op, kp, root, proplist):
    #     self.log.info('Service premod(service=', kp, ')')

    # @Service.post_modification
    # def cb_post_modification(self, tctx, op, kp, root, proplist):
    #     self.log.info('Service premod(service=', kp, ')')


# ---------------------------------------------
# COMPONENT THREAD THAT WILL BE STARTED BY NCS.
# ---------------------------------------------
class Main(ncs.application.Application):
    def setup(self):
        # The application class sets up logging for us. It is accessible
        # through 'self.log' and is a ncs.log.Log instance.
        self.log.info('Main RUNNING')

        # Service callbacks require a registration for a 'service point',
        # as specified in the corresponding data model.
        #
        self.register_service('wlan-servicepoint', ServiceCallbacks)

        # If we registered any callback(s) above, the Application class
        # took care of creating a daemon (related to the service/action point).

        # When this setup method is finished, all registrations are
        # considered done and the application is 'started'.

    def teardown(self):
        # When the application is finished (which would happen if NCS went
        # down, packages were reloaded or some error occurred) this teardown
        # method will be called.

        self.log.info('Main FINISHED')

~~~~

No you are able to apply to the service's inputs as many function as you consider.
For more information about how the main.py works, refer to the resources mentioned above.

### 7.4 Python variables in the XML file
The last thing you need to do, is to collect the Python output from the XML file. You can do so with {$VARIABLE}

Note that this time, the XML does not point directly to the service, but it just receives the values from Python.

~~~~
<config-template xmlns="http://tail-f.com/ns/config/1.0">
  <devices xmlns="http://tail-f.com/ns/ncs">
    <device>

      <name>{/device}</name>
      <config>
        <wlans xmlns="http://cisco.com/ns/ciscosb/wifi">
          <ssid>
              <ssid>{$SSID}</ssid>
              <radio>{$RADIO}</radio>
              <enable>true</enable>
              <ssid-advertisment-enable>true</ssid-advertisment-enable>
              <wmm-enable>true</wmm-enable>
              <captive-portal-enable>false</captive-portal-enable>
              <isolation-with-ssid>false</isolation-with-ssid>
              <security>
                <mode-enabled>WPA2-Personal</mode-enabled>
                <WPA2-Personal>
                  <key-passphrase>{$PWD}</key-passphrase>
                </WPA2-Personal>
              </security>
              <schedule>{$SCHEDULE}</schedule>
              <pmf>capable</pmf>
              <vlan_id>{$VLANID}</vlan_id>
              <mac-filter>
                <enable>false</enable>
              </mac-filter>
              <wps>
                <enable>false</enable>
              </wps>
            </ssid>
         </wlans>
      </config>
    </device>
  </devices>
</config-template>
~~~~

## **8. Services Stack**
Finally we will create a global service that will run the different services we defined above with a single call.

First, create the service skeleton as usual:
~~~~
ncs-make-package --service-skeleton python-and-template secure-access
~~~~

In this case we will need to work with the following files:

- src/yang/secure-access.yang
- src/Makefile
- python/wlan/main.py

The service XML file does not need to be modified.

### 8.1 Define the YANG model
The main function of this service is to call the rest of the services. For that we will need to:

- Import the correspondent service's modules
- State the use of those modules within the "list secure-access{...}" statement
- Modify the Makefile to compute the path to the correspondant modules

If we want to integrate the wlan and the static-route services, the resulting YANG model for secure-access will be:

~~~~
module secure-access {

  namespace "http://example.com/secure-access";
  prefix secure-access;

  import ietf-inet-types {prefix inet;}
  import tailf-common {prefix tailf;}
  import tailf-ncs {prefix ncs;}

  // Import the services modules
  import wlan {prefix wlan;}
  import static-route {prefix static-route;}

  description
    "This service implements secure access, reusing other YANG service modules";

  revision 2016-01-01 {
    description
      "Initial revision.";
  }

  augment /ncs:services {
  list secure-access {
    description "Service to deploy secure access";

    key name;
    leaf name {
      tailf:info "Unique service id";
      tailf:cli-allow-range;
      type string;
    }

    uses ncs:service-data;
    ncs:servicepoint secure-access-servicepoint;

    leaf device {
      mandatory true;
      type leafref {
        path "/ncs:devices/ncs:device/ncs:name";
      }
    }

    // State the use of the imported services
    uses wlan:wlan_conf;
    uses static-route:static-route_conf;


  }
  } // augment /ncs:services {
}
~~~~

Also modify the Makefile. Below you can find the lines that need to be added.

~~~~
YANGPATH += ../../wlan/src/yang
YANGPATH += ../../static-route/src/yang
~~~~

### 8.2. Write the Python code
The Python code is responsible for extracting the YANG variables and implementing them in the correct template.

~~~~
# -*- mode: python; python-indent: 4 -*-
import ncs
from ncs.application import Service


# ------------------------
# SERVICE CALLBACK EXAMPLE
# ------------------------
class ServiceCallbacks(Service):

    # The create() callback is invoked inside NCS FASTMAP and
    # must always exist.
    @Service.create
    def cb_create(self, tctx, root, service, proplist):
        self.log.info('Service create(service=', service._path, ')')
        #This is a stack service, we will need to provide the correct variables to each sub-service template

        ## Get wlan service variables
        wlan = ncs.template.Variables()

        wlan.add('DEVICE', service.device)
        wlan.add('SSID', service.ssid)

        ### Selection of radio mode
        radio = str(service.ssid_radio)
        if  radio == "5Ghz":
          wlan.add('RADIO', 'WLAN0')
        if radio == "2.5Ghz":
          wlan.add('RADIO', 'WLAN1')
        else:
          wlan.add('RADIO', 'BOTH')

        wlan.add('PWD', service.ssid_password)
        wlan.add('SCHEDULE', service.ssid_schedule)
        wlan.add('VLANID', service.ssid_vlan)

        ## Get static route service variables
        route = ncs.template.Variables()
        route.add('DEVICE', service.device)
        route.add('DESCRIPTION', service.route_description)
        route.add('DESTINATION', service.route_destination)
        route.add('NEXTHOP', service.route_next_hop)

        interface = str(service.route_interface)
        i = "WAN1"
        if interface == "LTE":
          i = "WAN0"

        route.add('INTERFACE', i)
        route.add('METRIC', service.route_metric)

        # Apply the variables to each sub-service template
        template = ncs.template.Template(service)
        template.apply('wlan-template', wlan)
        template.apply('static-route-template', route)

    # The pre_modification() and post_modification() callbacks are optional,
    # and are invoked outside FASTMAP. pre_modification() is invoked before
    # create, update, or delete of the service, as indicated by the enum
    # ncs_service_operation op parameter. Conversely
    # post_modification() is invoked after create, update, or delete
    # of the service. These functions can be useful e.g. for
    # allocations that should be stored and existing also when the
    # service instance is removed.

    # @Service.pre_lock_create
    # def cb_pre_lock_create(self, tctx, root, service, proplist):
    #     self.log.info('Service plcreate(service=', service._path, ')')

    # @Service.pre_modification
    # def cb_pre_modification(self, tctx, op, kp, root, proplist):
    #     self.log.info('Service premod(service=', kp, ')')

    # @Service.post_modification
    # def cb_post_modification(self, tctx, op, kp, root, proplist):
    #     self.log.info('Service premod(service=', kp, ')')


# ---------------------------------------------
# COMPONENT THREAD THAT WILL BE STARTED BY NCS.
# ---------------------------------------------
class Main(ncs.application.Application):
    def setup(self):
        # The application class sets up logging for us. It is accessible
        # through 'self.log' and is a ncs.log.Log instance.
        self.log.info('Main RUNNING')

        # Service callbacks require a registration for a 'service point',
        # as specified in the corresponding data model.
        #
        self.register_service('secure-access-servicepoint', ServiceCallbacks)

        # If we registered any callback(s) above, the Application class
        # took care of creating a daemon (related to the service/action point).

        # When this setup method is finished, all registrations are
        # considered done and the application is 'started'.

    def teardown(self):
        # When the application is finished (which would happen if NCS went
        # down, packages were reloaded or some error occurred) this teardown
        # method will be called.

        self.log.info('Main FINISHED')

~~~~

### 8.3 Troubleshooting

When attempting to reload the service stack (secure-access in our case) issuing on the NSO CLI the command 

~~~~
packages reload
~~~~

you could be put in front of this error message

![Image of error packages reload](screenshots/tshoot/packages_reload.png)

This means that there were already secure-access service instances defined (e.g. d1) and you were trying to modify them. The previous versions of the service instantiated didn't have defined some of the mandatory attributes that you added when adding your services to the stack.
In order to solve this it's then necessary to remove those pre-existing instances in this way (e.g. for instance d1):

~~~~
no services secure-access d1
commit
~~~~

and then retry the package reload.

# **THANK YOU!**
