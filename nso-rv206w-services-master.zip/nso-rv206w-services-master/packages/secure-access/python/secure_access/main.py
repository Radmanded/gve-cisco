# -*- mode: python; python-indent: 4 -*-
import ncs
from ncs.application import Service


# ------------------------
# SERVICE CALLBACK EXAMPLE
# ------------------------
class ServiceCallbacks(Service):

    # The create() callback is invoked inside NCS FASTMAP and
    # must always exist.
    @Service.create
    def cb_create(self, tctx, root, service, proplist):
        self.log.info('Service create(service=', service._path, ')')
        #This is a stack service, we will need to provide the correct variables to each sub-service template
        
        ## Get wlan service variables
        wlan = ncs.template.Variables()
        
        wlan.add('DEVICE', service.device)
        wlan.add('SSID', service.ssid)
        
        ### Selection of radio mode
        radio = str(service.ssid_radio)
        if  radio == "5Ghz":
          wlan.add('RADIO', 'WLAN0')
        if radio == "2.5Ghz":
          wlan.add('RADIO', 'WLAN1')
        else:
          wlan.add('RADIO', 'BOTH')
          
        wlan.add('PWD', service.ssid_password)
        wlan.add('SCHEDULE', service.ssid_schedule)
        wlan.add('VLANID', service.ssid_vlan)
        
        ## Get static route service variables 
        route = ncs.template.Variables()
        route.add('DEVICE', service.device)
        route.add('DESCRIPTION', service.route_description)
        route.add('DESTINATION', service.route_destination)
        route.add('NEXTHOP', service.route_next_hop)
        
        interface = str(service.route_interface)
        i = "WAN1"
        if interface == "LTE":
          i = "WAN0"
        
        route.add('INTERFACE', i)
        route.add('METRIC', service.route_metric)
        
        ## Content Filtering Service
        cf_vars = ncs.template.Variables()
        cf_vars.add('DEVICE', service.device)
        cf_vars.add('FILTERING_TYPE', service.filtering_type)
        cf_vars.add('DOMAIN_NAME', service.domain_name)
        cf_vars.add('SCHEDULE_NAME', service.schedule_name)
        
        ## WAN Static Configuration Service 
        sc_vars = ncs.template.Variables()
        sc_vars.add('DEVICE', service.device)
        sc_vars.add('IPV4_ADDR', service.ipv4_addr)
        sc_vars.add('IPV4_NETMASK', service.ipv4_netmask)
        sc_vars.add('IPV4_GATEWAY_ADDR', service.ipv4_gateway_addr)
        sc_vars.add('INTERFACE_NAME', service.interface_name)
        sc_vars.add('PRIMARY_NAMING_SERVER', service.primary_naming_server)
        sc_vars.add('SECONDARY_NAMING_SERVER', service.secondary_naming_server)
        
        ## NTP Configuration Service
        ntp_vars = ncs.template.Variables()
        ntp_vars.add('DEVICE', service.device)
        ntp_vars.add('NTP_ENABLED', service.ntp_enabled)
        ntp_vars.add('NTP1_ADDRESS', service.ntp1_address)
        ntp_vars.add('NTP2_ADDRESS', service.ntp2_address)
        ntp_vars.add('NTP3_ADDRESS', service.ntp3_address)
        ntp_vars.add('NTP4_ADDRESS', service.ntp4_address)
        
        # Apply the variables to each sub-service template
        template = ncs.template.Template(service)
        template.apply('wlan-template', wlan)
        template.apply('static-route-template', route)
        template.apply('content_filtering-template', cf_vars)
        template.apply('wan_static-template', sc_vars)
        template.apply('ntp_py-template', ntp_vars)
        

    # The pre_modification() and post_modification() callbacks are optional,
    # and are invoked outside FASTMAP. pre_modification() is invoked before
    # create, update, or delete of the service, as indicated by the enum
    # ncs_service_operation op parameter. Conversely
    # post_modification() is invoked after create, update, or delete
    # of the service. These functions can be useful e.g. for
    # allocations that should be stored and existing also when the
    # service instance is removed.

    # @Service.pre_lock_create
    # def cb_pre_lock_create(self, tctx, root, service, proplist):
    #     self.log.info('Service plcreate(service=', service._path, ')')

    # @Service.pre_modification
    # def cb_pre_modification(self, tctx, op, kp, root, proplist):
    #     self.log.info('Service premod(service=', kp, ')')

    # @Service.post_modification
    # def cb_post_modification(self, tctx, op, kp, root, proplist):
    #     self.log.info('Service premod(service=', kp, ')')


# ---------------------------------------------
# COMPONENT THREAD THAT WILL BE STARTED BY NCS.
# ---------------------------------------------
class Main(ncs.application.Application):
    def setup(self):
        # The application class sets up logging for us. It is accessible
        # through 'self.log' and is a ncs.log.Log instance.
        self.log.info('Main RUNNING')

        # Service callbacks require a registration for a 'service point',
        # as specified in the corresponding data model.
        #
        self.register_service('secure-access-servicepoint', ServiceCallbacks)

        # If we registered any callback(s) above, the Application class
        # took care of creating a daemon (related to the service/action point).

        # When this setup method is finished, all registrations are
        # considered done and the application is 'started'.

    def teardown(self):
        # When the application is finished (which would happen if NCS went
        # down, packages were reloaded or some error occurred) this teardown
        # method will be called.

        self.log.info('Main FINISHED')
