# def getRECORD(user_id):
#     records = user_records.find_one({"user_id":user_id})
#     return records
#
# def pushRECORD(record):
#     user_records.insert_one(record)
#
# def updateRecord(record, updates):
#     user_records.update_one({'_id': record['_id']},{
#                               '$set': updates
#                               }, upsert=False)
#
import pymongo
from pymongo import MongoClient
#
# client = pymongo.MongoClient('mongodb+srv://timiomoya:t6ogd2PVgObVZ56L@cluster0-wlf2i.mongodb.net/test?retryWrites=true&w=majority')
# '''
# Be sure the install the right version of PyMongo
# You must also install dnspython module for connection to be made
# '''
# db = client.get_database('mydatabase')
#
# abseto_collection = db.abseto
#
# def get_data(user='xxxxx@yyyy.com',location='durban',date='today',duration= '1 hour',start='9am',end='10am',event_id='xyz'):
#     booking_info = {
#     'user_email':user,
#     'location':location ,
#     'date':date,
#     'duration':duration,
#     'start':start,
#     'end': end,
#     'event_id':event_id
#     }
#     return booking_info
#
# def insert_data():
#     booking_info = get_data()
#     abseto_collection.insert_one(booking_info)
#     return {}
#
# insert_data()

booking_info={"location":'durban'}
client = pymongo.MongoClient('mongodb+srv://timiomoya:t6ogd2PVgObVZ56L@cluster0-wlf2i.mongodb.net/test?retryWrites=true&w=majority')
'''
Be sure the install the right version of PyMongo
You must also install dnspython module for connection to be made
'''
db = client.get_database('mydatabase')
abseto_collection = db.abseto
abseto_collection.insert_one(booking_info)


# def update_data():
#     return{}
