
#! /usr/bin/env python3
from Calendar import get_token,get_calendar,modify_calendar,delete_event
from google_cal import send_email,create_event,google_delete_event

# import flask dependencies
from flask import Flask, request, make_response, jsonify,json
from flask import redirect, render_template, request, \
                send_from_directory, url_for
import json
import pandas as pd
import math
import pymongo
from pymongo import MongoClient
import pystache
from pprint import pprint
import webexteamssdk
import requests
import os
import sys
import string
from datetime import date as dt
from datetime import datetime




# initialize the flask app
app = Flask(__name__)
log = app.logger
MONGO_URI = os.environ.get('MY_MONGO_URI')
booking_info={}
client = pymongo.MongoClient(MONGO_URI)
'''
Be sure the install the right version of PyMongo
You must also install dnspython module for connection to be made
'''
db = client.get_database('mydatabase')
kaust_collection = db.kaust
BOT_TOKEN = os.environ.get('KAUST_BOT_ID')
teams_api = webexteamssdk.WebexTeamsAPI(access_token=BOT_TOKEN)
heroku_uri = os.environ.get('HEROKU_URI')

# def get_next_sequence(sequence_name):
#     sequence_doc = kaust_collection.find_and_modify(
#       query = {'_id': sequence_name },
#       update = {'$inc':{'sequence_value':1}},
#       upsert = True
#
#    )
    # return sequence_doc.get('sequence_value')


# default route
@app.route('/')
def index():
    return 'Hello World!'

#
def location_map(user_email):
    location = kaust_collection.find_one({'person_email':user_email},{'location':True})['location']
    # print(location)
    if location =='Engineering':
        map_url = 'https://bit.ly/3e1L7IR'
    elif location =='Sciences':
        map_url = 'https://bit.ly/3c9Nmbn'
    elif location== 'Arts':
        map_url = 'https://bit.ly/39XmSYQ'
    return map_url

def find_meeting_time_results(duration,date):

    available_time_slots = get_time(duration,date)
    timeslots =[]
    for i, time in enumerate(available_time_slots):
        start_time = time["start"]
        start_time = start_time[11:]
        start_time = start_time[:-11]
        end_time = time["end"]
        end_time = end_time[11:]
        end_time = end_time[:-11]
        timeslot = f'{i+1}. From   {start_time}  till  {end_time}'
        timeslots.append(timeslot)

    optionstring = '''Pick one of the times when the room would be available _(Eg. 1,2,3...)_'''
    timeslots = json.dumps(timeslots,indent=2,sort_keys=True)
    timeslots = timeslots.replace('"', '')
    timeslots = timeslots.replace(',','')
    timeslots = timeslots.replace(']','')
    timeslots = timeslots.replace('[','')
    timeslots = optionstring + '\n' + timeslots
    return timeslots


def delete_booking(event_id):
    token = get_token()
    delete_event(token,event_id)
    return 'deleted - YES'



def get_time(duration,date):
    token = get_token()
    duration = str(duration)
    duration = float(duration)
    duration = math.trunc(duration)
    duration= str(duration)
    start_time_value = date+'T'+'08:00:00'
    end_time_value = date+'T'+'18:00:00'
    duration_value = 'PT'+duration+'H'
    available_time_slotss = get_calendar(token,start_time_value,end_time_value,duration_value)
    return available_time_slotss



def get_message(session, payload):
    headers = {
        'content-type': 'application/json; charset=utf-8',
        'authorization': f'Bearer {BOT_TOKEN}'
    }
    url = f'https://api.ciscospark.com/v1/messages/{payload["data"]["id"]}'
    response = session.get(url, headers=headers)
    # pprint(response.json())
    return response.json()['text']

def get_card_data(session, payload):
    headers = {
        'content-type': 'application/json; charset=utf-8',
        'authorization': f'Bearer {BOT_TOKEN}'
    }
    response = session.get(f'https://api.ciscospark.com/v1/attachment/actions/{payload["data"]["id"]}', headers=headers)
    return response.json()

def get_person_info(session, payload):
    headers = {
        'content-type': 'application/json; charset=utf-8',
        'authorization': f'Bearer {BOT_TOKEN}'
    }
    url = f'https://api.ciscospark.com/v1/people/{payload["personId"]}'
    response = session.get(url, headers=headers)
    return response.json()

@app.route("/kaustbot", methods = ["POST"])
def kaust_handler():
    payload = request.get_json()
    session = requests.Session()
    # pprint(payload)




    # pprint(message)

    # When using DialogFlow, POST payload is embedded in a slightly different
    # JSON structure. Check if key originalDetectIntentRequest is present to know if
    # payload is from DialogFlow or Webex
    if "originalDetectIntentRequest" in payload:
        message = payload.get('queryResult').get('action')
        parameters =payload.get('queryResult').get('parameters')
        payload = payload["originalDetectIntentRequest"]["payload"]["data"]
        user_email= payload.get('data').get('personEmail')
    # pprint(user_email)

    # If message came from DialogFlow this check is redundant, but in
    # order to keep the logic simpler and the code more versatile we check that
    # the resource value is messages
    if payload["resource"] == "messages":
         # filter bot self triggered message
        if payload["data"]["personEmail"] == "kaust_poc@webex.bot":
            return "OK"
        # message = get_message(session, payload)
        # pprint(f"Message received: {message}")
        # if message =='input.welcome':
        if message == 'bookmeeting':
            # if message.strip().lower() == "wifi":
            with open('templates/greeting_card.json') as fp:
                text = fp.read()
                # converted = pystache.render(text)
                # card = json.loads(converted)
            card = json.loads(text)
            data = [
                    {'contentType': 'application/vnd.microsoft.card.adaptive', 'content': card}
                ]
            teams_api.messages.create(roomId=payload["data"]["roomId"] ,markdown='kindly fill form', attachments=data)
        # elif message =='bookmeeting':
        # # if message.strip().lower() == "wifi":
        #     with open('templates/booking_card.json') as fp:
        #         text = fp.read()
        #     # converted = pystache.render(text)
        #     # card = json.loads(converted)
        #     card = json.loads(text)
        #     data = [
        #             {'contentType': 'application/vnd.microsoft.card.adaptive', 'content': card}
        #         ]
        #     teams_api.messages.create(roomId=payload["data"]["roomId"] ,markdown='kindly fill form', attachments=data)
        elif message=='deletebooking':
            with open('templates/cancel_card.json') as fp:
                text = fp.read()
            # converted = pystache.render(text)
            # card = json.loads(converted)
            card = json.loads(text)
            data = [
                    {'contentType': 'application/vnd.microsoft.card.adaptive', 'content': card}
                ]
            teams_api.messages.create(roomId=payload["data"]["roomId"] ,markdown='kindly fill form', attachments=data)
        elif message =='input.simpleBook':
            slot_picked = parameters.get('SlotPicker')
            slot_picked = float(slot_picked)
            slot_picked = math.trunc(slot_picked)
            slot_picked = int(slot_picked)
            user_email = payload.get('data').get('personEmail')
            booking_details = kaust_collection.find_one({'person_email':user_email},{'date':True ,'duration':True,'attendees':True,'location':True})
            # print(booking_details)
            available_time_slots = get_time(booking_details['duration'],booking_details['date'])
            token = get_token()
            location = booking_details['location']
            class_time = booking_details['duration']
            # location = 'Lecture Theatre'
            webex_url='https://cisco.webex.com/meet/'+user_email.split('@')[0]
            # email_sent=f'''     Hi,
            # You have just booked a Class at {location}
            # {class_time}
            # You can join the Class using the link below
            #
            # {webex_url}
            # '''
            attendees = booking_details['attendees']
            # event_id = modify_calendar(token, available_time_slots[slot_picked-1]['start'], available_time_slots[slot_picked-1]['end'],location,email_sent)
            start_time= available_time_slots[slot_picked-1].get('start')
            # pprint(start_time)
            google_start_time = start_time.split('.')[0]
            start_time = start_time[11:]
            start_time = start_time[:-11]
            end_time = available_time_slots[slot_picked-1].get('end')
            google_end_time = end_time.split('.')[0]
            end_time = end_time[11:]
            end_time = end_time[:-11]
            attendee_email = booking_details['attendees']
            google_event_id = create_event(google_start_time,google_end_time,attendee_email)

            timeslot = f'From {start_time} till {end_time}'
            email_sent=f'''            Hi,

            You have just booked a meeting at {location}

            {timeslot}

            You can join the meeting using the link below

            {webex_url}
            '''
            event_id = modify_calendar(token, available_time_slots[slot_picked-1]['start'], available_time_slots[slot_picked-1]['end'],location,email_sent,user_email)

            kaust_collection.find_and_modify(
            query={'person_email':user_email},
            update = {'$set':{'event_id':event_id,'time':timeslot,'google_event_id':google_event_id}},
            upsert= True
            )
            place = booking_details['location']
            day = booking_details['date']

            # response_text=f'Yaay! I have booked your Lecture :) The details are below!  \n - Location :{place}. \n - date: {day}. \n - Time : {timeslot}'
            # teams_api.messages.create(roomId=payload.get('data').get('roomId'),markdown=response_text)
            with open('templates/booking_confirmation.json') as fp:
                text = fp.read()
                converted = pystache.render(text,{"location":booking_details["location"], "date":booking_details["date"], "time": timeslot})
                card = json.loads(converted)
                data = [{'contentType': 'application/vnd.microsoft.card.adaptive', 'content': card}]
                # teams_api.messages.create(toPersonEmail=ambassador_email , text = "New partner registration Request", attachments = data)
                teams_api.messages.create(roomId = payload["data"]["roomId"], text = "booking confirmation", attachments = data)
            # webex_user_name=user_email.split('@')[0]
            student_email=f'''            Hi,

            You would be having a lecture at {location}
            {timeslot}
            You can join the meeting using the link below
            {webex_url}
            '''
            course = booking_details['location']
            email_subject=f'You have a  meeting coming up at {course}'
            send_email(email_subject,student_email,attendee_email)
            # print(user_email)
            # pprint(payload)
            # person_info = get_person_info(session, payload.get('data'))
            # pprint(person_info)
            # print(slot_picked)
        elif message =='simpleBook.simpleBook-no':
            user_email = payload.get('data').get('personEmail')
            url = location_map(user_email)
            # url = 'https://bit.ly/3e1L7IR'

            reply_text=f'Welcome :) This is the direction to the venue [Here]({url}) .\n - **Please arrive 15 minutes prior to your Lecture**.  Have a great day!'
            teams_api.messages.create(roomId=payload.get('data').get('roomId'),markdown=reply_text)

        else:
            teams_api.messages.create(roomId=payload["data"]["roomId"], text="Unrecognized command")
        # pprint(card_webhook())

    elif payload["resource"] == "attachmentActions":
        card_data = get_card_data(session, payload)
        person_info = get_person_info(session, card_data)
        user_email = person_info.get('emails')[0]
        # pprint(user_email)
        # pprint(card_data)
        if 'greeting' in card_data.get('inputs'):
            # if card_data.get('input').get()
            if card_data.get('inputs').get('greeting')=='book':
                # if message.strip().lower() == "wifi":
                with open('templates/booking_card.json') as fp:
                    text = fp.read()
                    # converted = pystache.render(text)
                    # card = json.loads(converted)
                    card = json.loads(text)
                    data = [{'contentType': 'application/vnd.microsoft.card.adaptive', 'content': card}]
                    teams_api.messages.create(roomId=payload["data"]["roomId"] ,markdown='kindly fill form', attachments=data)
            elif card_data.get('inputs').get('greeting')=='cancel':
                with open('templates/cancel_card.json') as fp:
                    text = fp.read()
                    # converted = pystache.render(text)
                    # card = json.loads(converted)
                    card = json.loads(text)
                    data = [{'contentType': 'application/vnd.microsoft.card.adaptive', 'content': card}]
                    teams_api.messages.create(roomId=payload["data"]["roomId"] ,markdown='kindly fill form', attachments=data)
        if 'date' in card_data.get('inputs'):
            if card_data.get("inputs").get("compulsory_attendees")=='':
                with open('templates/card_selection_error.json') as fp:
                    text = fp.read()
                    converted = pystache.render(text,{"display_name":person_info["displayName"],"user_email": person_info["emails"][0]})
                    card = json.loads(converted)
                    data = [{'contentType': 'application/vnd.microsoft.card.adaptive', 'content': card}]
                    teams_api.messages.create(roomId = payload["data"]["roomId"], text = "select both fields", attachments = data)
            else:
                date = card_data.get('inputs').get('date')
                duration = card_data.get('inputs').get('number_hours')
                # architecture = card_data.get('inputs').get('architecture')
                attendees = card_data.get('inputs').get('compulsory_attendees')
                # resource = card_data.get('inputs').get('resource')
                location =card_data.get('inputs').get('location')
                day = datetime.strptime(date, '%Y-%m-%d').date()
                #error handling to make sure user fills in correct date
                if day < dt.today():
                    with open('templates/date_selection_error.json') as fp:
                        text = fp.read()
                        converted = pystache.render(text,{"display_name":person_info["displayName"],"user_email": person_info["emails"][0]})
                        card = json.loads(converted)
                        data = [{'contentType': 'application/vnd.microsoft.card.adaptive', 'content': card}]
                        teams_api.messages.create(roomId = payload["data"]["roomId"], text = "select both fields", attachments = data)

                    raise ValueError ('User inputed past date')
                if location =='Online':
                    with open('templates/online_time_card.json') as fp:
                        text = fp.read()
                        converted = pystache.render(text,{"display_name":person_info["displayName"],"user_email": person_info["emails"][0]})
                        card = json.loads(converted)
                        data = [{'contentType': 'application/vnd.microsoft.card.adaptive', 'content': card}]
                        teams_api.messages.create(roomId = payload["data"]["roomId"], text = "select both fields", attachments = data)
                        kaust_collection.find_and_modify(
                        query = {'person_email':user_email},
                        update = {'$set': {'location':location,'date': date,'duration':duration,'attendees':attendees}},
                        upsert = True
                        )
                else:
                    kaust_collection.find_and_modify(
                    query = {'person_email':user_email},
                    update = {'$set': {'location':location,'date': date,'duration':duration,'attendees':attendees}},
                    upsert = True
                    )
                    availaibility =find_meeting_time_results(duration,date)
                    availaibility = str(availaibility)
                    teams_api.messages.create(roomId=card_data.get('roomId'),markdown=availaibility)
        elif 'time' in card_data.get('inputs'):
            token=get_token()
            webex_time = card_data.get('inputs').get('time')
            webex_time = webex_time+':00'
            booking_details = kaust_collection.find_one({'person_email':user_email},{'date':True ,'duration':True,'attendees':True,'location':True})
            webex_date=booking_details['date']
            duration =booking_details['duration']
            duration=int(duration)
            location=booking_details['location']
            webex_start_time=webex_date+'T'+webex_time+'.0000000'
            time_shift =  pd.Timedelta(pd.offsets.Hour(duration)) + pd.Timedelta(webex_time)
            time_shift = str(time_shift)
            time_shift = time_shift[7:]
            webex_end_time= webex_date+'T'+time_shift+'.0000000'
            timeslot= f'From {webex_time[:5]} to {time_shift[:5]}'
            webex_url='https://cisco.webex.com/meet/'+user_email.split('@')[0]
            email_sent=f'''            Hi,

            You have just booked a meeting On Webex
            {timeslot}

            You can join the meeting using the link below

            {webex_url}
            '''
            event_id = modify_calendar(token,webex_start_time,webex_end_time,location,email_sent,user_email)
            google_start_time = webex_start_time.split('.')[0]
            google_end_time = webex_end_time.split('.')[0]
            attendee_email = booking_details['attendees']
            google_event_id = create_event(google_start_time,google_end_time,attendee_email)

            student_email=f'''            Hi,

            You would be having a meeting on Webex
            {timeslot}

            You can join the meeting using the link below
            {webex_url}
            '''
            email_subject=f'You have a webex meeting coming up'
            send_email(email_subject,student_email,attendee_email)


            kaust_collection.find_and_modify(
            query = {'person_email':user_email},
            update = {'$set': {'event_id':event_id,'google_event_id':google_event_id}},
            upsert = True
            )
            with open('templates/booking_confirmation.json') as fp:
                text = fp.read()
                converted = pystache.render(text,{"location":'Webex', "date":booking_details["date"], "time": timeslot})
                card = json.loads(converted)
                data = [{'contentType': 'application/vnd.microsoft.card.adaptive', 'content': card}]
                # teams_api.messages.create(toPersonEmail=ambassador_email , text = "New partner registration Request", attachments = data)
                teams_api.messages.create(roomId = payload["data"]["roomId"], text = "booking confirmation", attachments = data)




                    # event_id = modify_calendar(token, available_time_slots[slot_picked-1]['start'], available_time_slots[slot_picked-1]['end'],location,email_sent,user_email)
                    # kaust_collection.find_and_modify(
                    # query = {'person_email':user_email},
                    # update = {'$set': {'location':location,'date': date,'duration':duration,'attendees':attendees,'event_id':event_id}},
                    # upsert = True
                    # )





        elif 'cancel' in card_data.get('inputs'):
            cancel_confirm = card_data.get('inputs').get('cancel')
            cancel_reason = card_data.get('inputs').get('cancel_reason')
            booking_details= kaust_collection.find_one({'person_email':user_email},{'google_event_id': True,'event_id': True,'location': True, 'time': True,'date': True,'attendees': True})
            # event_id = kaust_collection.find_one({'person_email':user_email},{'event_id': True})['event_id']
            # google_event_id= kaust_collection.find_one({'person_email':user_email},{'google_event_id': True})['google_event_id']
            event_id = booking_details['event_id']
            google_event_id= booking_details['google_event_id']
            location= booking_details['location']
            timeslot=booking_details['time']
            date=booking_details['date']
            attendee_email=booking_details['attendees']
            delete = delete_booking(event_id)
            google_delete = google_delete_event(google_event_id)
            email_subject='Your meeting has been Canceled'
            student_email=f'''            Hi,

            This is to inform you that the {location} lecture

            that was to hold on {date} {timeslot} has been canceled

            Enjoy the Rest of your day !!

            '''
            send_email(email_subject,student_email,attendee_email)

            kaust_collection.find_and_modify(
            query={'person_email':user_email},
            update={'$set':{'If Deleted':delete}},
            upsert = True
            )
            res = 'Your meeting has been cancelled . Goodbye :)'
            teams_api.messages.create(roomId=card_data.get('roomId'),markdown=res)

            # print(cancel_confirm,cancel_reason)


        # person_info = get_person_info(session, card_data)
        # user_email = person_info.get('emails')[0]
        # pprint(user_email)
        # We assume that email list contains atleast one entry.
        # if card_data["inputs"]["user_type"] == "partner" and len(person_info["emails"]) \
        #     and is_partner(person_info["emails"][0]):
        #     with open('templates/welcome.json') as fp:
        #         text = fp.read()
        #
        #     converted = pystache.render(text,{"user_name":person_info["displayName"], "user_link":"dummy link"})
        #     card = json.loads(converted)
        #     data = [
        #             {'contentType': 'application/vnd.microsoft.card.adaptive', 'content': card}
        #         ]
        #
        #     teams_api.messages.create(roomId = payload["data"]["roomId"], text = "Welcome card" , attachments = data)
    # return {'fulfillmentText': 'ok'}
    return 'ok'


#route to the background image displayed in the website
@app.route("/feed/images/<filename>", methods=["GET"])
def get_feed(filename):
    return send_from_directory("feed/images", filename, mimetype="image/jpg")
#route to the video dispalyed in the website
@app.route("/feed/video/<filename>", methods = ["GET"])
def get_videofeed(filename):
    return send_from_directory("feed/video",filename,mimetype="video/mp4")

#display the cisco logo in the webpage
@app.route("/favicon.ico")
def get_favicon():
    return send_from_directory("static", "favicon.ico", mimetype="image/png")


@app.route("/")
def get_slash():
    return 'Hello World !'



def card_webhook():
    url = 'https://api.ciscospark.com/v1/webhooks'
    headers = {'Content-Type': 'application/json','Authorization': f'Bearer {BOT_TOKEN}'}

    data={
    'name':'kaustwebhook',
    'targetUrl': heroku_uri+'kaustbot',
    'resource': 'attachmentActions',
    'event':'created'
    }
    data = json.dumps(data)
    response = requests.post(url,headers=headers,data=data)
    return response.json()

if __name__ == '__main__':
    app.run(debug=True)
