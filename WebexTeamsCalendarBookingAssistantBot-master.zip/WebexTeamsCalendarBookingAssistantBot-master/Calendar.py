#! /usr/bin/env python

#import libraries
import requests
import json
import os
# import pandas as pd
# import pyodbc

def get_token():
    app_id = os.environ.get('APP_ID') #Application Id - on the azure app overview page
    client_secret = os.environ.get('CLIENT_SECRET')
    tenant=os.environ.get('TENANT')
    #Use the redirect URL to create a token url
    token_url = f'https://login.microsoftonline.com/{tenant}/oauth2/token'
    token_data = {
     'grant_type': 'password',
     'client_id': app_id,
     'client_secret': client_secret,
     'resource': 'https://graph.microsoft.com',
     'scope':'https://graph.microsoft.com',

     'username':os.environ.get('USERNAME'), #Account with no 2MFA
     'password':os.environ.get('PASSWORD'),
    }
    headers = {
        'Accept': 'application/json'
    }
    token_r = requests.post(token_url, data=token_data, headers=headers)
    token = token_r.json().get('access_token')              #changing the response into a dictionary and getting neeeded value
    print('Getting authorization and token' , token_r)

    return token


# def select_location():
    # Location = input ('Kindly choose your prefered Room \n1. Pretoria World Room \n2. Pretoria Edge \n3. Durban \nSelect Option 1 , 2 or 3')
    # if Location == '1' :
    #     id = os.environ.get('PRETORIA_WORLD_ID')
    # elif Location == '2' :
    #     id = os.environ.get('PRETORIA_EDGE_ID')
    # elif Location == '3':
    #     id = os.environ.get('DURBAN_ID')
    # else:
    #     print('kindly select a valid option')

    # id = os.environ.get('PRETORIA_WORLD_ID')
    # return id



#  function for finding free meeting times
'''
1. This particular API (findMeetingTimes API) seems to be buggy at the time of
writing this Script.
Especially when you change date value to a present month
It works perfectly for future or past months

Would most likely need to get a subsitute API if the bug isnt fixed
soon enough.



2. This particular API only goes only as far as the primary Calendar of a user
So it would be impossible to check other calendars that the user has created.
This means that this script only checks one calendar for availaibility.
So it would be impossible to show different Calendars, as that is what this PoV
is supposed to prove.
This problem is only due to the limited number of Calendars available for this PoV.
It SHOULD NOT be a problem in production since different webex devices would have
their own individual primary Calendars.
The URL would just need to change from :
https://graph.microsoft.com/v1.0/me/findMeetingTimes
and becomes
https://graph.microsoft.com/v1.0/user/{id|userPrincipalname}/findMeetingTimes

Then you can parse different Calenar ids (Location ids) and there respective userPrincipalname
into the function

'''
def get_calendar(token,start,end,duration):
    get_calendar_url = 'https://graph.microsoft.com/v1.0/me/findMeetingTimes'
    calendar_data = {
                    "Attendees": [],
                    "TimeConstraint": {
                    "ActivityDomain": "Unrestricted",
                    "Timeslots": [{
                    "Start": {
                    "DateTime": start,
                    "TimeZone": "UTC"
                    },
                    "End": {
                    "DateTime": end,
                    "TimeZone": "UTC"
                    }
                    }]
                    },
                    "meetingDuration": duration,
                    "MaxCandidates": 100
                    }
    calendar_headers = {
    "Authorization":"Bearer " + token,
    # "Prefer": {"outlook.timezone": "Pacific Standard Time"},
    "Content-type" : "application/json"
    # "Accept" : "application/json"

    }
    calendar_data=json.dumps(calendar_data)         #changing json to string because apparently that is what the API takes as a valid 'json payload'

    calendar_response = requests.post(get_calendar_url,headers=calendar_headers,data=calendar_data)
    possible_meeting_time=calendar_response.json()

    # parsing json to get values for start and end time
    time_list = []
    for suggestion in possible_meeting_time['meetingTimeSuggestions']:
            start = suggestion["meetingTimeSlot"]["start"]["dateTime"]
            end = suggestion["meetingTimeSlot"]["end"]["dateTime"]
            time_list.append({
                    'start': start,
                    'end': end
                })
    # print("This are the available Time Slot for the day you have choosen : ")
    # print(time_list)
    return time_list

#taking user choice of available time slots
def user_choice(time_list):
    for i, time in enumerate(time_list):
        print(f'{i+1}. Start_time: {time["start"]}, End_time: {time["end"]}')
    choice = input('Choose an option of the available times: ')
    choice=int(choice)
    return choice


# Creating a calendar event using timeslots chosen
def modify_calendar(token,start_time,end_time,location,email_sent,user_email):
    modify_calendar_url='https://graph.microsoft.com/v1.0/me/events'
    # modify_calendar_url=f'https://graph.microsoft.com/v1.0/me/calendars/{location}/events'
    modify_calendar_headers={
    'Authorization':token,
    'Content-Type':'application/json',
    # 'Content-length':'600'

    }

    modify_calendar_data = {

  "subject": "Kaust Has Booked a Meeting For You",
  "body": {
    "contentType": "Text",
    "content":email_sent
  },
  "start": {
      "dateTime": start_time,
      "timeZone": "UTC"
  },
  "end": {
      "dateTime": end_time,
      "timeZone": "UTC"
  },

  "location":{
      "displayName":location
  },
  "attendees": [
    {
      "emailAddress": {
        "address":user_email,
        "name": "tomoyajo"
      },
      "type": "required"
    }
  ]

  }

    modify_calendar_action = requests.post(modify_calendar_url,headers=modify_calendar_headers,data=json.dumps(modify_calendar_data))
    modify_calendar_response = modify_calendar_action.json()
    event_id = modify_calendar_action.json().get('id')
    print('Making your Booking ... ' , modify_calendar_action)
    return event_id

# deleting a calendar event using the id from when it was created
def delete_event(token,event_id):
    #Dosomething
    id=event_id
    delete_event_url = f'https://graph.microsoft.com/v1.0/me/events/{id}'
    delete_event_header = {'Authorization':token}

    delete_event_response= requests.delete(delete_event_url,headers=delete_event_header)
    print('deleting event', delete_event_response)
    return

# Mainfunction
if __name__ == "__main__":
#
    token= get_token()
    Location_id = select_location()
    start_time_value = '2020-04-02T12:00:00'
    end_time_value = '2020-04-02T18:00:00'
    duration = 'PT1H'
    available_time_slots=get_calendar(token,start_time_value,end_time_value,duration)
    print(available_time_slots)
    # start_time= available_time_slots[0].get('start')
    # start_time = start_time[11:]
    # start_time = start_time[:-11]
    # end_time = available_time_slots[0].get('end')
    # end_time = end_time[11:]
    # end_time = end_time[:-11]
    # timeslot = f'From {start_time} till {end_time}'
    # print(timeslot)
    # time_choice = user_choice(available_time_slots)
    # #(time_choice-1) because of indexing difference between user choice and actual list value
    # event_id = modify_calendar(token, available_time_slots[time_choice-1]['start'], available_time_slots[time_choice-1]['end'],Location_id)
    # delete_trigger = input('would you like to delete the booking you just made \nEnter y/n ')
    # if delete_trigger == 'y':
    #     delete_event(token,event_id)
