# from flask import Flask, request, make_response ,jsonify,json
# # import jsonify
#
# app = Flask(__name__)
# log = app.logger
#
# @app.route('/webhook', methods=['GET','POST'])
# def webhook():
#
#     req = request.get_json(force=True)
#     # try:
#     #     action = req.get('queryResult').get('action')
#     #     parameter = req.get('queryResult').get('parameters').get('param-name')
#     # except AttributeError:
#     #     return 'json error'
#
#     action = req.get("queryResult").get("action")
#     # parameter = req.get('queryResult').get('parameters').get('param-name')
#
#     # if action == "input.simpleBook":
#     #     res = "connection works"
#
#     # if parameter == "location":
#     #     res = find_calendar_slot(location)
#     # elif parameter == 'choice':
#     #     res = book_room(choice)
#     # elif action == 'cancel':
#     #     res = cancel_booking()
#     # else :
#     #     log.error('Unexpected action/parameter')
#     #
#     #
#     # print('Action: ' + action)
#     # print('Response: ' + res)
#
#     # return make_response(jsonify({'fulfillmentText': '2'}))
#     # return make_response(jsonify({'hi':'2'}))
#     return {}
#     # return make_response(jsonify({}))
#
# # def Location_choice():
# #     #use select_location()
# #     return{}
# # def find_calendar_slot():
# #     #user Location_choice()
# #     #use get_calendar()
# #     return{}
# # def choose_room():
# #     #use user_choice()
# #     return{}
# # def book_room():
# #     #use modify_calendar()
# #     return{}
# # def cancel_booking():
# #     #use delete_event()
# #     return {}
#
# if __name__ == '__main__':
#     app.run(debug=True)

#




from Calendar import get_token,get_calendar,modify_calendar,delete_event,select_location

# import flask dependencies
from flask import Flask, request, make_response, jsonify,json
import json
import pandas as pd
import math

# initialize the flask app
app = Flask(__name__)
log = app.logger

# default route
@app.route('/')
def index():
    return 'Hello World!'

# function for responses

def bookings_detail_parameters():
    req = request.get_json(force=True)

    # action = req.get('queryResult').get('action')
    location = req.get('queryResult').get('parameters').get('location')
    # date_time  = req.get('queryResult').get('outputContexts')[3].get('parameters').get('date-time')[0]
    date_time  = req.get('queryResult').get('parameters').get('date-time')[0]
    # date  = req.get('queryResult').get('parameters').get('date-time')[0]

    # duration  = req.get('queryResult').get('outputContexts')[3].get('parameters').get('duration').get('amount')
    duration  = req.get('queryResult').get('parameters').get('duration').get('amount')


    duration_unit  = req.get('queryResult').get('parameters').get('duration').get('unit')
    duration_unit = str(duration_unit)
    if duration_unit =='min':
        unit='M'
    elif duration_unit == 'h':
        unit='H'
    # duration_unit  = req.get('queryResult').get('outputContexts')[3].get('parameters').get('duration').get('unit')
    #if statement for 'h' or 'min'


    # duration = req.get('queryResult').get('parameters').get('duration').get('amount')
    # choice_input = req.get('queryResult').get('parameters').get('SlotPicker')
    # people_number = req.get('queryResult').get('parameters').get('numberPeople')

    # people_number = req.get('queryResult').get('outputContexts')[0].get('parameters').get('numberPeople.original')
    # choice_input = req.get('queryResult').get('outputContexts')[0].get('parameters').get('SlotPicker.original')
    # choice_input = req.get('queryResult').get('parameters').get('numberPeople')
    # return action,location,date,choice_input
    return date_time,duration,unit
    # return choice_input

def bookings_detail_context():
    req = request.get_json(force=True)
    date_time  = req.get('queryResult').get('outputContexts')[3].get('parameters').get('date-time')[0]
    duration  = req.get('queryResult').get('outputContexts')[3].get('parameters').get('duration').get('amount')
    duration_unit  = req.get('queryResult').get('outputContexts')[3].get('parameters').get('duration').get('unit')
    if duration_unit =='min':
        unit='M'
    elif duration_unit == 'h':
        unit='H'
    location = req.get('queryResult').get('outputContexts')[3].get('parameters').get('location')[0]
    date_time = req.get('queryResult').get('outputContexts')[3].get('parameters').get('date-time')[0]
    # date_time = date_time[11:]
    # date_time = date_time[:-11]
    return date_time,duration,unit,location,date_time

# def delete_booking_context():
#     req = request.get_json(force=True)
#     date_time  = req.get('queryResult').get('outputContexts')[1].get('parameters').get('date-time')[0]
#     duration  = req.get('queryResult').get('outputContexts')[1].get('parameters').get('duration').get('amount')
#     duration_unit  = req.get('queryResult').get('outputContexts')[1].get('parameters').get('duration').get('unit')
#     if duration_unit =='min':
#         unit='M'
#     elif duration_unit == 'h':
#         unit='H'
#     return date_time,duration,unit


def user_choice_parameters():
    req = request.get_json(force=True)
    choice_input = req.get('queryResult').get('parameters').get('SlotPicker')
    return choice_input
def user_choice_parameters_context():
    req = request.get_json(force=True)
    # choice_input = req.get('queryResult').get('parameters').get('SlotPicker')
    choice_input  = req.get('queryResult').get('outputContexts')[0].get('parameters').get('SlotPicker')
    choice_input = int(choice_input)
    return choice_input


def location_map():
    req = request.get_json(force=True)
    location = req.get('queryResult').get('outputContexts')[0].get('parameters').get('location')[0]
    if location =='Durban':
        map_url = 'https://bit.ly/3e1L7IR'
    elif location =='Pretoria':
        map_url = 'https://bit.ly/3c9Nmbn'
    elif location== 'Nairobi':
        map_url = 'https://bit.ly/39XmSYQ'
    return map_url

def find_meeting_time_results():
    # build a request object
    # req = request.get_json(force=True)

    # fetch action from json
    available_time_slots = get_time()

    # action = req.get('queryResult').get('action')
    # location = req.get('queryResult').get('parameters').get('location')
    # date  = req.get('queryResult').get('parameters').get('date')
    # duration = req.get('queryResult').get('parameters').get('duration').get('amount')
    # choice_input = req.get('queryResult').get('parameters').get('SlotPicker')
    # token = get_token()
    # available_time_slots = get_calendar(token)
    # token = get_token()
    # available_time_slots = get_calendar(token)

    timeslots =[]
    for i, time in enumerate(available_time_slots):
        # timeslot = f'{i+1}. {time["start"]} Until {time["end"]}'
        start_time = time["start"]
        start_time = start_time[11:]
        start_time = start_time[:-11]
        end_time = time["end"]
        end_time = end_time[11:]
        end_time = end_time[:-11]
        timeslot = f'{i+1}. From   {start_time}  till  {end_time} '
        timeslots.append(timeslot)


    # available_time_slots = enumerate(available_time_slots)
    # available_time_slots = {k:v for element in available_time_slots for k,v in element.items()}
    optionstring = '''These are the times when the room would be available
    Pick one of them. (Eg. 1,2,3...)'''
    timeslots = json.dumps(timeslots, indent= 2, sort_keys=True)
    timeslots = timeslots.replace('"', '')
    timeslots = timeslots.replace(',','')
    timeslots = timeslots.replace(']','')
    timeslots = timeslots.replace('[','')
    timeslots = optionstring + '\n' + timeslots

    return timeslots

def booked_time_response():
    available_time_slots = get_time_context()
    choice_input = user_choice_parameters_context()
    start_time= available_time_slots[choice_input-1].get('start')
    start_time = start_time[11:]
    start_time = start_time[:-11]
    end_time = available_time_slots[choice_input-1].get('end')
    end_time = end_time[11:]
    end_time = end_time[:-11]
    timeslot = f'From {start_time} till {end_time}'
    return timeslot




    # for i, time in enumerate(available_time_slots):
    #      Start_time: {time["start"]}
    #      End_time: {time["end"]}


    # if action == 'bookmeeting':
    #     res = timeslots
    # elif action =='input.simpleBook':
    #     book_calendar()
    #     res = 'booked!'
    #
    #
    # # return {}
    #
    # # return a fulfillment response
    # # print(duration)
    # return {'fulfillmentText': res}

# create a route for webhook

def results():
    req = request.get_json(force=True)
    action = req.get('queryResult').get('action')
    if action == 'bookmeeting':
        res = find_meeting_time_results()
    elif action =='input.simpleBook':
        book_calendar()
        response_detail = bookings_detail_context()
        location=response_detail[3]
        date = response_detail[4]
        date = date[:10]
        time = booked_time_response()

        res = f'''Yaay! I have booked your meeting :)
        These are the details :
        Location : {location}
        date: {date}
        Time : {time}
        Have you been to the edge center before ?'''
    elif action =='simpleBook.simpleBook-no':
        map_url= location_map()
        res = f'''Great, welcome to your first visit to the center.
        This is the map info : {map_url}

        Allow me to give you a breakdown of how to access the building:

        - Please arrive 15 minutes prior to your meeting.
        - Upon arrival, sign into the building and go to level 2.
        -A Cisco Edge Center ambassador will be present for you.

        If you would like to change your meeting-
        come back to this bot page and ask to modify your booking!

        Have a great day!
        '''

    elif action == 'deletebooking':
        if req.get('queryResult').get('parameters').get('reply')=='y':
            delete_booking()
            res = '''Your booking has been cancelled
            We would love to see you again though
            Goodbye !
            '''

        # delete_booking()
        # res = 'Your booking has been deleted. \n We would love to see you again \n Can you let us know why you are cancelling ?'
    return {'fulfillmentText': res}




def delete_booking():
    token = get_token()
    id = open('id.txt','r')
    calendar_id = id.read()
    id.close()
    delete_event(token,calendar_id)
    return None

@app.route('/webhook', methods=['GET','POST'])
def webhook():
    # return response
    # return {}
    # req = request.get_json(silent=True, force= True)
    # action = req.get("queryResult")

    # res = req
    #
    # res = make_response(res)
    # res.headers['Content-Type'] = 'application/json'


    # return make_response(jsonify(req))
    # return action




    # return make_response(jsonify(results()))
    return make_response(jsonify(results()))


def get_time_context():
    token = get_token()
    parameters = bookings_detail_context()
    duration = parameters [1]
    duration = str(duration)
    duration = float(duration)
    duration = math.trunc(duration)
    duration= str(duration)
    # date_time = '2020-04-07T12:00:00+02:00'
    date_time = parameters[0]
    date_time = str(date_time)
    date_string = date_time[:11]
    start_time_value = date_string+'08:00:00'
    end_time_value = date_string+'18:00:00'
    unit = parameters[2]

    # date_time=date_time[:-6]
    # start_time_value = date_time
    # duration_unit = parameters[2]
    # if duration_unit =='min':
    #     unit='M'
    # elif duration_unit == 'h':
    #     unit='H'
    duration_value = 'PT'+duration+unit
    available_time_slotsss = get_calendar(token,start_time_value,end_time_value,duration_value)
    return available_time_slotsss

def get_time():
    token = get_token()
    parameters = bookings_detail_parameters()
    # choice_input = parameters[0]
    duration = parameters [1]
    duration = str(duration)
    duration = float(duration)
    duration = math.trunc(duration)
    duration= str(duration)
    # date_time = '2020-04-07T12:00:00+02:00'
    date_time = parameters[0]
    date_time = str(date_time)
    date_string = date_time[:11]
    start_time_value = date_string+'08:00:00'
    end_time_value = date_string+'18:00:00'
    unit = parameters[2]

    # date_time=date_time[:-6]
    # start_time_value = date_time
    # duration_unit = parameters[2]
    # if duration_unit =='min':
    #     unit='M'
    # elif duration_unit == 'h':
    #     unit='H'
    duration_value = 'PT'+duration+unit

    # duration = float(duration)
    # date_time = "2020-04-02T12:00:00+02:00"
    # date_string = date_time[:11]
    # time_string=date_time[:-6]
    # time_string =date_time[11:]


    # if duration_unit == 'min':
    #     time_shift = pd.Timedelta(pd.offsets.Minute(duration)) + pd.Timedelta(time_string)
    # elif duration_unit == 'h':
    #     time_shift =  pd.Timedelta(pd.offsets.Hour(duration)) + pd.Timedelta(time_string)
    # time_shift = str(time_shift)
    # time_shift = time_shift[7:]
    # end_time_value = date_string+time_shift
    available_time_slotss = get_calendar(token,start_time_value,end_time_value,duration_value)
    return available_time_slotss

def book_calendar():
    token = get_token()
    # parameters = diagflow_parameters()
    # choice_input = parameters[0]
    # duration = parameters [2]
    # date_time = parameters[1]
    # start_time_value = date_time
    # duration_unit = parameters[3]
    #
    # duration = int(duration)
    # # date_time = "2020-04-02T12:00:00+02:00"
    # date_string = date_time[:11]
    # time_string=date_time[:-6]
    # time_string =time_string[11:]
    # if duration_unit == 'min':
    #     time_shift = pd.Timedelta(pd.offsets.Minute(duration)) + pd.Timedelta(time_string)
    # elif duration_unit == 'h':
    #     time_shift =  pd.Timedelta(pd.offsets.Hour(duration)) + pd.Timedelta(time_string)
    # time_shift = str(time_shift)
    # time_shift = time_shift[7:]
    # end_time_value = date_string+time_shift

    # available_time_slots=get_calendar(token,start_time_value,end_time_value)
    # choice_input = choice_input[3]
    choice_input = user_choice_parameters()
    # choice_input = parameters[0]
    available_time_slots = get_time_context()
    choice_input = int(choice_input)
    Location_id = select_location()
    event_id = modify_calendar(token, available_time_slots[choice_input-1]['start'], available_time_slots[choice_input-1]['end'],Location_id)
    event_id_txt = open('id.txt','w')
    event_id_txt.write(event_id)
    event_id_txt.close()
    # time_txt = open('id.txt','w')
    # event_id_txt.write(event_id)
    # event_id_txt.close()
    return event_id


# run the app
if __name__ == '__main__':
    app.run(debug=True)
    # api_script_actions()
