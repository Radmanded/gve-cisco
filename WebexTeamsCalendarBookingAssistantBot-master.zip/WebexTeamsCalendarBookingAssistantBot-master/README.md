# WebexTeamsCalendarBookingAssistantBot
Webex Teams Calendar (Google, O365) Booking Assistant Bot




| :exclamation:  External repository notice   |
|:---------------------------|
| This repository is now mirrored at "PLEASE UPDATE HERE - add External repo URL after code review is completed"  Please inform a https://github.com/gve-sw/ organization admin of any changes to mirror them to the external repo |
## Contacts
* Timi Omoyajowo

## Solution Components
*  Flask App
*  Webex Teams Bot
*  DialogFlow
*  O365
*  Mongo DB
*  Gmail
*  Google Calendar
*  Heroku

## Bot Architecture 

![Architectural Diagram](/IMAGES/HighLevelDiagram.png)

## Installation/Configuration



## Setting Up a Webex Teams Bot 
* Create a webex teams bot as described [here](https://developer.webex.com/docs/bots)
* Keep note of the token and ID

## Setting Up NLP Agent in Dialogflow 
* Create a Dialogflow agent as described [here](https://cloud.google.com/dialogflow/docs/agents-manage)
* Import the [Kaust.zip](https://wwwin-github.cisco.com/gve/WebexTeamsCalendarBookingAssistantBot/blob/master/kaust.zip) file into your agent in Dialogflow as described [here](https://cloud.google.com/dialogflow/docs/agents-prebuilt) 

## Setting up office 365 app on Azure 
* Register your application in Azure as described [here](https://docs.microsoft.com/en-us/graph/auth-v2-user)
* Take note of the :
    * Application ID
    * Client Secret
    * Tenant ID
        
## Setting Up MongoDB
* Create a new Mongodb collection as described [here](https://www.mongodb.com/blog/post/getting-started-with-python-and-mongodb)
* Take note of your URL to your DB

## Setting Up Google Calendar API
* Set up your google calendar API as described [here](https://www.youtube.com/watch?v=j1mh0or2CX8)
* See [here](https://gist.github.com/nikhilkumarsingh/8a88be71243afe8d69390749d16c8322) for example
* Replace the client_secret.json file in the repo with the one you have created.

## Setting Up Gmail
* Set up your Demo Gmail account 
* Keep note of the username and password 

## Running it all Together 
1. Clone the Repo 
2. Install all dependencies from requirements.txt file in the environment of your choice 
3. Provide the following enviromental variables
    * APP_ID -- Application Id from the Azure app overview page 
    * CLIENT_SECRET -- Also from the application in Azure 
    * TENANT -- Tenant ID from Azure 
    * USERNAME -- office 365 account username 
    * PASSWORD -- Office 365 account password
    * MONGO_URI -- mongodb URI for your database
    * AMBASSADOR_EMAIL-- email of whoever you would like to recieve fyi notifications about bookings made
    * HEROKU_URL --webhook URL from heroku or whichever webhook url you're using
    * BOT_TOKEN -- webex teams bot token 
    * GMAIL_ADDRESS -- Gmail address the bot will be using to send emails to gmail users
    * GMAIL_PASSWORD -- Password of the gmail address you have created 
4. Run the main.py file in the environment of your choice
5. Add the bot you have created to your space in webex teams and say "Hi"


# Screenshots

![/IMAGES/0image.png](/IMAGES/0image.png)

### LICENSE

Provided under Cisco Sample Code License, for details see [LICENSE](LICENSE.md)

### CODE_OF_CONDUCT

Our code of conduct is available [here](CODE_OF_CONDUCT.md)

### CONTRIBUTING

See our contributing guidelines [here](CONTRIBUTING.md)

#### DISCLAIMER:
<b>Please note:</b> This script is meant for demo purposes only. All tools/ scripts in this repo are released for use "AS IS" without any warranties of any kind, including, but not limited to their installation, use, or performance. Any use of these scripts and tools is at your own risk. There is no guarantee that they have been through thorough testing in a comparable environment and we are not responsible for any damage or data loss incurred with their use.
You are responsible for reviewing and testing any scripts you run thoroughly before use in any non-testing environment.
