#!/usr/bin/python3


import sys
from pprint import pprint
from googleapiclient.discovery import build
from datetime import datetime, timedelta
from google_auth_oauthlib.flow import InstalledAppFlow
scopes = ['https://www.googleapis.com/auth/calendar']
flow = InstalledAppFlow.from_client_secrets_file("client_secret.json", scopes=scopes)
credentials = flow.run_console()

import pickle
import pymongo
import smtplib

# import config

client = pymongo.MongoClient('mongodb+srv://timiomoya:t6ogd2PVgObVZ56L@cluster0-wlf2i.mongodb.net/test?retryWrites=true&w=majority')
'''
Be sure the install the right version of PyMongo
You must also install dnspython module for connection to be made
'''
db = client.get_database('mydatabase')
kaust_collection = db.kaust


pickle.dump(credentials, open("token.pkl", "wb"))
credentials = pickle.load(open("token.pkl", "rb"))
# print(credentials)
service = build("calendar", "v3", credentials=credentials)

start_time = datetime(2020, 5, 2, 16, 30, 0)
# print(start_time)
duration = 1
end_time = start_time + timedelta(hours=duration)
# duration =""
timezone = 'Europe/Amsterdam'


GMAIL_ADDRESS = os.environ.get('GMAIL_ADDRESS')
GMAIL_PASSWORD = os.environ.get('GMAIL_PASSWORD')


def is_a_student(email):

    # client = pymongo.MongoClient(db_uri)

    # db = client.get_default_database()

    student = kaust_collection

    entry = student.find_one({"email":email})
    # pprint(entry)

    if entry:
        return True
    else:
        return False


def send_student_email():
    return None



def send_email(subject, msg,email):
    try:
        server = smtplib.SMTP('smtp.gmail.com:587')
        server.ehlo()
        server.starttls()
        server.login(GMAIL_ADDRESS,GMAIL_PASSWORD)
        message = 'Subject: {}\n\n{}'.format(subject, msg)
        server.sendmail(GMAIL_ADDRESS, email, message)
        server.quit()
        print("Success: Email sent!")
    except:
        print("Email failed to send.")






def create_event(start_time,end_time,email):
    event = {
      'summary': 'You have a Class today',
      'location': '@webex',
      'description': 'kaust update',
      'start': {
        'dateTime': start_time,
        'timeZone': timezone,
      },
      'end': {
        'dateTime': end_time,
        'timeZone': timezone,
      },
      'attendees': [
      {'email': email}
      ],
      'reminders': {
        'useDefault': False,
        'overrides': [
          {'method': 'email', 'minutes': 24 * 60},
          {'method': 'popup', 'minutes': 10},
        ],
      },
    }
    result=service.events().insert(calendarId='primary', body=event).execute()
    invite_id = result.get('id')
    # if is_a_student(email) is True:
    #     result=service.events().insert(calendarId='primary', body=event).execute()
    #     invite_id = result.get('id')

    # pprint(invite_id)
    return invite_id

def google_delete_event(google_event_id):
    result= service.events().delete(calendarId='primary', eventId=google_event_id).execute()
    # print(result.json())
    return{}





# result = service.calendarList().list().execute()
