"""
Copyright (c) 2020 Cisco and/or its affiliates.
This software is licensed to you under the terms of the Cisco Sample
Code License, Version 1.1 (the "License"). You may obtain a copy of the
License at
           https://developer.cisco.com/docs/licenses
All use of the material herein must be in accordance with the terms of
the License. All rights not expressly granted by the License are
reserved. Unless required by applicable law or agreed to separately in
writing, software distributed under the License is distributed on an "AS
IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express
or implied.
"""

from ncclient import manager
import sys
import xml.dom.minidom
import config

def get_request(xml_filter):
    
    # Main method that sends and receives the NETCONF API calls.

    with manager.connect(host=config.host, username=config.username,
                         password=config.password, hostkey_verify=False,
                         device_params={'name': 'default'},
                         allow_agent=False, look_for_keys=False) as m:

        with open(xml_filter) as f:

            return(m.get(f.read()))


def main():

    commands = ['get-firmware','get-hardware','get-hostname','get-interfaces','get-sensors']
    
    i = 1
    while i != 0:
        print(commands)
        command = input("Enter which command to run: ")
        
        if command == 'get-firmware':
            response = get_request("templates/get_firmware.xml")
            print(xml.dom.minidom.parseString(response.xml).toprettyxml())

        elif command == 'get-hardware':
            response = get_request("templates/get_hardware.xml")
            print(xml.dom.minidom.parseString(response.xml).toprettyxml())
        
        elif command == 'get-hostname':
            response = get_request("templates/get_hostname.xml")
            print(xml.dom.minidom.parseString(response.xml).toprettyxml())
        
        elif command == 'get-interfaces':
            response = get_request("templates/get_interfaces.xml")
            print(xml.dom.minidom.parseString(response.xml).toprettyxml())

        elif command == 'get-sensors':
            response = get_request("templates/get_sensors.xml")
            print(xml.dom.minidom.parseString(response.xml).toprettyxml())

    exit()

    response = get_request(FILE)

    print(xml.dom.minidom.parseString(response.xml).toprettyxml())

if __name__ == '__main__':
    sys.exit(main())
