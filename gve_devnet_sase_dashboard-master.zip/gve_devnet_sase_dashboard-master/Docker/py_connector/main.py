import duo
import thousand_eyes
import umbrella
import config
import logging
import time
import influxdb_connect
import demo_dashboard 
from datetime import datetime

# set logger config
logging.getLogger().setLevel(logging.INFO)
logging.basicConfig(format="%(asctime)s - %(levelname)s - %(message)s")

def ThousandEyes_historical_data(TE):
    #getting all data or just specific?
    if config.enable_label_specific == 1:
        all_tests = TE.get_tests_by_label()
    else:
        all_tests = TE.get_tests_by_type()
        
    all_endpointtests=TE.get_endpointtests_by_type()
    if "http-server" in all_endpointtests:
        TE.get_all_http_server_endpointtests(all_endpointtests, config.window)

    # get historic data only if they are specified
    if "http-server" in all_tests:
        TE.get_all_http_server_tests(all_tests, config.window)
    
    if "page-load" in all_tests:
        TE.get_all_page_load_tests(all_tests, config.window)

    if "agent-to-server" in all_tests:
        TE.get_all_agent_server_tests(all_tests, config.window)

    if "agent-to-agent" in all_tests:
        TE.get_all_agent_agent_tests(all_tests, config.window)
    logging.info(" === Success! Got ALL HISTORIC test data. Pulling new data now... === ")

def ThousandEyes_new_data(TE):
     # get new data only if they are specified
    if config.enable_label_specific == 1:
            all_tests = TE.get_tests_by_label()
    else:
        all_tests = TE.get_tests_by_type()
    
    all_endpointtests=TE.get_endpointtests_by_type()
    if "http-server" in all_endpointtests:
        TE.get_all_http_server_endpointtests(all_endpointtests, config.window)

    if "http-server" in all_tests:
        TE.get_all_http_server_tests(all_tests, "latest")

    if "page-load" in all_tests:
        TE.get_all_page_load_tests(all_tests, "latest")

    if "agent-to-server" in all_tests:
        TE.get_all_agent_server_tests(all_tests, "latest")

    if "agent-to-agent" in all_tests:
        TE.get_all_agent_agent_tests(all_tests, "latest")

    logging.info("Pulled new thousand eyes data.")

def Umbrella_historical_data(Umbrella):
    try:
        Umbrella.umb_authtoken()
    except:
        logging.info("Umbrella getting authtoken did not work")

    try:
        Umbrella.blocked_urls()
    except:
        logging.info("Umbrella getting blocked urls did not work")
    try:
        Umbrella.top_urls()
    except:
        logging.info("Umbrella getting topurls did not work")
    Umbrella.Requests_perHour()
    for url in config.URLS:
        Umbrella.URL_info(url)

def Umbrella_new_data(Umbrella):
    Umbrella.umb_authtoken()
    try:
        Umbrella.blocked_urls()
    except:
        logging.info("Umbrella getting blocked urls didnt work")
    Umbrella.top_urls()
    for url in config.URLS:
        Umbrella.URL_info(url)

def Duo_historical_data(Duo):
    logs = Duo.get_authentication_log()
    for app in config.duo_integration:
        Duo.parse_app(logs, app)
    for app in config.duo_demo_integrations:
        Duo.make_demo_data(app[0], app[1])

def Duo_data(Duo):
    logs = Duo.get_authentication_log()
    for app in config.duo_integration:
        Duo.parse_app(logs, app)
    for app in config.duo_demo_integrations:
        Duo.make_demo_data(app[0], app[1])

def parse_traffic(Umb, TE, Duo):
    """
    Granular method of parsing all the data from TE, Umbrella, and Duo to combine them into a single metric to be used as a health monitor of the App

    Returns a score between 0 and 100 for the app of choice.
    """


    umb_score = Umb/3
    duo_score = Duo/3
    TE_jitter_score = (1-TE[1])
    # TE_loss_score = 
    TE_maxLatency_score = (200- TE[2]) /200
    TE_avgLatency_score = (100 - TE[3]) /100
    TE_score = (TE_maxLatency_score + TE_avgLatency_score + TE_jitter_score) *11.1111
    Total_score = umb_score + duo_score + TE_score
    return Total_score

def parse_TE_Traffic(data, url):
    """
    Parses the ThousandEyes data to take the average values of each of the main TE metrics over the given config window

    returns a list with average values
    """

    loss = 0
    jitter = 0
    maxLatency=0
    avgLatency=0
    minLatency=0
 
    total = len(data)
    for log in data:
        if (log['time'] > round(time.time() - 86400 * config.window_int)   ):
            loss += log['fields']['loss']
            jitter += log['fields']['jitter']
            maxLatency += log['fields']['maxLatency']
            avgLatency += log['fields']['avgLatency']
            minLatency += log['fields']['minLatency']
    if total==0:
        average_loss=0
    else:
        average_loss= loss/total
    if total==0:
        average_jitter=0
    else:
        average_jitter= jitter/total

    average_maxLatency=maxLatency/total
    average_avgLatency=avgLatency/total
    average_minLatency=minLatency/total
    returned_data = [average_loss, average_jitter, average_maxLatency, average_avgLatency, average_minLatency]
    return(returned_data)

def traffic_light_to_influx(data, url):
    """
    :insert_to_db: JSON friendly format for InfluxDBv2
    :te_test: Name of the TE Test
    Insert to database
    """
    te_event_time = int(datetime.now().timestamp())
    
    one_dataset = {
                    "measurement": f'Traffic {url} Light',
                    "tags":
                        {"IntegrationName": url,},
                    "fields": {
                        "traffic value": data,
                        },
                    "time":round(te_event_time)
                    }   

    try:
        influxdb_connect.write_api.write(
            bucket=config.influx_bucket,
            org=config.influx_org,
            record=one_dataset,
            write_precision=influxdb_connect.WritePrecision.S)
        logging.info(f"... traffic light info inserted into database.")
    except Exception as e:
        logging.exception(f"Can't insert data into Influx for traffic light")

def traffic_light_baseline(url):
    baseline_values = [0.0,100.0]
    for i in range(2):
        one_dataset = {
                "measurement": f'Traffic {url} Light',
                "tags":
                    {
                        "IntegrationName": url
                    },
                "fields": {
                        "traffic value": baseline_values[i],
                    },
                "time": round(time.time()-100*(i+2))
                }
        try:
            influxdb_connect.write_api.write(
                bucket=config.influx_bucket,
                org=config.influx_org,
                record=one_dataset,
                write_precision=influxdb_connect.WritePrecision.S)
            logging.info(f"... traffic light baseline info inserted into database for {url}.")
        except Exception as e:
            logging.exception(f"Can't insert data into Influx for traffic light baseline {url}")

def Traffic_light_data():
    #Grab TrafficLight Data from each source and then parse to find traffic score
    for url in config.URLS:
        TE_traffic_data = parse_TE_Traffic(TE.traffic_data[url], url) 
        Duo_app = config.URL_to_DUO[url]
        Traffic_light = parse_traffic(Umbrella.traffic_data[url] , TE_traffic_data, Duo.success_rate[Duo_app]) 
        traffic_light_baseline(url)
        traffic_light_to_influx(Traffic_light, url)

if __name__ == '__main__':
    time.sleep(60)
    #ThousandEyes Class init
    TE = thousand_eyes.ThousandEyes(
    window=config.window, 
    label_name=config.label_name, 
    oauth_bearer_token=config.oauth_bearer_token, 
    endpoint_agent1=config.endpoint_agent1, 
    influx_bucket=config.influx_bucket, 
    influx_org=config.influx_org, 
    umb_oauth_bearer_token=config.umb_oauth_bearer_token, 
    umb_base_url=config.umb_base_url, 
    umb_org_id=config.umb_org_id, 
    umb_time=config.umb_time, 
    enable_label_specific=config.enable_label_specific, 
    base_url=config.base_url, 
    test_types = config.test_types)
    
    Umbrella = umbrella.Umbrella(
    window=config.window, 
    influx_bucket=config.influx_bucket, 
    influx_org=config.influx_org, 
    umb_oauth_bearer_token=config.umb_oauth_bearer_token, 
    umb_base_url=config.umb_base_url, 
    umb_org_id=config.umb_org_id, 
    umb_time=config.umb_time, 
    interval = config.interval,)

    Duo = duo.Admin(
    ikey=config.ikey,
    skey=config.skey,
    host=config.host,)
    
    #Grab historical data of umbrella, duo, and thousandeyes and put it into influxdb
    ThousandEyes_historical_data(TE)
    logging.info("thouseandEyesData has been taken")
    Umbrella_historical_data(Umbrella)
    logging.info("umbrella data has been taken")
    Duo_historical_data(Duo)
    logging.info("duo data has been taken")
    Traffic_light_data()
    logging.info("Traffic light data has been taken")

    demo_dashboard.make_demo_dashboard()
    logging.info('made demo dashboard')

    #endless loop for pulling new data every x seconds
    while True:    
        logging.info('Pulling a new set of data')
        time.sleep(config.interval)
        ThousandEyes_new_data(TE)
        Traffic_light_data()
        Duo_data(Duo)
        Umbrella_new_data(Umbrella)

        
