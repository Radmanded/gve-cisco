from urllib.request import Request

#from pyparsing import And
import config
import influxdb_connect
import time
import requests
import logging
import datetime
import json

# set logger config
logging.getLogger().setLevel(logging.INFO)
logging.basicConfig(format="%(asctime)s - %(levelname)s - %(message)s")
class Umbrella:
    def __init__(self, window, influx_bucket, influx_org, umb_oauth_bearer_token, umb_base_url, umb_org_id, umb_time, interval):
        self.window = window
        self.interval = interval
        self.influx_bucket = influx_bucket
        self.influx_org = influx_org
        self.umb_oauth_bearer_token = umb_oauth_bearer_token
        self.umb_base_url = umb_base_url
        self.umb_org_id = umb_org_id
        self.umb_time = umb_time
        self.traffic_data = {}

    def umb_authtoken(self):
        try:
            url = "https://management.api.umbrella.com/auth/v2/oauth2/token"
            payload={}
            headers = {
                'Authorization': 'Basic MWI4ZGJkYzE3MzQ5NDdkZWJhYzFkNWY3OGQyOTIxMTc6MDNmYThlOGJjYzk4NGRkZTlhNjk0ODIyODU5NDA0ZWY='
                }
            response = requests.request("POST", url, headers=headers, data=payload)
            response.raise_for_status()
            if response.status_code == 200:
                    logging.info(f"Successfully requested umbrella auth token.")
            r=json.loads(response.text)
            r1=r["access_token"]
            self.umb_oauth_bearer_token= r1

        except Exception as e:
            logging.exception(f"Error! Could not get umbrella auth token: {e}")

    def Requests_perHour(self):
        headers = {'Authorization' : f'Bearer {self.umb_oauth_bearer_token}'}
        response = requests.request('GET', f"{self.umb_base_url}/organizations/{self.umb_org_id}/requests-by-timerange?from=-7days&to=now&offset=0&limit=169", headers=headers)
        r=json.loads(response.text)
        r1=r['data']
        print(r1[0]["counts"]["allowedrequests"])
        umb_test_dataset_group=[]
        n=0
        try:
            while n<169:
                #influxDB JSON format
                one_dataset = {
                    "measurement": "Umbrella",
                    "tags":
                        {"testName": "Requests",},
                    "fields": {
                        "Requests Allowed": r1[n]['counts']['allowedrequests'],
                        "Requests Blocked": r1[n]['counts']["blockedrequests"],
                        },
                    "time": round(r1[n]["timestamp"]/1000),
                        }      
                umb_test_dataset_group.append(one_dataset)          
                n+=1
            logging.info(f"Week Summary added")
        except Exception as e:
                logging.exception(f"Error when getting week summary from Umbrella")
        self.umb_insert_to_influx_v2(umb_test_dataset_group)

    def URL_info(self, url):
        try:
            headers = {'Authorization' : f'Bearer {self.umb_oauth_bearer_token}'}
            response1 = requests.request('GET', f"{self.umb_base_url}/organizations/{self.umb_org_id}/summaries-by-destination/dns?from=-5minutes&to=now&offset=0&limit=1000", headers=headers)
            r1=json.loads(response1.text)
            r2=r1['data']
            response1.raise_for_status()

            if response1.status_code == 200:
                        logging.info(f"Successfully requested umbrella summary data for {url}.")
        
        except Exception as e:
            logging.exception(f"Error! Could not get umbrella week summary by desination")
        
        n=0
        URL_blocked=0
        URL_allowed=0
        URL_success=0

        while n<len(r2):
                if r2[n]["domain"]== url:
                    URL_blocked =r2[n]["summary"]["requestsblocked"]
                    URL_allowed =r2[n]["summary"]["requestsallowed"]
                    URL_success_calc =int((r2[n]["summary"]["requestsallowed"])/(r2[n]["summary"]["requests"])*100)
                    if URL_success_calc == 0 and URL_allowed == 0:
                        URL_success          
                elif n==len(r2) and r2[n]["domain"]!=url: 
                    URL_blocked =int(0.0)
                    URL_allowed =int(0.0)
                    URL_success =int(100.0)
                n+=1
        try:
            self.traffic_data[url] = URL_success/(URL_success+URL_blocked)

        except:
            self.traffic_data[url] = 100.0

        umb_test_dataset_group=[]
        try:
            te_event_time = int(time.time())
                #influxDB JSON format
            one_dataset = {
                    "measurement": url,
                    "tags":
                        {"testName": "URL Summary",},
                    "fields": {
                        "URL_Blocked": URL_blocked,
                        "URL_Allowed" : URL_allowed,
                        "URL_Success" : URL_success,
                        },
                        "time": round(te_event_time)}      
            umb_test_dataset_group.append(one_dataset)
        except Exception as e:
                logging.exception(f"Error when getting day data about {url} from Umbrella")
        self.umb_insert_to_influx_v2(umb_test_dataset_group)

    def top_urls(self):
        headers = {'Authorization' : f'Bearer {self.umb_oauth_bearer_token}'}
        response = requests.request('GET', f"{self.umb_base_url}/organizations/{self.umb_org_id}/summaries-by-destination?from=-1days&to=now&offset=0&limit=10", headers=headers)
        r=json.loads(response.text)
        n=0
        umb_test_dataset_group=[]
        while n<10:             
            try:
                #influxDB JSON format
                one_dataset = {
                    "measurement": "TopURL" ,
                    "tags":
                        {
                        f"Domain": r['data'][n]["domain"]
                        },
                    "fields": {
                        "Top URL count": r['data'][n]["summary"]["requestsallowed"]
                        ,},
                        }      
                umb_test_dataset_group.append(one_dataset)
                n+=1               
            except Exception as e:
                logging.exception(f"Error when getting day data from Umbrella")
            self.umb_insert_to_influx_v2(umb_test_dataset_group)
            
    def blocked_urls(self):
        headers = {'Authorization' : f'Bearer {self.umb_oauth_bearer_token}'}
        response = requests.request('GET', f"{self.umb_base_url}/organizations/{self.umb_org_id}/summaries-by-destination?from=-1days&to=now&offset=0&limit=1000", headers=headers)
        r=json.loads(response.text)
        n=0
        umb_test_dataset_group=[]
        while n<1000: 
            if r['data'][n]["summary"]["requestsblocked"]>0:  
                # try:
                #influxDB JSON format
                    one_dataset = {
                        "measurement": "Top Blocked URL",
                        "tags":
                        {"Top Blocked URL": r['data'][n]["domain"]},
                        "fields": {
                        "Number of Requests": r['data'][n]["domain"],},
                        }      
                    umb_test_dataset_group.append(one_dataset)
            n+=1               
                # except Exception as e:
            self.umb_insert_to_influx_v2(umb_test_dataset_group)  
 
    def Traffic_light_data(self, URL1):
        try:
            headers = {'Authorization' : f'Bearer {self.umb_oauth_bearer_token}'}
            response1 = requests.request('GET', f"{self.umb_base_url}/organizations/{self.umb_org_id}/summaries-by-destination/dns?from=-7days&to=now&offset=0&limit=500", headers=headers)
            r1=json.loads(response1.text)
            r2=r1['data']
            response1.raise_for_status()

            if response1.status_code == 200:
                        logging.info(f"Successfully requested umbrella week summary by destination.")
        
        except Exception as e:
            logging.exception(f"Error! Could not get umbrella week summary by desination")
        
        try:
            response2 = requests.request('GET', f"{self.umb_base_url}/organizations/{self.umb_org_id}/summaries-by-destination/dns?from=-1days&to=now&offset=0&limit=500", headers=headers)
            r3=json.loads(response2.text)
            r4=r3['data']
            response2.raise_for_status()

            if response2.status_code == 200:
                        logging.info(f"Successfully requested umbrella day summary by destination.")
        
        except Exception as e:
            logging.exception(f"Error! Could not get umbrella week summary by desination")

        n=0
        week_blocked=0
        week_allowed=0
        week_success=0
        day_blocked=0
        day_allowed=0
        day_success=0

        while n<500:
                if r2[n]["domain"]== self.URL1:
                    week_blocked =r2[n]["summary"]["requestsblocked"]
                    week_allowed =r2[n]["summary"]["requestsallowed"]
                    week_success =(r2[n]["summary"]["requestsallowed"])/(r2[n]["summary"]["requestsblocked"]+r2[n]["summary"]["requestsallowed"])*100
                if r4[n]["domain"]== self.URL1:
                    day_blocked = r4[n]["summary"]["requestsblocked"]
                    day_allowed = r4[n]["summary"]["requestsallowed"]
                    day_success = (r4[n]["summary"]["requestsallowed"])/(r4[n]["summary"]["requestsblocked"]+r4[n]["summary"]["requestsallowed"])*100
                n+=1
        umb_test_dataset_group=[]
        try:
                #influxDB JSON format
            one_dataset = {
                    "measurement": self.URL1,
                    "tags":
                        {"testName": "URL Summary",},
                    "fields": {
                        "Week_Blocked": week_blocked,
                        "Week_Allowed" : week_allowed,
                        "Week_Success" : week_success,
                        "Day_blocked" : day_blocked,
                        "Day_Allowed": day_allowed, 
                        "Day_Success" : day_success,
                        },}      
            umb_test_dataset_group.append(one_dataset)
        except Exception as e:
                logging.exception(f"Error when getting day data about {self.URL1} from Umbrella")
        return(week_success)

    def umb_insert_to_influx_v2(self, insert_to_db):
        """
        :insert_to_db: JSON friendly format for InfluxDBv2
        :te_test: Name of the TE Test
        Insert to database
        """
        try:
            influxdb_connect.write_api.write(
                bucket=config.influx_bucket,
                org=config.influx_org,
                record=insert_to_db,
                write_precision=influxdb_connect.WritePrecision.S)
        except Exception as e:
            logging.exception(f"Can't insert data into Influx for Umbrella")
