import client
import six
import warnings
import sys
import time
import requests
import logging
import datetime
import json
import config
import influxdb_connect
import random

class Admin(client.Client ):
    account_id = None

    def get_authentication_log(self, api_version=1, **kwargs):
        """
        Returns authentication log events.

        api_version - The api version of the handler to use. Currently, the
                      default api version is v1, but the v1 api will be
                      deprecated in a future version of the Duo Admin API.
                      Please migrate to the v2 api at your earliest convenience.
                      For details on the differences between v1 and v2,
                      please see Duo's Admin API documentation. (Optional)

        API Version v1:

        mintime - Fetch events only >= mintime (to avoid duplicate
                  records that have already been fetched)

        Returns:
            [
                {'timestamp': <int:unix timestamp>,
                 'eventtype': "authentication",
                 'host': <str:host>,
                 'username': <str:username>,
                 'factor': <str:factor>,
                 'result': <str:result>,
                 'ip': <str:ip address>,
                 'new_enrollment': <bool:if event corresponds to enrollment>,
                 'integration': <str:integration>,
                 'location': {
                     'state': '<str:state>',
                     'city': '<str:city>',
                     'country': '<str:country>'
                 }
             }]

        Raises RuntimeError on error.

        API Version v2:

        mintime (required) - Unix timestamp in ms; fetch records >= mintime
        maxtime (required) - Unix timestamp in ms; fetch records <= maxtime
        limit - Number of results to limit to
        next_offset - Used to grab the next set of results from a previous response
        sort - Sort order to be applied
        users - List of user ids to filter on
        groups - List of group ids to filter on
        applications - List of application ids to filter on
        results - List of results to filter to filter on
        reasons - List of reasons to filter to filter on
        factors - List of factors to filter on
        event_types - List of event_types to filter on

        Returns:
            {
                "authlogs": [
                {
                  "access_device": {
                    "ip": <str:ip address>,
                    "location": {
                      "city": <str:city>,
                      "state": <str:state>,
                      "country": <str:country
                    }
                  },
                  "application": {
                    "key": <str:application id>,
                    "name": <str:application name>
                  },
                  "auth_device": {
                    "ip": <str:ip address>,
                    "location": {
                      "city": <str:city>,
                      "state": <str:state>,
                      "country": <str:country
                    },
                    "name": <str:device name>
                  },
                  "event_type": <str:type>,
                  "factor": <str:factor,
                  "reason": <str:reason>,
                  "result": <str:result>,
                  "timestamp": <int:unix timestamp>,
                  "user": {
                    "key": <str:user id>,
                    "name": <str:user name>
                  }
                }
              ],
              "metadata": {
                "next_offset": [
                  <str>,
                  <str>
                ],
                "total_objects": <int>
              }
            }

        Raises RuntimeError on error.
        """

        if api_version not in [1,2]:
            raise ValueError("Invalid API Version")

        params = {}

        if api_version == 1: #v1
            params['mintime'] = kwargs['mintime'] if 'mintime' in kwargs else 0;
            # Sanity check mintime as unix timestamp, then transform to string
            params['mintime'] = '{:d}'.format(int(params['mintime']))
            warnings.warn(
                'The v1 Admin API for retrieving authentication log events '
                'will be deprecated in a future release of the Duo Admin API. '
                'Please migrate to the v2 API.',
            DeprecationWarning)
        else: #v2
            for k in kwargs:
                if kwargs[k] is not None and k in VALID_AUTHLOG_REQUEST_PARAMS:
                    params[k] = kwargs[k]

            if 'mintime' not in params:
                params['mintime'] = (int(time.time()) - 86400) * 1000
            # Sanity check mintime as unix timestamp, then transform to string
            params['mintime'] = '{:d}'.format(int(params['mintime']))


            if 'maxtime' not in params:
                params['maxtime'] = int(time.time()) * 1000
            # Sanity check maxtime as unix timestamp, then transform to string
            params['maxtime'] = '{:d}'.format(int(params['maxtime']))


        response = self.json_api_call(
            'GET',
            '/admin/v{}/logs/authentication'.format(api_version),
            params,
        )

        if api_version == 1:
            for row in response:
                row['eventtype'] = 'authentication'
                row['host'] = self.host
        else:
            for row in response['authlogs']:
                row['eventtype'] = 'authentication'
                row['host'] = self.host
        return response

    def get_telephony_log(self,
                          mintime=0):
        """
        Returns telephony log events.

        mintime - Fetch events only >= mintime (to avoid duplicate
                  records that have already been fetched)

        Returns:
            [
                {'timestamp': <int:unix timestamp>,
                 'eventtype': "telephony",
                 'host': <str:host>,
                 'context': <str:context>,
                 'type': <str:type>,
                 'phone': <str:phone number>,
                 'credits': <str:credits>}, ...
            ]

        Raises RuntimeError on error.
        """
        # Sanity check mintime as unix timestamp, then transform to string
        mintime = str(int(mintime))
        params = {
            'mintime': mintime,
        }
        response = self.json_api_call(
            'GET',
            '/admin/v1/logs/telephony',
            params,
        )
        for row in response:
            row['eventtype'] = 'telephony'
            row['host'] = self.host
        return response

    def success_rate_set_baseline(self, app_name):
        """
        For small businesses where there isn't enough data to make a time graph and a gauge will be better in the dashboard, a baseline of 0 and 1 must be created for grafana
        to play nice with some of the visualization

        returns nothing
        """


        success_rate = [0.0,1.0]
        for i in range (2):
            one_dataset = {
                "measurement": f'Duo info for {app_name}',
                "tags":
                    {
                        "IntegrationName": app_name
                    },
                "fields": {
                        "Success rate": success_rate[i]
                    },
                "time": round(time.time()-100*(i+2))
                }
            self.duo_insert_to_influx_v2(one_dataset, app_name)
         

    def parse_app(self, logs, app_name):
        """
        For smaller apps where a time graph is unnecessary, this method condenses the app's authentications and inputs a success rate into influx and into a self variable

        returns nothing
        """



        successes = 0
        total = 0
        for log in logs:
            if (log.get('integration') == app_name):
                total += 1
            if (log.get('integration') == app_name) & (log.get('result') == 'SUCCESS'):
                successes +=1
        success_rate = successes/total
        one_dataset = {
                    "measurement": f'Duo info for {app_name}',
                    "tags":
                        {
                            "IntegrationName": app_name
                        },
                    "fields": {
                            "Success rate": success_rate
                        },
                    "time": round(time.time())
                    }
      
        print(f'this is gonna be the duo data for {app_name} with  a success of {successes} and a total of {total}')
        self.success_rate[app_name] = success_rate
        self.success_rate_set_baseline(app_name)
        self.duo_insert_to_influx_v2(one_dataset, app_name)

    #Duo Insert to Influx DB
    def duo_insert_to_influx_v2(self, insert_to_db, app_name):
        """
        :insert_to_db: JSON friendly format for InfluxDBv2
        :te_test: Name of the TE Test
        Insert to database
        """
        try:
            influxdb_connect.write_api.write(
                bucket=config.influx_bucket,
                org=config.influx_org,
                record=insert_to_db,
                write_precision=influxdb_connect.WritePrecision.S)
            logging.info(f"...duo info inserted into database for {app_name}.")
        except Exception as e:
            logging.exception(f"Can't insert data into Influx for Duo with {app_name}")

    def make_demo_data(self, app, company_size):
        """ 
        For demo purposes, this method makes data for the apps given in the duo_demo_integrations. Not for production use

        returns nothing
        
        """



        data_points = config.duo_demo_data_point_amount
        ts = round(time.time())
        interval =  data_points/ (config.window_int * 24*60*60) #spread 1,000,000 data points over the given window time
        duo_test_data_set = []
        
        for i in range(data_points):
            successes = (random.weibullvariate(1, 1) + 30) * company_size
            failures = (random.weibullvariate(1,1) + 7) * company_size

            if data_points*.8<i<data_points*.9:
                successes = (random.weibullvariate(1, 1)+25) * company_size
                failures = (random.weibullvariate(1,1) + 12) * company_size

            if i == (data_points -2):
                self.success_rate[app] = successes/failures
    
            one_dataset = {
                "measurement": f'Duo data for {app}',
                "tags":
                    {
                        "Authentication": "Success" 
                    },
                "fields": {
                        "hits": successes,
                    },
                "time": round(ts - i*interval)
                }
            duo_test_data_set.append(one_dataset)
            one_dataset = {
                "measurement": f'Duo data for {app}',
                "tags":
                    {
                        "Authentication": "Failure" 
                    },
                "fields": {
                        "hits": failures,
                    },
                "time": round(ts - i*interval)
                }
            duo_test_data_set.append(one_dataset)
        self.duo_insert_to_influx_v2(duo_test_data_set, app)

                
class AccountAdmin(Admin):
    """AccountAdmin manages a child account using an Accounts API integration."""

    def __init__(self, account_id, **kwargs):
        """Initializes an AccountAdmin for administering a child account.
           account_id is the account id of the child account.
           See the Client base class for other parameters."""
        super(AccountAdmin, self).__init__(**kwargs)
        self.account_id = account_id

