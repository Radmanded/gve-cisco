# SASE Dashboard
# CISCO SAMPLE CODE LICENSE Version 1.1, Cisco Systems 2021, rosboyd and pzeeuw
# IMPORTANT: If you already did once "docker-compose up" and want to change the settings,
# you have to rebuild the Docker Container: "docker-compose build"

# ================================= #
#        Domain Inputs              #
# ================================= #
#Insert URLS to applications which are to be monitored (Do not include "wwww." - example would be google.com)
URL1 = "outlook.office365.com" #Make sure this matches exact URL on TE and Umbrella
URL2 = "www.google.com"
URL3 = "www.salesforce.com"
URL4="www.github.com"
URLS = [URL1, URL2, URL3,URL4]
URL_to_DUO = {
    URL1: '',
    URL2: '',

    } #Each key value pair should be URL:<DUO Application Name> ex: URL1: "Microsoft Azure Active Directory"
TE_to_URL = {
    "": URL1,
    "": URL2,

} #Each key value pair should be <TE Test ID>:URL  ex: "2516364": URL1

no_of_endpointAgents = 1 #How many endpoint agents set up in thousand eyes?
endpoint_agent1 = "Ross Boyd" #Endpoint agents to be shown on SASE dashboard (Names must match exactly)

# ================================= #
#       ThousandEyes Settings       #
# ================================= #
base_url = "https://api.thousandeyes.com/v6" # define API base URL and API version
oauth_bearer_token = "" # Insert OAuth Bearer Token
# 0 = add ALL test types as stated in test_types 
# 1 = add ALL test types as stated in test_types AND which are TAGGED with the stated label_name
# Create your test label at https://app.thousandeyes.com/settings/tests/?tab=labels
enable_label_specific = 1 #change to 1 or 0
label_name = "grafana" #case sensitive!

### Define test types which should be added
# page-load includes: (Web) Page load, (Web) HTTP server, (Network) End-to-End metrics, (Network) Path visualization
test_types = ["page-load",
                "agent-to-agent",
                "agent-to-server",
                "http-server"]
### Set time window for historic data. Please ensure both the string version of "Xd" and the int version of X are present
# examples: 12h --> 12 hours interval, 1d --> 24 hours interval
window = "1d"
window_int = 1
### Set time interval (in seconds) for pulling new data from TE
interval = 300

# ================================= #
#       Umbrella Settings           #
# ================================= #
umb_base_url = "https://reports.api.umbrella.com/v2" # define API base URL and API version
umb_oauth_bearer_token = " " #added within main code
umb_time = "7" #default time which data is pulled for (Leave as 7)
umb_org_id = ""  #organisation id from Umbrella dashboard URL

# ================================= #
#       DUO Settings                #
# ================================= #
duo_demo_integrations = [ ] #In the format [<App_name>, <daily authentications>] ex: [ ['SalesForce' , 2000] , ['github' , 500], ['workday', 200] ]
duo_demo_data_point_amount = 100000 #Amount of data points generated for the demo data
duo_integration = [] #Names of the apps as seen in the Duo dashboard
ikey="" #Integration Key from DUO
skey=""  #Secret Key from DUO
host=""  #API host from DUO


# =========================================== #
#   INFLUX DB- DO NOT EDIT IF YOU ARE UNSURE  #
# =========================================== #
influx_token = "sensordata_token123"
influx_org = "sensordata_organization"
influx_bucket = "sensordata_bucket"
influx_url = "http://influxdb:8086"  #http://localhost:8086 for local testing using VSC

