import config
import influxdb_connect
import logging
import time
import random

# set logger config
logging.getLogger().setLevel(logging.INFO)
logging.basicConfig(format="%(asctime)s - %(levelname)s - %(message)s")

def make_demo_dashboard():
    make_Duo_data()
    make_Umbrella_data()
    make_TE_data("London, England", 0.1, 12.0, 0.3, 20.1)
    make_TE_data("Glasgow, Scotland", 0.1, 25.0, 0.15, 14.1)
    make_TE_data("Ross Boyd", 0.1, 40.0, 0.15, 4.1)
    make_traffic_data()

def make_traffic_data():
    data_points = [24.2, 0.0, 100.0]
    current_time = int(time.time())
    traffic_data = []
    for i in range(3):
        one_dataset = {
                    "measurement": f'Traffic DEMO DASHBOARD Light',
                    "tags":
                        {"IntegrationName": "DEMO DASHBOARD",},
                    "fields": {
                        "traffic value": data_points[i],
                        },
                    "time": current_time - 30*i
            }   
        traffic_data.append(one_dataset)
        one_dataset = {
                    "measurement": f'Traffic DEMO DASHBOARD Light',
                    "tags":
                        {"IntegrationName": "DEMO DASHBOARD",},
                    "fields": {
                        "traffic value": data_points[i],
                        },
                    "time": current_time - 1000*i
            }   
        traffic_data.append(one_dataset)
    data_to_influx(traffic_data, 'traffic_light')   


def make_TE_data(agentName, loss_avg, latency_avg, jitter_avg, throughput_avg):
    """
    Latency
    Jitter
    Loss
    Throughput
    """
    current_time = int(time.time())
    TE_test_dataset_group = []
    for i in range(2200):
        if 1000<=i<1200: #latency is bad
            avgLatency = latency_avg * random.normalvariate(1,0.15)*5
            avgLoss = loss_avg * random.normalvariate(1,0.05)
            avgjitter = jitter_avg * random.normalvariate(1,0.15)
            avgthroughput = throughput_avg * random.normalvariate(1,0.15)
        elif 1200<=i<1400: #loss is bad
            avgLatency = latency_avg * random.normalvariate(1,0.15)
            avgLoss = loss_avg * random.normalvariate(1,0.05)*45
            avgjitter = jitter_avg * random.normalvariate(1,0.15)
            avgthroughput = throughput_avg * random.normalvariate(1,0.15)
        elif 1400<=i<1600: #jitter is bad
            avgLatency = latency_avg * random.normalvariate(1,0.15)
            avgLoss = loss_avg * random.normalvariate(1,0.05)
            avgjitter = jitter_avg * random.normalvariate(1,0.15)*30
            avgthroughput = throughput_avg * random.normalvariate(1,0.15)
        elif 1600<=i<1800: #throughput is bad
            avgLatency = latency_avg * random.normalvariate(1,0.15)
            avgLoss = loss_avg * random.normalvariate(1,0.05)
            avgjitter = jitter_avg * random.normalvariate(1,0.15)
            avgthroughput = throughput_avg * random.normalvariate(1,0.15)*.4
        elif i<250:
            avgLatency = latency_avg * random.normalvariate(1,0.15)*5
            avgLoss = loss_avg * random.normalvariate(1,0.05)*45
            avgjitter = jitter_avg * random.normalvariate(1,0.15)*900
            avgthroughput = throughput_avg * random.normalvariate(1,0.15)*.4
        else:
            avgLatency = latency_avg * random.normalvariate(1,0.15)
            avgLoss = loss_avg * random.normalvariate(1,0.05)
            avgjitter = jitter_avg * random.normalvariate(1,0.15)
            avgthroughput = throughput_avg * random.normalvariate(1,0.15)           


        
        one_dataset = {
            "measurement": "TE DEMO DASHBOARD",
            "tags":
                {
                    "testName": "testName DEMO DASHBOARD",
                    "agentName": agentName
                },
            "fields": {
                "avgLatency":  avgLatency ,
                "jitter":  avgjitter  ,
                "loss":  avgLoss ,
                "throughput2": avgthroughput    ,


            },
            "time": current_time - 300*i
            }
        TE_test_dataset_group.append(one_dataset)
    data_to_influx(TE_test_dataset_group, "ThousandEyes")

def make_Umbrella_data():

    umb_test_dataset_group=[]
    current_time = int(time.time())
    for i in range(3000):
        try:
            #influxDB JSON format
            if i<400:
                URL_blocked = random.randint(1500,2500)
                URL_allowed = random.randint(3500, 4000)
                URL_Hit = URL_blocked + URL_allowed
                URL_success = URL_allowed / (URL_blocked+ URL_allowed)
            elif 1800<i<2050:
                URL_blocked = random.randint(1500,2500)
                URL_allowed = random.randint(3500, 4000)
                URL_Hit = URL_blocked + URL_allowed
                URL_success = URL_allowed / (URL_blocked+ URL_allowed)
            else:
                URL_blocked = random.randint(200,300)
                URL_allowed = random.randint(5000, 6500)
                URL_success = URL_allowed / (URL_blocked+ URL_allowed)
                URL_Hit = URL_blocked + URL_allowed

            one_dataset = {
                    "measurement": 'UMB DEMO DASHBOARD',
                    "tags":
                        {"testName": "URL Summary",},
                    "fields": {
                        "URL_Blocked": URL_blocked,
                        "URL_Allowed" : URL_allowed,
                        "URL_Success" : URL_success,
                        "URL_Hit": URL_Hit,
                        },
                        "time": current_time - (5*60*i)}      
            umb_test_dataset_group.append(one_dataset)
        except Exception as e:
                logging.exception(f"Error when getting day data about DEMO DASHBOARD from Umbrella")
    data_to_influx(umb_test_dataset_group, "umbrella")

def make_Duo_data():
    data_points = 2200
    ts = round(time.time())
    duo_test_data_set = []
    
    for i in range(data_points):
        successes = (random.weibullvariate(1, 1) + 30) * 2000
        failures = (random.weibullvariate(1,1) + 7) * 2000 

        if (i<150) or (1600<=i<2000):
            successes = (random.weibullvariate(1, 1)+25) * 2000
            failures = (random.weibullvariate(1,1) + 12) * 2000


        one_dataset = {
            "measurement": f'Duo fake data for demo dashboard',
            "tags":
                {
                    "Authentication": "Success" 
                },
            "fields": {
                    "hits": successes,
                },
            "time": round(ts - i*300)
            }
        duo_test_data_set.append(one_dataset)
        one_dataset = {
            "measurement": f'Duo fake data for demo dashboard',
            "tags":
                {
                    "Authentication": "Failure" 
                },
            "fields": {
                    "hits": failures,
                },
            "time": round(ts - i*300)
            }
        duo_test_data_set.append(one_dataset)
    data_to_influx(duo_test_data_set, 'duo')

def data_to_influx(data, section):
    
    """
    :insert_to_db: JSON friendly format for InfluxDBv2
    :te_test: Name of the TE Test
    Insert to database
    """
   

    try:
        influxdb_connect.write_api.write(
            bucket=config.influx_bucket,
            org=config.influx_org,
            record=data,
            write_precision=influxdb_connect.WritePrecision.S)
        logging.info(f"... demo dashboard inserted for {section}.")
    except Exception as e:
        logging.exception(f"Can't insert data into Influx for demo dashbaord for data {section}")