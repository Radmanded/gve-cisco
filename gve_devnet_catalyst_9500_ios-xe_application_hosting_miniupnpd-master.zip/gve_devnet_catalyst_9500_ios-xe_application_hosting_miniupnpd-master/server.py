""" Copyright (c) 2021 Cisco and/or its affiliates.
This software is licensed to you under the terms of the Cisco Sample
Code License, Version 1.1 (the "License"). You may obtain a copy of the
License at
           https://developer.cisco.com/docs/licenses
All use of the material herein must be in accordance with the terms of
the License. All rights not expressly granted by the License are
reserved. Unless required by applicable law or agreed to separately in
writing, software distributed under the License is distributed on an "AS
IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express
or implied.
"""

from xml.etree import cElementTree as ElementTree
from xml_to_dict import XmlDictConfig
from nat import port_forwarding
from flask import Flask, request, Response
from dotenv import load_dotenv
from threading import Thread
import os, json

app = Flask(__name__)

load_dotenv()
device_ext_ip = os.getenv("DEVICE_EXT_IP")

@app.route('/rootDesc.xml')
def get_rootDesc():
    with open("rootDesc.xml", "r") as data:
        xml = data.read()
    return Response(xml, mimetype="text/xml")

@app.route('/ctl/IPConn', methods=['POST'])
def soap_actions():
    request_headers = request.headers
    soap_action = request_headers.get("Soapaction", None)
    if soap_action == '"urn:schemas-upnp-org:service:WANIPConnection:1#GetStatusInfo"':
        resp = Response("""<s:Envelope xmlns:s="http://schemas.xmlsoap.org/soap/envelope/" s:encodingStyle="http://schemas.xmlsoap.org/soap/encoding/">
          <s:Body>
            <u:GetStatusInfoResponse xmlns:u="urn:schemas-upnp-org:service:WANIPConnection:1">
              <NewConnectionStatus>Connected</NewConnectionStatus>
              <NewLastConnectionError>ERROR_NONE</NewLastConnectionError>
              <NewUptime>11150347</NewUptime>
            </u:GetStatusInfoResponse>
          </s:Body>
        </s:Envelope>""")
        resp.headers["CONTENT-TYPE"] = 'text/xml; charset="utf-8"'
        resp.headers["EXT"] = ""
        resp.headers["SERVER"] = "C9500 UPnP/1.0"
        return resp

    elif soap_action == '"urn:schemas-upnp-org:service:WANIPConnection:1#GetExternalIPAddress"':
        resp = Response(f"""<s:Envelope xmlns:s="http://schemas.xmlsoap.org/soap/envelope/" s:encodingStyle="http://schemas.xmlsoap.org/soap/encoding/">
          <s:Body>
            <u:GetExternalIPAddressResponse xmlns:u="urn:schemas-upnp-org:service:WANIPConnection:1">
              <NewExternalIPAddress>{device_ext_ip}</NewExternalIPAddress>
            </u:GetExternalIPAddressResponse>
          </s:Body>
        </s:Envelope>""")
        resp.headers["CONTENT-TYPE"] = 'text/xml; charset="utf-8"'
        resp.headers["EXT"] = ""
        resp.headers["SERVER"] = "C9500 UPnP/1.0"
        return resp

    elif soap_action == '"urn:schemas-upnp-org:service:WANIPConnection:1#AddPortMapping"':
        payload = request.data.decode("utf-8")
        root = ElementTree.XML(payload)
        params = XmlDictConfig(root)
        internal_port = params["{http://schemas.xmlsoap.org/soap/envelope/}Body"]["{urn:schemas-upnp-org:service:WANIPConnection:1}AddPortMapping"]["NewInternalPort"]
        internal_host = params["{http://schemas.xmlsoap.org/soap/envelope/}Body"]["{urn:schemas-upnp-org:service:WANIPConnection:1}AddPortMapping"]["NewInternalClient"]
        external_port = params["{http://schemas.xmlsoap.org/soap/envelope/}Body"]["{urn:schemas-upnp-org:service:WANIPConnection:1}AddPortMapping"]["NewExternalPort"]
        resp = Response("""<s:Envelope xmlns:s="http://schemas.xmlsoap.org/soap/envelope/" s:encodingStyle="http://schemas.xmlsoap.org/soap/encoding/">
          <s:Body>
            <u:AddPortMappingResponse xmlns:u="urn:schemas-upnp-org:service:WANIPConnection:1">
            </u:AddPortMappingResponse>
          </s:Body>
        </s:Envelope>""")
        resp.headers["CONTENT-TYPE"] = 'text/xml; charset="utf-8"'
        resp.headers["EXT"] = ""
        resp.headers["SERVER"] = "C9500 UPnP/1.0"
        with open("port_mapping.json", "r") as file:
            port_mapping = json.loads(file.read())
        file.close()
        with open("port_mapping.json", "w") as file:
            port_mapping[external_port] = {
                "internal_port": internal_port,
                "internal_host": internal_host
            }
            json.dump(port_mapping, file)
            file.close()
        port_forwarding_thread = Thread(target=port_forwarding, args=["add", internal_host, internal_port, external_port]).start()
        return resp

    elif soap_action == '"urn:schemas-upnp-org:service:WANIPConnection:1#GetSpecificPortMappingEntry"':
        payload = request.data.decode("utf-8")
        root = ElementTree.XML(payload)
        params = XmlDictConfig(root)
        external_port = params["{http://schemas.xmlsoap.org/soap/envelope/}Body"]["{urn:schemas-upnp-org:service:WANIPConnection:1}GetSpecificPortMappingEntry"]["NewExternalPort"]
        with open("port_mapping.json", "r") as file:
            port_mapping = json.loads(file.read())
            file.close()
        resp = Response(f"""<s:Envelope xmlns:s="http://schemas.xmlsoap.org/soap/envelope/" s:encodingStyle="http://schemas.xmlsoap.org/soap/encoding/">
          <s:Body>
            <u:GetSpecificPortMappingEntryResponse xmlns:u="urn:schemas-upnp-org:service:WANIPConnection:1">
              <NewInternalPort>{external_port}</NewInternalPort>
              <NewInternalClient>{port_mapping[external_port]["internal_host"]}</NewInternalClient>
              <NewEnabled>1</NewEnabled>
              <NewPortMappingDescription>libminiupnpc</NewPortMappingDescription>
              <NewLeaseDuration>604800</NewLeaseDuration>
            </u:GetSpecificPortMappingEntryResponse>
          </s:Body>
        </s:Envelope>""")
        resp.headers["CONTENT-TYPE"] = 'text/xml; charset="utf-8"'
        resp.headers["EXT"] = ""
        resp.headers["SERVER"] = "C9500 UPnP/1.0"
        return resp

    elif soap_action == '"urn:schemas-upnp-org:service:WANIPConnection:1#DeletePortMapping"':
        payload = request.data.decode("utf-8")
        root = ElementTree.XML(payload)
        params = XmlDictConfig(root)
        external_port = params["{http://schemas.xmlsoap.org/soap/envelope/}Body"]["{urn:schemas-upnp-org:service:WANIPConnection:1}DeletePortMapping"]["NewExternalPort"]
        resp = Response("""<s:Envelope xmlns:s="http://schemas.xmlsoap.org/soap/envelope/" s:encodingStyle="http://schemas.xmlsoap.org/soap/encoding/">
          <s:Body>
            <u:u:DeletePortMappingResponse xmlns:u="urn:schemas-upnp-org:service:WANIPConnection:1">
            </u:u:DeletePortMappingResponse>
          </s:Body>
        </s:Envelope>""")
        resp.headers["CONTENT-TYPE"] = 'text/xml; charset="utf-8"'
        resp.headers["EXT"] = ""
        resp.headers["SERVER"] = "C9500 UPnP/1.0"
        with open("port_mapping.json", "r") as file:
            port_mapping = json.loads(file.read())
            file.close()
        with open("port_mapping.json", "w") as file:
            delete_port = port_mapping.pop(external_port, None)
            json.dump(port_mapping, file)
        file.close()
        internal_host = delete_port["internal_host"]
        internal_port = delete_port["internal_port"]
        port_forwarding_thread = Thread(target=port_forwarding, args=["remove", internal_host, internal_port, external_port]).start()
        return resp

def run_flask_server():
    app.run("0.0.0.0")
