""" Copyright (c) 2021 Cisco and/or its affiliates.
This software is licensed to you under the terms of the Cisco Sample
Code License, Version 1.1 (the "License"). You may obtain a copy of the
License at
           https://developer.cisco.com/docs/licenses
All use of the material herein must be in accordance with the terms of
the License. All rights not expressly granted by the License are
reserved. Unless required by applicable law or agreed to separately in
writing, software distributed under the License is distributed on an "AS
IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express
or implied.
"""

import socket, struct, os, json, uuid
from threading import Thread
from ssdp import SSDPServer
from server import run_flask_server
from dotenv import load_dotenv

load_dotenv()
local_ip = os.getenv("CONTAINER_IP")

if __name__ == "__main__":
    http_server_thread = Thread(target=run_flask_server)
    http_server_thread.daemon = True
    http_server_thread.start()

    # SSDP Server
    device_uuid = uuid.uuid4()
    ssdp = SSDPServer()
    ssdp.register('local',
                  'uuid:{}::upnp:rootdevice'.format(device_uuid),
                  'upnp:rootdevice',
                  'http://{}:5000/rootDesc.xml'.format(local_ip))
    ssdp.run()