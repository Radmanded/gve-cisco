""" Copyright (c) 2021 Cisco and/or its affiliates.
This software is licensed to you under the terms of the Cisco Sample
Code License, Version 1.1 (the "License"). You may obtain a copy of the
License at
           https://developer.cisco.com/docs/licenses
All use of the material herein must be in accordance with the terms of
the License. All rights not expressly granted by the License are
reserved. Unless required by applicable law or agreed to separately in
writing, software distributed under the License is distributed on an "AS
IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express
or implied.
"""

from netmiko import ConnectHandler
import sys, os
from dotenv import load_dotenv

load_dotenv()
device_ip = os.getenv("DEVICE_IP")
device_username = os.getenv("DEVICE_USERNAME")
device_password = os.getenv("DEVICE_PASSWORD")
device_ext_ip = os.getenv("DEVICE_EXT_IP")

def port_forwarding(action, internal_ip, internal_port, external_port):
    c9532c = {
        "device_type": "cisco_xe",
        "host": device_ip,
        "username": device_username,
        "password": device_password
    }

    net_connect = ConnectHandler(**c9532c)

    if action == "add":
        nat_config = [
            f"ip nat inside source static tcp {internal_ip} {internal_port} {device_ext_ip} {external_port}"
        ]
        ip_nat = net_connect.send_config_set(nat_config)

    elif action == "remove":
        nat_config = [
            f"no ip nat inside source static tcp {internal_ip} {internal_port} {device_ext_ip} {external_port}",
            "yes"
        ]
        net_connect.config_mode()
        ip_nat = net_connect.send_command(command_string=nat_config[0], expect_string=r"Static entry in use")
        ip_nat += net_connect.send_command(command_string=nat_config[1], expect_string=r"#")

    net_connect.disconnect()

