# Catalyst 9500 IOS-XE Application Hosting MiniUPnPd

This script works as a custom daemon working specifically on Cisco Catalyst 9500. It handles UPnP Protocol specification (SSDP, SCPD and SOAP) and is comprised of SSDP server (UPnP device discovery), SOAP web services (UPnP action request and response) and Netmiko agent (NAT configuration on Catalyst 9500). The application can be containerized and run on Catalyst 9500.

Note:
[Original open-source MiniUPnP project](http://miniupnp.free.fr/) is not compatible with Catalyst switches.
UPnP could cause significant security risks. Please use with care.
Application Hosting requirements vary between Catalyst 9000 Series switches, including hardware and cabling setup.

---

The following diagram describes the use case overview.

![Catalyst 9500 IOS-XE Application Hosting MiniUPnPd Overview](./IMAGES/Catalyst_9500_IOS-XE_Application_Hosting_MiniUPnPd_Overview.png)

The following diagram describes the PoV high level design.

![Catalyst 9500 IOS-XE Application Hosting MiniUPnPd High Level Design](./IMAGES/Catalyst_9500_IOS-XE_Application_Hosting_MiniUPnPd_High_Level_Design.png)



## Contacts
* Alvin Lau (alvlau@cisco.com)
* Jack Yu (jacyu2@cisco.com)
* Sergey Nasonov (snasonov@cisco.com)



## Solution Components
* Catalyst 9500
* Python 3.7
* Docker



## Installation
- **Prepare MiniUPnPd in Docker** - [Docker Installation](https://www.docker.com/get-started)
  1. Update all the variables in .env file. Device refers to Catalyst 9500.
  2. Using a workstation with Docker installed, build a docker image. Run `docker build -t miniupnpd .`
  3. Save the created docker image as an archived file. Run `docker save miniupnpd -o miniupnpd.tar`
  4. Copy the archived file to Catalyst 9500 flash storage.

- **Catalyst 9500 Application Hosting** - [Programmability Configuration Guide, Cisco IOS XE Amsterdam 17.3.x](https://www.cisco.com/c/en/us/td/docs/ios-xml/ios/prog/configuration/173/b_173_programmability_cg/application_hosting.html)
  1. Configure application hosting on the switch.
  ```
  configure terminal
  iox
  app-hosting appid miniupnpd
    app-vnic AppGigabitEthernet port 0 trunk
    vlan 101 guest-interface 0
      guest-ipaddress 100.1.1.14 netmask 255.255.255.0
   app-default-gateway 100.1.1.10 guest-interface 0
  ```
  2. Install and run the MiniUPnPd docker container.
  ```
  app-hosting install appid miniupnpd package flash:miniupnpd.tar
  app-hosting activate appid miniupnpd
  app-hosting start appid miniupnpd
  ```
  3. Verify application state.
  ```
  c9500#show app-hosting list
  App id                                   State
  ---------------------------------------------------------
  miniupnpd                                RUNNING
  ```


## Usage
- **Adding a Port Mapping**
  1. On client that is running the service to be exposed, run `upnpc -a <internal_ip> <internal_port> <external_port> tcp`
  2. The custom MiniUPnPd on Catalyst 9500 should receive the request and go through the UPnP Protocol flow. Eventually adding a static NAT configuration on the switch, i.e. `ip nat inside source static tcp <internal_ip> <internal_port> <external_ip> <external_port>`
  3. Using an external client, access to the exposed service at `<external_ip>:<external_port>`
  4. The custom MiniUPnPd keeps the port mapping in a json file (port_mapping.json). It updates the newly added port mapping.

- **Deleting a Port Mapping**
  1. On client that is running the service to be exposed, run `upnpc -d <external_port> tcp`
  2. The custom MiniUPnPd on Catalyst 9500 should receive the request and go through the UPnP Protocol flow. Eventually removing a static NAT configuration on the switch, i.e. `no ip nat inside source static tcp <internal_ip> <internal_port> <external_ip> <external_port>`, as well as the corresponding NAT translation.
  3. The external client can no longer access to the exposed service at `<external_ip>:<external_port>`
  4. The custom MiniUPnPd keeps the port mapping in a json file (port_mapping.json). It removes the specified port mapping.



## License
Provided under Cisco Sample Code License, for details see [LICENSE](./LICENSE)



## Code of Conduct
Our code of conduct is available [here](./CODE_OF_CONDUCT.md)



## Contributing
See our contributing guidelines [here](./CONTRIBUTING.md)



## Credits
SSDP portion of this script leverages code from [ZeWaren's repository Python UPnP Example](https://github.com/ZeWaren/python-upnp-ssdp-example)
