""" Copyright (c) 2021 Cisco and/or its affiliates.
This software is licensed to you under the terms of the Cisco Sample
Code License, Version 1.1 (the "License"). You may obtain a copy of the
License at
           https://developer.cisco.com/docs/licenses
All use of the material herein must be in accordance with the terms of
the License. All rights not expressly granted by the License are
reserved. Unless required by applicable law or agreed to separately in
writing, software distributed under the License is distributed on an "AS
IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express
or implied.
"""

from flask import Flask, render_template
import os
from dotenv import load_dotenv

load_dotenv()
vpn_user = os.getenv("VPN_USER")
vpn_group = os.getenv("VPN_GROUP")
vpn_password = os.getenv("VPN_PASSWORD")
vpn_host = os.getenv("VPN_HOST")

app = Flask(__name__)

@app.route("/")
def start():
    return render_template("index.html")

@app.route("/connect", methods=["POST"])
def connect_vpn():
    os.system(f"printf 'y\n{vpn_group}\n{vpn_user}\n{vpn_password}\ny' | /opt/cisco/anyconnect/bin/vpn -s connect {vpn_host}")
    return "OK", 200

@app.route("/disconnect", methods=["POST"])
def disconnect_vpn():
    os.system("/opt/cisco/anyconnect/bin/vpn disconnect")
    return "OK", 200

if __name__ == "__main__":
    port = int(os.environ.get('PORT', 8000))
    app.run(host='0.0.0.0', port=port)
