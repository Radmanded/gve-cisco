# AnyConnect VPN In Browser

A simple web app that uses the local AnyConnect agent to connect and disconnect from VPN. This is designated as a client-side web service where the AnyConnect agent is already installed.

---

The following diagram describes the use case overview.

![AnyConnect VPN In Browser Overview](./IMAGES/AnyConnect_VPN_In_Browser_Overview.png)

The following diagram describes the PoV high level design.

![AnyConnect VPN In Browser High Level Design](./IMAGES/AnyConnect_VPN_In_Browser_High_Level_Design.png)



## Contacts
* Alvin Lau (alvlau@cisco.com)
* Rich Yim (layim@cisco.com)



## Solution Components
* Cisco AnyConnect
* Python 3.7



## Prerequisite
- **Cisco AnyConnect** - Cisco AnyConnect agent should be installed before running the web service.

- **Client-side Control** - This web service is designated to run on client side. The web service launches and connects to VPN using the AnyConnect command line, which is not possible from a remote host. Hence, this use case falls under IT teams that have control over employees' laptops so that this web service can be installed before handing off to the end users.

- **Web Service** - The capability to connect to and disconnect from VPN is based on AnyConnect command line. This script is tested on MacOS and an VPN with login groups. Therefore, the AnyConnect command line to perform the action would differ from OS and type of VPN. For example, the path to AnyConnect is different in Windows and the inputs to other type of VPN are different. See line 32 and 37 in app.py for more details.



## Installation

1. Download this repository, or clone this repository by `git clone <this repo>`.

2. Optionally, create a Python 3 virtual environment.
```
python3 -m venv venv
source venv/bin/activate
```

3. Install the dependencies.
```
pip install -r requirement.txt
```

4. Update environment variables in .env file and AnyConnect CLI in line 32 and 37 in app.py.

5. Run the web service.
```
python app.py
```

6. Visit http://localhost:8000 to test connection and disconnection. Make sure the AnyConnect agent is not running as the web service would launch it.



## License
Provided under Cisco Sample Code License, for details see [LICENSE](./LICENSE)



## Code of Conduct
Our code of conduct is available [here](./CODE_OF_CONDUCT.md)



## Contributing
See our contributing guidelines [here](./CONTRIBUTING.md)
