function connect_vpn(){
    $.ajax({
        type: "POST",
        url: "/connect",
        success: function(res){
            alert("Connected!");
        }
    });
}

function disconnect_vpn(){
    $.ajax({
        type: "POST",
        url: "/disconnect",
        success: function(res){
            alert("Disconnected!");
        }
    });
}